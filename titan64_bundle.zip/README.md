titan64 soft-fault build
