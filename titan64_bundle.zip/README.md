# titan64 – Titan Souls 64-bit via Dynarmic (milestone 4)

Native code lives in `native/`. The APK is built by GitHub Actions (`.github/workflows/build.yml`).

## What milestone 4 does
The arm64 `libTestSuite.so` (this project) loads the ORIGINAL 32-bit game library from the APK asset
`guest/libTestSuite.so`, emulates it with Dynarmic and bridges every system call the game makes:

* **Game start** – runs the 558 static constructors, then the game's own `ANativeActivity_onCreate`
  (native_app_glue). The game creates its own threads; every guest thread runs on a host thread with its own
  Dynarmic instance (`sync.cpp`, `cpu.cpp`). Android lifecycle events (window, input queue, focus, pause/resume) are
  forwarded to the guest (`android_entry.cpp`).
* **Graphics** – `eglXxx` / `glXxx` calls are passed straight to the phone's real EGL / OpenGL ES 2 driver
  (`gles_bridge.cpp`). The app owns the EGL surface and draws the status banner with OpenGL (`host_gl.cpp`), then the
  game takes the same surface over.
* **Android** – assets (`AAsset_*`), `AConfiguration_*`, the real host `ALooper` and `AInputQueue` (`android_hle.cpp`),
  a fake JavaVM/JNIEnv (`jni_stub.cpp`).
* **libc** – heap with real `free`, stdio / POSIX files / directories / pipes (`libc_io.cpp`), wide chars, sscanf,
  regex, qsort, setjmp, zlib (`libc_misc.cpp`, `zlib_bridge.cpp`).
* **Audio** – FMOD is a silent stub for now (`fmod_stub.cpp`): the game runs without sound. Amazon GameCircle is stubbed.
* **Not implemented** – C++ exception unwinding (`_Unwind_*` ends the game with a clear message).

## How to read the result
* Banner colours: amber = working, red = failed (screenshot it, the last log lines are on screen),
  no banner (game picture) = the game owns the screen.
* Full log: `/sdcard/TitanSoulsSave/titan64.log` (or `Android/data/<package>/files/titan64.log`).
  Lines starting with `[hle] UNIMPLEMENTED import called` name a system function that still has to be written.
* `[gl] frame N swapped` means the game is rendering.

## Tests
`native/tests/hle_test.cpp` tests the portable HLE layer on a PC (allocator, threads, printf/sscanf, regex, qsort,
files, setjmp):

    g++ -std=c++20 -O1 -pthread -Inative/src native/src/{elf32,hle,builtins,log,sync,libc_io,libc_misc,fmod_stub}.cpp \
        native/tests/hle_test.cpp -o hle_test && ./hle_test
