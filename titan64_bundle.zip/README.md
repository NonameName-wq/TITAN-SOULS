titan64 soft-fault v2
