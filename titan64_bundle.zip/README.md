# titan64 – Titan Souls 64-bit via Dynarmic (milestone 3)

Native code: `native/`. Build is done by GitHub Actions (`.github/workflows/build.yml`).
Milestone 3 goal: the APK boots on arm64, loads the original 32-bit `libTestSuite.so` as an asset,
runs a CPU self-test and the game's 558 static constructors inside Dynarmic, and shows the result on screen.
Green banner = OK, red banner = failed (screenshot it).
