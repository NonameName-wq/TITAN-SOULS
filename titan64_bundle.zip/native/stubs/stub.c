/* Empty placeholder so TVActivity's System.loadLibrary("fmodex") / ("AmazonGamesJni") succeed on arm64. */
void t64_stub(void) {}
