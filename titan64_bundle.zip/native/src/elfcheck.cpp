// Verifies the ELF loader on the real library WITHOUT needing Dynarmic:
//   elfcheck libTestSuite.so
#include <algorithm>
#include <cstdio>
#include "hle.h"

int main(int argc, char** argv) {
    if (argc < 2) { std::fprintf(stderr, "usage: elfcheck <libTestSuite.so>\n"); return 2; }
    try {
        t64::GuestMemory mem;
        t64::Hle hle(mem);
        t64::LoadedLib lib = t64::LoadElf32(argv[1], mem, hle);
        std::printf("base=0x%08x image=0x%x bytes, symbols=%zu, exports=%zu\n", lib.base, lib.image_size, lib.syms.size(), lib.exports.size());
        std::printf("relocations: RELATIVE=%u JUMP_SLOT=%u GLOB_DAT=%u ABS32=%u other=%u\n",
                    lib.n_relative, lib.n_jump_slot, lib.n_glob_dat, lib.n_abs32, lib.n_other);
        std::printf("init_array=%zu fini_array=%zu\n", lib.init_array.size(), lib.fini_array.size());
        size_t bad = 0;
        for (uint32_t a : lib.init_array) if ((a & ~1u) < lib.base || (a & ~1u) >= lib.base + lib.image_size) ++bad;
        std::printf("init_array entries outside image: %zu\n", bad);

        std::vector<std::string> fn = lib.imported_functions, data = lib.imported_data;
        std::sort(fn.begin(), fn.end());
        size_t impl = 0;
        std::vector<std::string> missing;
        for (auto& n : fn) { if (hle.Implemented(n)) ++impl; else missing.push_back(n); }
        std::printf("imported functions: %zu (implemented %zu, missing %zu)\n", fn.size(), impl, missing.size());
        std::printf("imported data objects: %zu:", data.size());
        for (auto& n : data) std::printf(" %s", n.c_str());
        std::printf("\n--- missing functions ---\n");
        for (auto& n : missing) std::printf("%s\n", n.c_str());
    } catch (const std::exception& e) {
        std::fprintf(stderr, "error: %s\n", e.what());
        return 1;
    }
    return 0;
}
