// titan64: milestone runner.
//   titan64 --selftest
//   titan64 <libTestSuite.so> --call <symbol> [arg ...]
//   titan64 <libTestSuite.so> --init            (runs the 559 static constructors)
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "cpu.h"

using namespace t64;

static int SelfTest(GuestMemory& mem, Hle& hle) {
    // Thumb: lsls r0, r1, #2 ; bx lr   -> r0 = r1 << 2
    mem.write<uint16_t>(kScratch, 0x0088);
    mem.write<uint16_t>(kScratch + 2, 0x4770);
    Cpu cpu(mem, hle);
    CallResult r = cpu.Call(kScratch | 1, {1, 2});
    std::printf("selftest: ok=%d r0=%u (expected 8) %s\n", r.ok, r.r0, r.error.c_str());
    return r.ok && r.r0 == 8 ? 0 : 1;
}

int main(int argc, char** argv) {
    try {
        GuestMemory mem;
        Hle hle(mem);
        if (argc >= 2 && !std::strcmp(argv[1], "--selftest")) return SelfTest(mem, hle);
        if (argc < 3) {
            std::fprintf(stderr, "usage: titan64 --selftest | titan64 <lib.so> --init | --call <symbol> [args...]\n");
            return 2;
        }
        LoadedLib lib = LoadElf32(argv[1], mem, hle);
        Cpu cpu(mem, hle);
        if (!std::strcmp(argv[2], "--init")) {
            int n = 0;
            for (uint32_t fn : lib.init_array) {
                if (fn == 0 || fn == 0xFFFFFFFFu) continue;
                CallResult r = cpu.Call(fn, {});
                std::printf("init[%d] @0x%08x -> %s %s\n", n++, fn, r.ok ? "ok" : "FAILED", r.error.c_str());
                if (!r.ok) return 1;
            }
            return 0;
        }
        if (!std::strcmp(argv[2], "--call") && argc >= 4) {
            auto it = lib.exports.find(argv[3]);
            if (it == lib.exports.end()) { std::fprintf(stderr, "symbol not found: %s\n", argv[3]); return 1; }
            std::vector<uint32_t> args;
            for (int i = 4; i < argc; ++i) args.push_back(static_cast<uint32_t>(std::strtoul(argv[i], nullptr, 0)));
            CallResult r = cpu.Call(it->second, args);
            std::printf("%s -> ok=%d r0=0x%08x (%d) r1=0x%08x %s\n", argv[3], r.ok, r.r0, static_cast<int>(r.r0), r.r1, r.error.c_str());
            return r.ok ? 0 : 1;
        }
    } catch (const std::exception& e) {
        std::fprintf(stderr, "error: %s\n", e.what());
        return 1;
    }
    return 2;
}
