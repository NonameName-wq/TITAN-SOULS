// zlib for the 32-bit guest: the guest's z_stream (56 bytes, 32-bit fields) is mirrored onto a host z_stream per call.
#include <zlib.h>

#include <atomic>

#include "android_hle.h"
#include "handles.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {
namespace {

// Diagnostics: the first zlib calls with sizes, result codes and the first output bytes.
void ZLog(const char* what, int rc, uint32_t in_n, uint32_t out_n, const uint8_t* out) {
    static std::atomic<int> n{0};
    if (n++ >= 60) return;
    char b[200];
    std::snprintf(b, sizeof b, "[zlib] %s rc=%d in=%u out=%u", what, rc, in_n, out_n);
    std::string s = b;
    for (uint32_t i = 0; out && i < 8 && i < out_n; ++i) { char x[8]; std::snprintf(x, sizeof x, " %02x", out[i]); s += x; }
    Logf("%s", s.c_str());
}

HandleMap<z_stream*> g_streams(0x7E000000u);
enum : uint32_t { kNextIn = 0, kAvailIn = 4, kTotalIn = 8, kNextOut = 12, kAvailOut = 16, kTotalOut = 20,
                  kMsg = 24, kState = 28, kDataType = 44, kAdler = 48 };

z_stream* Host(GuestMemory& m, uint32_t strm) { return g_streams.GetOr(m.read<uint32_t>(strm + kState), nullptr); }

// Runs `op` on the host stream after copying the guest's buffers in; copies the progress back afterwards.
template <class F> uint32_t Run(GuestMemory& m, uint32_t strm, F op) {
    z_stream* hz = Host(m, strm);
    if (!hz) return uint32_t(Z_STREAM_ERROR);
    const uint32_t in_p = m.read<uint32_t>(strm + kNextIn), in_n = m.read<uint32_t>(strm + kAvailIn);
    const uint32_t out_p = m.read<uint32_t>(strm + kNextOut), out_n = m.read<uint32_t>(strm + kAvailOut);
    hz->next_in = in_n ? m.hostp(in_p, in_n) : nullptr;
    hz->avail_in = in_n;
    hz->next_out = out_n ? m.hostp(out_p, out_n) : nullptr;
    hz->avail_out = out_n;
    if ((in_n && !hz->next_in) || (out_n && !hz->next_out)) return uint32_t(Z_STREAM_ERROR);
    const int r = op(hz);
    ZLog("inflate/deflate", r, in_n - hz->avail_in, out_n - hz->avail_out, out_n ? m.hostp(out_p, 8) : nullptr);
    m.write<uint32_t>(strm + kNextIn, in_p + (in_n - hz->avail_in));
    m.write<uint32_t>(strm + kAvailIn, hz->avail_in);
    m.write<uint32_t>(strm + kTotalIn, uint32_t(hz->total_in));
    m.write<uint32_t>(strm + kNextOut, out_p + (out_n - hz->avail_out));
    m.write<uint32_t>(strm + kAvailOut, hz->avail_out);
    m.write<uint32_t>(strm + kTotalOut, uint32_t(hz->total_out));
    m.write<uint32_t>(strm + kAdler, uint32_t(hz->adler));
    m.write<int32_t>(strm + kDataType, hz->data_type);
    return uint32_t(r);
}

}  // namespace

void RegisterZlib(Hle& h) {
    GuestMemory& m = h.mem;
    h.Register("inflateInit2_", [&m](CallCtx& c) {  // (strm, windowBits, version, stream_size)
        auto* hz = new z_stream;
        std::memset(hz, 0, sizeof *hz);
        const int r = inflateInit2(hz, int32_t(c.arg(1)));
        if (r != Z_OK) { delete hz; c.ret(uint32_t(r)); return; }
        m.write<uint32_t>(c.arg(0) + kState, g_streams.Put(hz));
        m.write<uint32_t>(c.arg(0) + kMsg, 0);
        c.ret(0);
    });
    h.Register("inflate", [&m](CallCtx& c) { c.ret(Run(m, c.arg(0), [&](z_stream* z) { return ::inflate(z, int32_t(c.arg(1))); })); });
    h.Register("inflateEnd", [&m](CallCtx& c) {
        const uint32_t id = m.read<uint32_t>(c.arg(0) + kState);
        z_stream* hz = g_streams.GetOr(id, nullptr);
        int r = Z_STREAM_ERROR;
        if (hz) { r = ::inflateEnd(hz); delete hz; g_streams.Erase(id); m.write<uint32_t>(c.arg(0) + kState, 0); }
        c.ret(uint32_t(r));
    });
    h.Register("deflateInit2_", [&m](CallCtx& c) {  // (strm, level, method, windowBits, memLevel, strategy, version, stream_size)
        auto* hz = new z_stream;
        std::memset(hz, 0, sizeof *hz);
        const int r = deflateInit2(hz, int32_t(c.arg(1)), int32_t(c.arg(2)), int32_t(c.arg(3)), int32_t(c.arg(4)), int32_t(c.arg(5)));
        if (r != Z_OK) { delete hz; c.ret(uint32_t(r)); return; }
        m.write<uint32_t>(c.arg(0) + kState, g_streams.Put(hz));
        m.write<uint32_t>(c.arg(0) + kMsg, 0);
        c.ret(0);
    });
    h.Register("deflate", [&m](CallCtx& c) { c.ret(Run(m, c.arg(0), [&](z_stream* z) { return ::deflate(z, int32_t(c.arg(1))); })); });
    h.Register("deflateEnd", [&m](CallCtx& c) {
        const uint32_t id = m.read<uint32_t>(c.arg(0) + kState);
        z_stream* hz = g_streams.GetOr(id, nullptr);
        int r = Z_STREAM_ERROR;
        if (hz) { r = ::deflateEnd(hz); delete hz; g_streams.Erase(id); m.write<uint32_t>(c.arg(0) + kState, 0); }
        c.ret(uint32_t(r));
    });
    h.Register("uncompress", [&m](CallCtx& c) {  // (dest, uLongf* destLen, source, sourceLen)
        uLongf dl = m.read<uint32_t>(c.arg(1));
        uint8_t* dst = m.hostp(c.arg(0), dl);
        const uint8_t* src = m.hostp(c.arg(2), c.arg(3));
        if ((!dst && dl) || (!src && c.arg(3))) { c.ret(uint32_t(Z_STREAM_ERROR)); return; }
        const int r = ::uncompress(dst, &dl, src, c.arg(3));
        ZLog("uncompress", r, c.arg(3), uint32_t(dl), dst);
        m.write<uint32_t>(c.arg(1), uint32_t(dl));
        c.ret(uint32_t(r));
    });
}

}  // namespace t64
