// Flat 1 GiB guest address space for the 32-bit game code (lazily committed by the kernel).
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <string>
#include <sys/mman.h>
#include "log.h"

namespace t64 {

constexpr uint32_t kArenaSize = 0x40000000;
constexpr uint32_t kLibBase = 0x01000000;   // libTestSuite.so is loaded here
constexpr uint32_t kStubBase = 0x02000000;  // ARM stubs: 8 bytes per imported function
constexpr uint32_t kRetTramp = 0x02100000;  // Thumb BKPT; return target of Cpu::Call
constexpr uint32_t kDataBase = 0x02200000;  // imported data objects (_ctype_, __sF, ...)
constexpr uint32_t kDataEnd = 0x02400000;
constexpr uint32_t kScratch = 0x03000000;   // scratch area for self-tests
constexpr uint32_t kHeapBase = 0x04000000;
constexpr uint32_t kHeapEnd = 0x38000000;         // ~832 MiB of guest heap
constexpr uint32_t kThreadStackBase = 0x38000000;  // stacks of secondary guest threads / callback CPUs
constexpr uint32_t kThreadStackEnd = 0x3EE00000;
constexpr uint32_t kStackTop = 0x3F000000;         // main (emulator) thread stack, 2 MiB below this
constexpr uint32_t kVecBase = 0xFFFF0000;   // ARM "vector page": kernel user helpers (__kuser_cmpxchg, get_tls, ...)
constexpr uint32_t kVecSize = 0x1000;
constexpr uint32_t kTlsBlock = 0x023F0000;  // value returned by __kuser_get_tls

class GuestMemory {
public:
    GuestMemory() {
        p_ = static_cast<uint8_t*>(mmap(nullptr, kArenaSize, PROT_READ | PROT_WRITE,
                                        MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0));
        if (p_ == MAP_FAILED) throw std::runtime_error("mmap of guest arena failed");
    }
    ~GuestMemory() { munmap(p_, kArenaSize); }
    GuestMemory(const GuestMemory&) = delete;
    GuestMemory& operator=(const GuestMemory&) = delete;

    bool valid(uint32_t a, size_t n) const { return static_cast<uint64_t>(a) + n <= kArenaSize; }
    bool isVec(uint32_t a, size_t n) const { return a >= kVecBase && static_cast<uint64_t>(a) + n <= uint64_t(kVecBase) + kVecSize; }
    uint8_t* vec() { return vec_; }
    uint8_t* host(uint32_t a) { return p_ + a; }
    uint8_t* base() { return p_; }
    // Host pointer for a guest address range, or nullptr when it is NULL / outside the arena.
    uint8_t* hostp(uint32_t a, size_t n = 1) { return (a && valid(a, n)) ? p_ + a : nullptr; }

    template <class T> T read(uint32_t a) const {
        T v{};
        if (valid(a, sizeof(T))) std::memcpy(&v, p_ + a, sizeof(T));
        else if (isVec(a, sizeof(T))) std::memcpy(&v, vec_ + (a - kVecBase), sizeof(T));
        else Fault(a, false);
        return v;
    }
    template <class T> void write(uint32_t a, T v) {
        if (valid(a, sizeof(T))) std::memcpy(p_ + a, &v, sizeof(T));
        else if (isVec(a, sizeof(T))) { /* vector page is read-only */ }
        else Fault(a, true);
    }
    std::string cstr(uint32_t a, size_t max = 1 << 16) const {
        std::string s;
        while (s.size() < max && valid(a, 1) && p_[a]) s.push_back(static_cast<char>(p_[a++]));
        return s;
    }
    uint32_t faults() const { return faults_; }

private:
    void Fault(uint32_t a, bool w) const {
        if (faults_++ < 20) Logf("[mem] bad %s at 0x%08x", w ? "write" : "read", a);
    }
    uint8_t* p_ = nullptr;
    uint8_t vec_[kVecSize] = {};
    mutable uint32_t faults_ = 0;
};

}  // namespace t64
