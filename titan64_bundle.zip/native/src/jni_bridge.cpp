// JNI bridge: the 32-bit guest calls "Java" through a JNIEnv function table that lives in guest memory. Every slot of that
// table is a system-call stub that lands here and is forwarded to the phone's REAL JNI (the app's own Dalvik/ART VM), so the
// game's Java helper class (com.devolver.titansouls.TVActivity: device model, static data, ...) really answers.
//   * guest jobject/jclass/jstring/... handles are 32-bit ids of host global references (HandleMap)
//   * jmethodID / jfieldID are 32-bit ids of a table entry that also remembers the signature (needed to decode varargs)
//   * every host thread that calls in is attached to the VM on first use and detached when the guest thread ends
#include <jni.h>

#include <cstring>
#include <mutex>
#include <string>
#include <vector>

#include "android_hle.h"
#include "handles.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {
namespace {

JavaVM* g_vm = nullptr;
thread_local JNIEnv* t_env = nullptr;
thread_local bool t_exception = false;  // a Java exception was thrown by the last call (reported to the guest via ExceptionCheck)

JNIEnv* Env() {
    if (!t_env && g_vm) {
        if (g_vm->AttachCurrentThread(&t_env, nullptr) != JNI_OK) t_env = nullptr;
    }
    return t_env;
}

HandleMap<jobject> g_objs(0x7A400000u);  // guest handle -> host global reference

uint32_t WrapLocal(JNIEnv* e, jobject local) {  // takes over a local reference
    if (!local) return 0;
    jobject g = e->NewGlobalRef(local);
    e->DeleteLocalRef(local);
    return g ? g_objs.Put(g) : 0u;
}
jobject Unwrap(uint32_t h) { return h ? g_objs.GetOr(h, nullptr) : nullptr; }

struct Member {
    jmethodID mid = nullptr;
    jfieldID fid = nullptr;
    std::string sig, desc;
};
HandleMap<Member*> g_members(0x7A800000u);

int g_logged = 0;
std::mutex g_log_mu;
void JLog(const std::string& s) {
    std::lock_guard<std::mutex> lk(g_log_mu);
    if (g_logged++ < 500) Logf("[jni] %s", s.c_str());
}

// ---- method signature parsing: "(ILjava/lang/String;[J)V" ----
struct Sig {
    std::vector<char> args;  // Z B C S I J F D, or L for every reference (objects and arrays)
};
Sig ParseSig(const std::string& s) {
    Sig r;
    size_t i = 1;
    while (i < s.size() && s[i] != ')') {
        char ch = s[i];
        if (ch == '[') {
            while (i < s.size() && s[i] == '[') ++i;
            if (i < s.size() && s[i] == 'L') i = s.find(';', i);
            ch = 'L';
        } else if (ch == 'L') {
            i = s.find(';', i);
        }
        if (i == std::string::npos) break;
        r.args.push_back(ch);
        ++i;
    }
    return r;
}

// Decodes the arguments of a call. mode 0: C varargs still in registers/stack, 1: guest va_list, 2: jvalue array.
std::vector<jvalue> Decode(GuestMemory& m, const Sig& sg, int mode, CallCtx& c, int first) {
    std::vector<jvalue> out(sg.args.size());
    std::memset(out.data(), 0, out.size() * sizeof(jvalue));
    RegArgs ra(c, first);
    VaArgs va(m, mode == 1 ? c.arg(first) : 0u);
    const uint32_t arr = mode == 2 ? c.arg(first) : 0u;
    for (size_t k = 0; k < sg.args.size(); ++k) {
        jvalue& v = out[k];
        auto u32 = [&]() -> uint32_t { return mode == 0 ? ra.u32() : mode == 1 ? va.u32() : m.read<uint32_t>(arr + 8 * uint32_t(k)); };
        auto u64 = [&]() -> uint64_t { return mode == 0 ? ra.u64() : mode == 1 ? va.u64() : m.read<uint64_t>(arr + 8 * uint32_t(k)); };
        switch (sg.args[k]) {
            case 'Z': v.z = (u32() & 0xFFu) != 0; break;
            case 'B': v.b = jbyte(u32()); break;
            case 'C': v.c = jchar(u32()); break;
            case 'S': v.s = jshort(u32()); break;
            case 'I': v.i = jint(u32()); break;
            case 'J': v.j = jlong(u64()); break;
            case 'F':
                if (mode == 2) { const uint32_t b = u32(); std::memcpy(&v.f, &b, 4); }
                else { const uint64_t b = u64(); double d; std::memcpy(&d, &b, 8); v.f = float(d); }  // float varargs are promoted to double
                break;
            case 'D': { const uint64_t b = u64(); std::memcpy(&v.d, &b, 8); break; }
            default: v.l = Unwrap(u32()); break;
        }
    }
    return out;
}

// After every call: turn a pending Java exception into a logged, cleared one (+ ExceptionCheck=true for the guest).
bool CheckException(JNIEnv* e, const std::string& what) {
    if (!e->ExceptionCheck()) return false;
    e->ExceptionDescribe();
    e->ExceptionClear();
    t_exception = true;
    JLog("exception thrown by " + what);
    return true;
}

// Logs the text of a java.lang.String returned by a Java method (paths, flags, ... the game asks for).
void LogStringResult(JNIEnv* e, jobject r, const std::string& what) {
    static jclass string_class = nullptr;
    static std::mutex mu;
    {
        std::lock_guard<std::mutex> lk(mu);
        if (!string_class) {
            jclass local = e->FindClass("java/lang/String");
            if (local) { string_class = static_cast<jclass>(e->NewGlobalRef(local)); e->DeleteLocalRef(local); }
        }
    }
    if (!r || !string_class || !e->IsInstanceOf(r, string_class)) return;
    const char* s = e->GetStringUTFChars(static_cast<jstring>(r), nullptr);
    if (!s) return;
    JLog(what + " = \"" + std::string(s).substr(0, 300) + "\"");
    e->ReleaseStringUTFChars(static_cast<jstring>(r), s);
}

constexpr int kElemSize[8] = {1, 1, 2, 2, 4, 8, 4, 8};  // Boolean Byte Char Short Int Long Float Double

}  // namespace

void JniSetHost(void* vm) { g_vm = static_cast<JavaVM*>(vm); }

uint32_t JniWrapGlobal(void* obj) {
    JNIEnv* e = Env();
    if (!e || !obj) return 0;
    jobject g = e->NewGlobalRef(static_cast<jobject>(obj));
    return g ? g_objs.Put(g) : 0u;
}

void JniThreadExit() {
    if (t_env && g_vm) {
        g_vm->DetachCurrentThread();
        t_env = nullptr;
    }
}

void RegisterJni(Hle& h, uint32_t* vm_out, uint32_t* env_out) {
    GuestMemory& m = h.mem;
    constexpr int kEnvSlots = 240;
    const uint32_t env_tab = h.Alloc(4 * kEnvSlots), vm_tab = h.Alloc(4 * 8);
    const uint32_t env = h.Alloc(16), vm = h.Alloc(16);
    m.write<uint32_t>(env, env_tab);
    m.write<uint32_t>(vm, vm_tab);

    // Default for every slot: log once and return 0.
    for (int i = 0; i < kEnvSlots; ++i) {
        const std::string name = "JNIEnv#" + std::to_string(i);
        h.Register(name, [i](CallCtx& c) {
            static std::mutex mu;
            static bool seen[256] = {};
            bool first;
            { std::lock_guard<std::mutex> lk(mu); first = !seen[i]; seen[i] = true; }
            if (first) JLog("JNIEnv slot " + std::to_string(i) + " is not emulated (returns 0)");
            c.ret(0);
        });
        m.write<uint32_t>(env_tab + 4u * uint32_t(i), h.Function(name));
    }
    auto slot = [&](int i, HleFn fn) { h.Register("JNIEnv#" + std::to_string(i), std::move(fn)); };
    auto with_env = [](auto fn) {  // wraps a handler so that it gets the host env (or returns 0 when no VM is available)
        return [fn](CallCtx& c) {
            JNIEnv* e = Env();
            if (!e) { c.ret(0); return; }
            fn(c, e);
        };
    };

    // ---- basics ----
    slot(4, with_env([](CallCtx& c, JNIEnv* e) { c.ret(uint32_t(e->GetVersion())); }));
    slot(6, with_env([&m](CallCtx& c, JNIEnv* e) {  // FindClass
        const std::string name = m.cstr(c.arg(1));
        jclass k = e->FindClass(name.c_str());
        if (e->ExceptionCheck()) { e->ExceptionClear(); JLog("FindClass(" + name + ") failed"); c.ret(0); return; }
        JLog("FindClass(" + name + ")");
        c.ret(WrapLocal(e, k));
    }));
    slot(10, with_env([](CallCtx& c, JNIEnv* e) { c.ret(WrapLocal(e, e->GetSuperclass(static_cast<jclass>(Unwrap(c.arg(1)))))); }));
    slot(31, with_env([](CallCtx& c, JNIEnv* e) { c.ret(WrapLocal(e, e->GetObjectClass(Unwrap(c.arg(1))))); }));
    slot(32, with_env([](CallCtx& c, JNIEnv* e) { c.ret(e->IsInstanceOf(Unwrap(c.arg(1)), static_cast<jclass>(Unwrap(c.arg(2))))); }));
    slot(24, with_env([](CallCtx& c, JNIEnv* e) { c.ret(e->IsSameObject(Unwrap(c.arg(1)), Unwrap(c.arg(2)))); }));
    for (int i : {21, 25, 226})  // NewGlobalRef / NewLocalRef / NewWeakGlobalRef
        slot(i, with_env([](CallCtx& c, JNIEnv* e) {
            jobject o = Unwrap(c.arg(1));
            jobject g = o ? e->NewGlobalRef(o) : nullptr;
            c.ret(g ? g_objs.Put(g) : 0u);
        }));
    for (int i : {22, 23, 227})  // DeleteGlobalRef / DeleteLocalRef / DeleteWeakGlobalRef
        slot(i, with_env([](CallCtx& c, JNIEnv* e) {
            if (jobject o = Unwrap(c.arg(1))) { e->DeleteGlobalRef(o); g_objs.Erase(c.arg(1)); }
            c.ret(0);
        }));
    slot(19, [](CallCtx& c) { c.ret(0); });            // PushLocalFrame
    slot(20, [](CallCtx& c) { c.ret(c.arg(1)); });     // PopLocalFrame
    slot(26, [](CallCtx& c) { c.ret(0); });            // EnsureLocalCapacity
    for (int i : {217, 218}) slot(i, [](CallCtx& c) { c.ret(0); });  // MonitorEnter / MonitorExit
    slot(219, [&m, vm](CallCtx& c) { if (c.arg(1)) m.write<uint32_t>(c.arg(1), vm); c.ret(0); });  // GetJavaVM
    slot(232, [](CallCtx& c) { c.ret(1); });           // GetObjectRefType: local
    slot(215, [&m](CallCtx& c) {                       // RegisterNatives(cls, methods, n): Java->guest calls are not supported yet
        for (uint32_t k = 0; k < c.arg(3); ++k) {
            const uint32_t p = c.arg(2) + 12 * k;
            JLog("RegisterNatives: " + m.cstr(m.read<uint32_t>(p)) + m.cstr(m.read<uint32_t>(p + 4)) + " (not callable from Java yet)");
        }
        c.ret(0);
    });
    slot(216, [](CallCtx& c) { c.ret(0); });           // UnregisterNatives

    // ---- exceptions ----
    slot(15, [](CallCtx& c) { c.ret(t_exception ? 0x7AF00010u : 0u); });       // ExceptionOccurred
    slot(16, [](CallCtx& c) { c.ret(0); });                                     // ExceptionDescribe
    slot(17, [](CallCtx& c) { t_exception = false; if (JNIEnv* e = Env()) e->ExceptionClear(); c.ret(0); });  // ExceptionClear
    slot(228, [](CallCtx& c) { JNIEnv* e = Env(); c.ret(t_exception || (e && e->ExceptionCheck()) ? 1u : 0u); });  // ExceptionCheck
    slot(14, with_env([&m](CallCtx& c, JNIEnv* e) {    // ThrowNew(cls, msg)
        e->ThrowNew(static_cast<jclass>(Unwrap(c.arg(1))), m.cstr(c.arg(2)).c_str());
        e->ExceptionClear();
        t_exception = true;
        c.ret(0);
    }));
    slot(18, [&h, &m](CallCtx& c) { h.Fatal("JNI FatalError: " + m.cstr(c.arg(1))); });

    // ---- method / field ids ----
    auto get_id = [&m, &slot](int idx, bool is_static, bool is_field) {
        slot(idx, [&m, is_static, is_field](CallCtx& c) {  // (env, class, name, sig)
            JNIEnv* e = Env();
            jclass k = static_cast<jclass>(Unwrap(c.arg(1)));
            if (!e || !k) { c.ret(0); return; }
            const std::string name = m.cstr(c.arg(2)), sig = m.cstr(c.arg(3));
            auto* mem = new Member;
            mem->sig = sig;
            mem->desc = name + sig;
            if (is_field) mem->fid = is_static ? e->GetStaticFieldID(k, name.c_str(), sig.c_str()) : e->GetFieldID(k, name.c_str(), sig.c_str());
            else mem->mid = is_static ? e->GetStaticMethodID(k, name.c_str(), sig.c_str()) : e->GetMethodID(k, name.c_str(), sig.c_str());
            if (e->ExceptionCheck()) { e->ExceptionClear(); JLog("not found: " + mem->desc); delete mem; c.ret(0); return; }
            JLog(std::string(is_field ? "field " : "method ") + (is_static ? "[static] " : "") + mem->desc);
            c.ret(g_members.Put(mem));
        });
    };
    get_id(33, false, false);
    get_id(94, false, true);
    get_id(113, true, false);
    get_id(144, true, true);

    // ---- calls: Call<T>Method[V|A] (34..63), CallNonvirtual (64..93), CallStatic (114..143), New/AllocObject (27..30) ----
    auto make_call = [&m](int type, int variant, int kind) {
        return [&m, type, variant, kind](CallCtx& c) {
            JNIEnv* e = Env();
            uint32_t obj_h = 0, cls_h = 0, mid_h;
            int first;
            if (kind == 0) { obj_h = c.arg(1); mid_h = c.arg(2); first = 3; }
            else if (kind == 1) { obj_h = c.arg(1); cls_h = c.arg(2); mid_h = c.arg(3); first = 4; }
            else { cls_h = c.arg(1); mid_h = c.arg(2); first = 3; }
            Member* mem = g_members.GetOr(mid_h, nullptr);
            if (!e || !mem || !mem->mid) { JLog("call with an unknown method id 0x" + std::to_string(mid_h)); c.ret(0); return; }
            std::vector<jvalue> jv = Decode(m, ParseSig(mem->sig), variant, c, first);
            jobject o = Unwrap(obj_h);
            jclass cls = static_cast<jclass>(Unwrap(cls_h));
            JLog("call " + mem->desc);
            const jvalue* a = jv.data();
            const jmethodID mid = mem->mid;
#define T64_CALL(IDX, JT, NAME, ASSIGN)                                                                                                  \
    case IDX: {                                                                                                                          \
        JT r = kind == 0 ? e->Call##NAME##MethodA(o, mid, a) : kind == 1 ? e->CallNonvirtual##NAME##MethodA(o, cls, mid, a)               \
                                                                : e->CallStatic##NAME##MethodA(cls, mid, a);                              \
        if (CheckException(e, mem->desc)) { c.ret(0); break; }                                                                            \
        ASSIGN;                                                                                                                           \
        break;                                                                                                                            \
    }
            switch (type) {
                T64_CALL(0, jobject, Object, LogStringResult(e, r, mem->desc); c.ret(WrapLocal(e, r)))
                T64_CALL(1, jboolean, Boolean, c.ret(uint32_t(r)))
                T64_CALL(2, jbyte, Byte, c.ret(uint32_t(int32_t(r))))
                T64_CALL(3, jchar, Char, c.ret(uint32_t(r)))
                T64_CALL(4, jshort, Short, c.ret(uint32_t(int32_t(r))))
                T64_CALL(5, jint, Int, c.ret(uint32_t(r)))
                T64_CALL(6, jlong, Long, c.ret64(uint64_t(r)))
                T64_CALL(7, jfloat, Float, c.retf(r))
                T64_CALL(8, jdouble, Double, c.retd(r))
                default:
                    if (kind == 0) e->CallVoidMethodA(o, mid, a);
                    else if (kind == 1) e->CallNonvirtualVoidMethodA(o, cls, mid, a);
                    else e->CallStaticVoidMethodA(cls, mid, a);
                    CheckException(e, mem->desc);
                    c.ret(0);
                    break;
            }
#undef T64_CALL
        };
    };
    for (int t = 0; t < 10; ++t)
        for (int v = 0; v < 3; ++v) {
            slot(34 + 3 * t + v, make_call(t, v, 0));
            slot(64 + 3 * t + v, make_call(t, v, 1));
            slot(114 + 3 * t + v, make_call(t, v, 2));
        }
    slot(27, with_env([](CallCtx& c, JNIEnv* e) { c.ret(WrapLocal(e, e->AllocObject(static_cast<jclass>(Unwrap(c.arg(1)))))); }));
    for (int v = 0; v < 3; ++v)
        slot(28 + v, [&m, v](CallCtx& c) {  // NewObject(cls, mid, ...)
            JNIEnv* e = Env();
            Member* mem = g_members.GetOr(c.arg(2), nullptr);
            if (!e || !mem || !mem->mid) { c.ret(0); return; }
            std::vector<jvalue> jv = Decode(m, ParseSig(mem->sig), v, c, 3);
            JLog("new " + mem->desc);
            jobject o = e->NewObjectA(static_cast<jclass>(Unwrap(c.arg(1))), mem->mid, jv.data());
            if (CheckException(e, mem->desc)) { c.ret(0); return; }
            c.ret(WrapLocal(e, o));
        });

    // ---- fields: Get<T>Field 95.., Set<T>Field 104.., GetStatic<T>Field 145.., SetStatic<T>Field 154.. ----
    auto field_get = [](int type, bool is_static) {
        return [type, is_static](CallCtx& c) {
            JNIEnv* e = Env();
            Member* mem = g_members.GetOr(c.arg(2), nullptr);
            if (!e || !mem || !mem->fid) { c.ret(0); return; }
            jobject o = Unwrap(c.arg(1));
            jclass k = static_cast<jclass>(o);
            const jfieldID f = mem->fid;
            switch (type) {
                case 0: c.ret(WrapLocal(e, is_static ? e->GetStaticObjectField(k, f) : e->GetObjectField(o, f))); break;
                case 1: c.ret(is_static ? e->GetStaticBooleanField(k, f) : e->GetBooleanField(o, f)); break;
                case 2: c.ret(uint32_t(int32_t(is_static ? e->GetStaticByteField(k, f) : e->GetByteField(o, f)))); break;
                case 3: c.ret(is_static ? e->GetStaticCharField(k, f) : e->GetCharField(o, f)); break;
                case 4: c.ret(uint32_t(int32_t(is_static ? e->GetStaticShortField(k, f) : e->GetShortField(o, f)))); break;
                case 5: c.ret(uint32_t(is_static ? e->GetStaticIntField(k, f) : e->GetIntField(o, f))); break;
                case 6: c.ret64(uint64_t(is_static ? e->GetStaticLongField(k, f) : e->GetLongField(o, f))); break;
                case 7: c.retf(is_static ? e->GetStaticFloatField(k, f) : e->GetFloatField(o, f)); break;
                default: c.retd(is_static ? e->GetStaticDoubleField(k, f) : e->GetDoubleField(o, f)); break;
            }
        };
    };
    auto field_set = [](int type, bool is_static) {
        return [type, is_static](CallCtx& c) {
            JNIEnv* e = Env();
            Member* mem = g_members.GetOr(c.arg(2), nullptr);
            if (!e || !mem || !mem->fid) { c.ret(0); return; }
            jobject o = Unwrap(c.arg(1));
            jclass k = static_cast<jclass>(o);
            const jfieldID f = mem->fid;
            switch (type) {
                case 0: { jobject v = Unwrap(c.arg(3)); if (is_static) e->SetStaticObjectField(k, f, v); else e->SetObjectField(o, f, v); break; }
                case 1: { jboolean v = (c.arg(3) & 0xFF) != 0; if (is_static) e->SetStaticBooleanField(k, f, v); else e->SetBooleanField(o, f, v); break; }
                case 2: { jbyte v = jbyte(c.arg(3)); if (is_static) e->SetStaticByteField(k, f, v); else e->SetByteField(o, f, v); break; }
                case 3: { jchar v = jchar(c.arg(3)); if (is_static) e->SetStaticCharField(k, f, v); else e->SetCharField(o, f, v); break; }
                case 4: { jshort v = jshort(c.arg(3)); if (is_static) e->SetStaticShortField(k, f, v); else e->SetShortField(o, f, v); break; }
                case 5: { jint v = jint(c.arg(3)); if (is_static) e->SetStaticIntField(k, f, v); else e->SetIntField(o, f, v); break; }
                case 6: { jlong v = jlong(c.arg64(4)); if (is_static) e->SetStaticLongField(k, f, v); else e->SetLongField(o, f, v); break; }
                case 7: { jfloat v = c.argf(3); if (is_static) e->SetStaticFloatField(k, f, v); else e->SetFloatField(o, f, v); break; }
                default: { jdouble v = c.argd(4); if (is_static) e->SetStaticDoubleField(k, f, v); else e->SetDoubleField(o, f, v); break; }
            }
            c.ret(0);
        };
    };
    for (int t = 0; t < 9; ++t) {
        slot(95 + t, field_get(t, false));
        slot(104 + t, field_set(t, false));
        slot(145 + t, field_get(t, true));
        slot(154 + t, field_set(t, true));
    }

    // ---- strings ----
    slot(167, with_env([&m](CallCtx& c, JNIEnv* e) {  // NewStringUTF
        const std::string s = m.cstr(c.arg(1));
        JLog("NewStringUTF(\"" + s.substr(0, 80) + "\")");
        c.ret(WrapLocal(e, e->NewStringUTF(s.c_str())));
    }));
    slot(164, with_env([](CallCtx& c, JNIEnv* e) { c.ret(uint32_t(e->GetStringLength(static_cast<jstring>(Unwrap(c.arg(1)))))); }));
    slot(168, with_env([](CallCtx& c, JNIEnv* e) { c.ret(uint32_t(e->GetStringUTFLength(static_cast<jstring>(Unwrap(c.arg(1)))))); }));
    slot(169, with_env([&h, &m](CallCtx& c, JNIEnv* e) {  // GetStringUTFChars(str, isCopy*) -> guest copy
        jstring js = static_cast<jstring>(Unwrap(c.arg(1)));
        if (c.arg(2)) m.write<uint8_t>(c.arg(2), 1);
        if (!js) { c.ret(0); return; }
        const char* s = e->GetStringUTFChars(js, nullptr);
        const uint32_t p = s ? PutGuestString(h, s) : 0u;
        if (s) e->ReleaseStringUTFChars(js, s);
        c.ret(p);
    }));
    slot(170, [&h](CallCtx& c) { h.Free(c.arg(2)); c.ret(0); });  // ReleaseStringUTFChars(str, chars)
    slot(165, with_env([&h, &m](CallCtx& c, JNIEnv* e) {          // GetStringChars -> UTF-16 guest copy
        jstring js = static_cast<jstring>(Unwrap(c.arg(1)));
        if (c.arg(2)) m.write<uint8_t>(c.arg(2), 1);
        if (!js) { c.ret(0); return; }
        const jsize n = e->GetStringLength(js);
        const jchar* s = e->GetStringChars(js, nullptr);
        const uint32_t p = h.Alloc(uint32_t(n + 1) * 2);
        if (p && s) { std::memcpy(m.host(p), s, size_t(n) * 2); m.write<uint16_t>(p + uint32_t(n) * 2, 0); }
        if (s) e->ReleaseStringChars(js, s);
        c.ret(p);
    }));
    slot(166, [&h](CallCtx& c) { h.Free(c.arg(2)); c.ret(0); });
    slot(163, with_env([&m](CallCtx& c, JNIEnv* e) {  // NewString(chars, len)
        const uint8_t* p = m.hostp(c.arg(1), size_t(c.arg(2)) * 2);
        c.ret(p ? WrapLocal(e, e->NewString(reinterpret_cast<const jchar*>(p), jsize(c.arg(2)))) : 0u);
    }));

    // ---- arrays ----
    slot(171, with_env([](CallCtx& c, JNIEnv* e) { c.ret(uint32_t(e->GetArrayLength(static_cast<jarray>(Unwrap(c.arg(1)))))); }));
    slot(172, with_env([](CallCtx& c, JNIEnv* e) {  // NewObjectArray(len, cls, init)
        c.ret(WrapLocal(e, e->NewObjectArray(jsize(c.arg(1)), static_cast<jclass>(Unwrap(c.arg(2))), Unwrap(c.arg(3)))));
    }));
    slot(173, with_env([](CallCtx& c, JNIEnv* e) { c.ret(WrapLocal(e, e->GetObjectArrayElement(static_cast<jobjectArray>(Unwrap(c.arg(1))), jsize(c.arg(2))))); }));
    slot(174, with_env([](CallCtx& c, JNIEnv* e) { e->SetObjectArrayElement(static_cast<jobjectArray>(Unwrap(c.arg(1))), jsize(c.arg(2)), Unwrap(c.arg(3))); c.ret(0); }));
    for (int t = 0; t < 8; ++t) {
        slot(175 + t, with_env([t](CallCtx& c, JNIEnv* e) {  // New<Prim>Array(len)
            const jsize n = jsize(c.arg(1));
            jarray a = nullptr;
            switch (t) {
                case 0: a = e->NewBooleanArray(n); break;
                case 1: a = e->NewByteArray(n); break;
                case 2: a = e->NewCharArray(n); break;
                case 3: a = e->NewShortArray(n); break;
                case 4: a = e->NewIntArray(n); break;
                case 5: a = e->NewLongArray(n); break;
                case 6: a = e->NewFloatArray(n); break;
                default: a = e->NewDoubleArray(n); break;
            }
            c.ret(WrapLocal(e, a));
        }));
        // Get<Prim>ArrayElements(arr, isCopy*): a guest copy of the whole array
        slot(183 + t, with_env([&h, &m, t](CallCtx& c, JNIEnv* e) {
            jarray a = static_cast<jarray>(Unwrap(c.arg(1)));
            if (c.arg(2)) m.write<uint8_t>(c.arg(2), 1);
            if (!a) { c.ret(0); return; }
            const size_t bytes = size_t(e->GetArrayLength(a)) * kElemSize[t];
            const uint32_t p = h.Alloc(uint32_t(bytes) + 16);
            void* src = e->GetPrimitiveArrayCritical(a, nullptr);
            if (p && src) std::memcpy(m.host(p), src, bytes);
            if (src) e->ReleasePrimitiveArrayCritical(a, src, JNI_ABORT);
            c.ret(p);
        }));
        // Release<Prim>ArrayElements(arr, elems, mode): 0 copy back + free, 1 (JNI_COMMIT) copy back, 2 (JNI_ABORT) free
        slot(191 + t, with_env([&h, &m, t](CallCtx& c, JNIEnv* e) {
            jarray a = static_cast<jarray>(Unwrap(c.arg(1)));
            const uint32_t p = c.arg(2), mode = c.arg(3);
            if (a && p && mode != 2) {
                const size_t bytes = size_t(e->GetArrayLength(a)) * kElemSize[t];
                void* dst = e->GetPrimitiveArrayCritical(a, nullptr);
                if (dst) { std::memcpy(dst, m.host(p), bytes); e->ReleasePrimitiveArrayCritical(a, dst, 0); }
            }
            if (mode != 1) h.Free(p);
            c.ret(0);
        }));
        // Get<Prim>ArrayRegion(arr, start, len, buf)
        slot(199 + t, with_env([&m, t](CallCtx& c, JNIEnv* e) {
            jarray a = static_cast<jarray>(Unwrap(c.arg(1)));
            const size_t es = kElemSize[t], start = c.arg(2), len = c.arg(3);
            uint8_t* dst = m.hostp(c.arg(4), len * es);
            void* src = a ? e->GetPrimitiveArrayCritical(a, nullptr) : nullptr;
            if (src && dst) std::memcpy(dst, static_cast<uint8_t*>(src) + start * es, len * es);
            if (src) e->ReleasePrimitiveArrayCritical(a, src, JNI_ABORT);
            c.ret(0);
        }));
        // Set<Prim>ArrayRegion(arr, start, len, buf)
        slot(207 + t, with_env([&m, t](CallCtx& c, JNIEnv* e) {
            jarray a = static_cast<jarray>(Unwrap(c.arg(1)));
            const size_t es = kElemSize[t], start = c.arg(2), len = c.arg(3);
            const uint8_t* srcg = m.hostp(c.arg(4), len * es);
            void* dst = a ? e->GetPrimitiveArrayCritical(a, nullptr) : nullptr;
            if (dst && srcg) std::memcpy(static_cast<uint8_t*>(dst) + start * es, srcg, len * es);
            if (dst) e->ReleasePrimitiveArrayCritical(a, dst, 0);
            c.ret(0);
        }));
    }

    // ---- JNIInvokeInterface: 3 DestroyJavaVM, 4 AttachCurrentThread, 5 DetachCurrentThread, 6 GetEnv, 7 AttachCurrentThreadAsDaemon ----
    auto vslot = [&](int i, HleFn fn) {
        const std::string name = "JavaVM#" + std::to_string(i);
        h.Register(name, std::move(fn));
        m.write<uint32_t>(vm_tab + 4u * uint32_t(i), h.Function(name));
    };
    for (int i = 0; i < 4; ++i) vslot(i, [](CallCtx& c) { c.ret(0); });
    auto get_env = [&m, env](CallCtx& c) {
        Env();  // make sure this host thread is attached to the VM
        if (c.arg(1)) m.write<uint32_t>(c.arg(1), env);
        c.ret(0);
    };
    vslot(4, get_env);
    vslot(5, [](CallCtx& c) { JniThreadExit(); c.ret(0); });
    vslot(6, get_env);
    vslot(7, get_env);
    *vm_out = vm;
    *env_out = env;
}

}  // namespace t64
