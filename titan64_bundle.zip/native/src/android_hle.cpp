#include "android_hle.h"

#include <android/asset_manager.h>
#include <android/configuration.h>
#include <android/input.h>
#include <android/looper.h>
#include <android/native_window.h>

#include <atomic>
#include <cstring>

#include "handles.h"
#include "host_gl.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {
namespace {
HandleMap<ANativeWindow*> g_windows(0x7B000000u);
HandleMap<AAsset*> g_assets(0x7B100000u);
HandleMap<AConfiguration*> g_configs(0x7B200000u);
HandleMap<AInputEvent*> g_events(0x7B300000u);
HandleMap<AInputQueue*> g_queues(0x7B400000u);
HandleMap<ALooper*> g_loopers(0x7B500000u);
HandleMap<AAssetManager*> g_mgrs(0x7B600000u);
}  // namespace

AndroidBridge& Bridge() {
    static AndroidBridge b;
    return b;
}
uint32_t AndroidBridge::WrapWindow(ANativeWindow* w) { return w ? g_windows.Put(w) : 0; }
uint32_t AndroidBridge::WrapAssetManager(AAssetManager* m) { return m ? g_mgrs.Put(m) : 0; }
uint32_t AndroidBridge::WrapInputQueue(AInputQueue* q) { return q ? g_queues.Put(q) : 0; }
ANativeWindow* AndroidBridge::Window(uint32_t h) { return g_windows.GetOr(h, nullptr); }
void AndroidBridge::ForgetWindow(uint32_t h) { g_windows.Erase(h); }
void AndroidBridge::ForgetInputQueue(uint32_t h) { g_queues.Erase(h); }

void RegisterAndroid(Hle& h) {
    GuestMemory& m = h.mem;

    // ---- ANativeWindow ----
    h.Register("ANativeWindow_setBuffersGeometry", [](CallCtx& c) {
        ANativeWindow* w = Bridge().Window(c.arg(0));
        if (w && w == Gl().window()) { c.ret(0); return; }  // the app's EGL surface is already configured (same visual id)
        c.ret(w ? uint32_t(ANativeWindow_setBuffersGeometry(w, int32_t(c.arg(1)), int32_t(c.arg(2)), int32_t(c.arg(3)))) : 0xFFFFFFFFu);
    });

    // ---- assets (the game's data lives inside the APK) ----
    h.Register("AAssetManager_open", [](CallCtx& c) {
        AAssetManager* mgr = g_mgrs.GetOr(c.arg(0), Bridge().assets);
        const std::string name = c.mem.cstr(c.arg(1));
        AAsset* a = mgr ? AAssetManager_open(mgr, name.c_str(), int(c.arg(2))) : nullptr;
        static std::atomic<int> oks{0};
        if (!a) Logf("[asset] open failed: %s", name.c_str());
        else if (oks++ < 40) Logf("[asset] open ok: %s (%d bytes)", name.c_str(), int(AAsset_getLength(a)));
        c.ret(a ? g_assets.Put(a) : 0u);
    });
    h.Register("AAsset_read", [&m](CallCtx& c) {
        AAsset* a = g_assets.GetOr(c.arg(0), nullptr);
        uint8_t* d = m.hostp(c.arg(1), c.arg(2));
        c.ret(a && (d || !c.arg(2)) ? uint32_t(AAsset_read(a, d, c.arg(2))) : 0xFFFFFFFFu);
    });
    h.Register("AAsset_seek", [](CallCtx& c) {
        AAsset* a = g_assets.GetOr(c.arg(0), nullptr);
        c.ret(a ? uint32_t(int32_t(AAsset_seek(a, off_t(int32_t(c.arg(1))), int(c.arg(2))))) : 0xFFFFFFFFu);
    });
    h.Register("AAsset_getLength", [](CallCtx& c) {
        AAsset* a = g_assets.GetOr(c.arg(0), nullptr);
        c.ret(a ? uint32_t(int32_t(AAsset_getLength(a))) : 0u);
    });
    h.Register("AAsset_close", [](CallCtx& c) {
        if (AAsset* a = g_assets.GetOr(c.arg(0), nullptr)) AAsset_close(a);
        g_assets.Erase(c.arg(0));
        c.ret(0);
    });

    // ---- AConfiguration ----
    h.Register("AConfiguration_new", [](CallCtx& c) { c.ret(g_configs.Put(AConfiguration_new())); });
    h.Register("AConfiguration_delete", [](CallCtx& c) {
        if (AConfiguration* cf = g_configs.GetOr(c.arg(0), nullptr)) AConfiguration_delete(cf);
        g_configs.Erase(c.arg(0));
        c.ret(0);
    });
    h.Register("AConfiguration_fromAssetManager", [](CallCtx& c) {
        AConfiguration* cf = g_configs.GetOr(c.arg(0), nullptr);
        AAssetManager* mgr = g_mgrs.GetOr(c.arg(1), Bridge().assets);
        if (cf && mgr) AConfiguration_fromAssetManager(cf, mgr);
        c.ret(0);
    });
    h.Register("AConfiguration_getLanguage", [&m](CallCtx& c) {
        char buf[4] = {};
        if (AConfiguration* cf = g_configs.GetOr(c.arg(0), nullptr)) AConfiguration_getLanguage(cf, buf);
        if (uint8_t* d = m.hostp(c.arg(1), 2)) std::memcpy(d, buf, 2);
        c.ret(0);
    });
    h.Register("AConfiguration_getCountry", [&m](CallCtx& c) {
        char buf[4] = {};
        if (AConfiguration* cf = g_configs.GetOr(c.arg(0), nullptr)) AConfiguration_getCountry(cf, buf);
        if (uint8_t* d = m.hostp(c.arg(1), 2)) std::memcpy(d, buf, 2);
        c.ret(0);
    });

    // ---- ALooper: the guest uses the REAL host looper of its thread; fds and `data` pointers pass straight through ----
    h.Register("ALooper_prepare", [](CallCtx& c) { c.ret(g_loopers.Put(ALooper_prepare(int(c.arg(0))))); });
    h.Register("ALooper_addFd", [](CallCtx& c) {
        if (c.arg(4)) Logf("[android] ALooper_addFd: callbacks are not supported, polling the ident instead");
        ALooper* l = g_loopers.GetOr(c.arg(0), ALooper_forThread());
        const int r = ALooper_addFd(l, int(c.arg(1)), int(c.arg(2)), int(c.arg(3)), nullptr,
                                    reinterpret_cast<void*>(static_cast<uintptr_t>(c.arg(5))));
        c.ret(uint32_t(r));
    });
    h.Register("ALooper_pollAll", [&h, &m](CallCtx& c) {
        const int timeout = int(c.arg(0));
        int fd = 0, events = 0, id;
        void* data = nullptr;
        for (;;) {  // an infinite wait is sliced so that a fatal error can stop the thread
            id = ALooper_pollOnce(timeout < 0 ? 250 : timeout, &fd, &events, &data);  // pollAll is unavailable in current NDKs
            if (id == ALOOPER_POLL_TIMEOUT && timeout < 0 && !h.fatal) continue;
            break;
        }
        if (id >= 0) {
            if (c.arg(1)) m.write<int32_t>(c.arg(1), fd);
            if (c.arg(2)) m.write<int32_t>(c.arg(2), events);
            if (c.arg(3)) m.write<uint32_t>(c.arg(3), uint32_t(reinterpret_cast<uintptr_t>(data)));
        }
        c.ret(uint32_t(id));
    });

    // ---- AInputQueue / AInputEvent ----
    h.Register("AInputQueue_attachLooper", [](CallCtx& c) {
        AInputQueue* q = g_queues.GetOr(c.arg(0), nullptr);
        ALooper* l = g_loopers.GetOr(c.arg(1), ALooper_forThread());
        if (q) AInputQueue_attachLooper(q, l, int(c.arg(2)), nullptr, reinterpret_cast<void*>(static_cast<uintptr_t>(c.arg(4))));
        c.ret(0);
    });
    h.Register("AInputQueue_detachLooper", [](CallCtx& c) {
        if (AInputQueue* q = g_queues.GetOr(c.arg(0), nullptr)) AInputQueue_detachLooper(q);
        c.ret(0);
    });
    h.Register("AInputQueue_getEvent", [&m](CallCtx& c) {
        AInputQueue* q = g_queues.GetOr(c.arg(0), nullptr);
        AInputEvent* ev = nullptr;
        const int32_t r = q ? AInputQueue_getEvent(q, &ev) : -1;
        if (r >= 0 && ev && c.arg(1)) m.write<uint32_t>(c.arg(1), g_events.Put(ev));
        c.ret(uint32_t(r));
    });
    h.Register("AInputQueue_preDispatchEvent", [](CallCtx& c) {
        AInputQueue* q = g_queues.GetOr(c.arg(0), nullptr);
        AInputEvent* ev = g_events.GetOr(c.arg(1), nullptr);
        c.ret(q && ev ? uint32_t(AInputQueue_preDispatchEvent(q, ev)) : 0u);
    });
    h.Register("AInputQueue_finishEvent", [](CallCtx& c) {
        AInputQueue* q = g_queues.GetOr(c.arg(0), nullptr);
        AInputEvent* ev = g_events.GetOr(c.arg(1), nullptr);
        if (q && ev) AInputQueue_finishEvent(q, ev, int(c.arg(2)));
        g_events.Erase(c.arg(1));
        c.ret(0);
    });
    h.Register("AInputEvent_getType", [](CallCtx& c) { AInputEvent* e = g_events.GetOr(c.arg(0), nullptr); c.ret(e ? uint32_t(AInputEvent_getType(e)) : 0u); });
    h.Register("AInputEvent_getSource", [](CallCtx& c) { AInputEvent* e = g_events.GetOr(c.arg(0), nullptr); c.ret(e ? uint32_t(AInputEvent_getSource(e)) : 0u); });
    h.Register("AKeyEvent_getAction", [](CallCtx& c) { AInputEvent* e = g_events.GetOr(c.arg(0), nullptr); c.ret(e ? uint32_t(AKeyEvent_getAction(e)) : 0u); });
    h.Register("AKeyEvent_getKeyCode", [](CallCtx& c) { AInputEvent* e = g_events.GetOr(c.arg(0), nullptr); c.ret(e ? uint32_t(AKeyEvent_getKeyCode(e)) : 0u); });
    h.Register("AMotionEvent_getAction", [](CallCtx& c) { AInputEvent* e = g_events.GetOr(c.arg(0), nullptr); c.ret(e ? uint32_t(AMotionEvent_getAction(e)) : 0u); });
    h.Register("AMotionEvent_getPointerCount", [](CallCtx& c) { AInputEvent* e = g_events.GetOr(c.arg(0), nullptr); c.ret(e ? uint32_t(AMotionEvent_getPointerCount(e)) : 0u); });
    h.Register("AMotionEvent_getAxisValue", [](CallCtx& c) {
        AInputEvent* e = g_events.GetOr(c.arg(0), nullptr);
        c.retf(e ? AMotionEvent_getAxisValue(e, int32_t(c.arg(1)), c.arg(2)) : 0.0f);
    });
}

}  // namespace t64
