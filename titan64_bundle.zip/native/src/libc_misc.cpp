// Remaining libc pieces: number parsing, wide characters, sscanf, regex, qsort, setjmp/longjmp,
// locale, process termination and the (stubbed) C++ exception unwinder.
#include <regex.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <cwchar>
#include <cwctype>
#include <numeric>
#include <string>
#include <vector>

#include "handles.h"
#include "hle.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {
namespace {

constexpr uint32_t kEOF = 0xFFFFFFFFu;

// ---- sscanf engine (subset: %d %i %u %x %X %o %p %f %e %g %s %c %[...] %n %%, widths, h/hh/l/ll, '*') ----
uint32_t DoScan(GuestMemory& m, const std::string& in, const std::string& fmt, ArgSrc& args) {
    size_t ip = 0;
    int assigned = 0;
    bool any_conversion = false;
    auto store_int = [&](uint32_t dst, int lmod, long long v) {
        if (!dst) return;
        if (lmod == -2) m.write<uint8_t>(dst, uint8_t(v));
        else if (lmod == -1) m.write<uint16_t>(dst, uint16_t(v));
        else if (lmod == 2) m.write<uint64_t>(dst, uint64_t(v));
        else m.write<uint32_t>(dst, uint32_t(v));
    };
    for (size_t fp = 0; fp < fmt.size();) {
        const char f = fmt[fp];
        if (std::isspace(static_cast<unsigned char>(f))) {
            while (ip < in.size() && std::isspace(static_cast<unsigned char>(in[ip]))) ++ip;
            ++fp;
            continue;
        }
        if (f != '%') {
            if (ip < in.size() && in[ip] == f) { ++ip; ++fp; continue; }
            if (ip >= in.size() && !any_conversion) return kEOF;
            break;
        }
        ++fp;
        if (fp >= fmt.size()) break;
        if (fmt[fp] == '%') {
            while (ip < in.size() && std::isspace(static_cast<unsigned char>(in[ip]))) ++ip;
            if (ip < in.size() && in[ip] == '%') { ++ip; ++fp; continue; }
            break;
        }
        bool suppress = false;
        if (fmt[fp] == '*') { suppress = true; ++fp; }
        size_t width = 0;
        while (fp < fmt.size() && std::isdigit(static_cast<unsigned char>(fmt[fp]))) width = width * 10 + size_t(fmt[fp++] - '0');
        int lmod = 0;  // -2 hh, -1 h, 0 none, 1 l, 2 ll
        while (fp < fmt.size() && std::strchr("hlLzjt", fmt[fp])) {
            const char ch = fmt[fp++];
            if (ch == 'h') lmod = (lmod == -1) ? -2 : -1;
            else if (ch == 'l' || ch == 'L') lmod = (lmod >= 1) ? 2 : 1;
            else lmod = 1;
        }
        if (fp >= fmt.size()) break;
        const char cv = fmt[fp++];
        if (cv == 'n') {
            if (!suppress) store_int(args.u32(), lmod, static_cast<long long>(ip));
            continue;
        }
        if (cv != 'c' && cv != '[')
            while (ip < in.size() && std::isspace(static_cast<unsigned char>(in[ip]))) ++ip;
        if (ip >= in.size()) return assigned ? uint32_t(assigned) : (any_conversion ? uint32_t(assigned) : kEOF);
        any_conversion = true;
        const std::string rest = in.substr(ip, width ? width : std::string::npos);
        switch (cv) {
            case 'd': case 'i': case 'u': case 'x': case 'X': case 'o': case 'p': {
                const int base = (cv == 'd' || cv == 'u') ? 10 : cv == 'i' ? 0 : cv == 'o' ? 8 : 16;
                char* end = nullptr;
                const long long v = (cv == 'u' || cv == 'x' || cv == 'X' || cv == 'o' || cv == 'p')
                                        ? static_cast<long long>(std::strtoull(rest.c_str(), &end, base))
                                        : std::strtoll(rest.c_str(), &end, base);
                if (end == rest.c_str()) return uint32_t(assigned);
                ip += size_t(end - rest.c_str());
                if (!suppress) { store_int(args.u32(), lmod, v); ++assigned; }
                break;
            }
            case 'f': case 'F': case 'e': case 'E': case 'g': case 'G': case 'a': {
                char* end = nullptr;
                const double v = std::strtod(rest.c_str(), &end);
                if (end == rest.c_str()) return uint32_t(assigned);
                ip += size_t(end - rest.c_str());
                if (!suppress) {
                    const uint32_t dst = args.u32();
                    if (lmod >= 1) m.write<double>(dst, v);
                    else m.write<float>(dst, float(v));
                    ++assigned;
                }
                break;
            }
            case 's': {
                size_t n = 0;
                while (n < rest.size() && !std::isspace(static_cast<unsigned char>(rest[n]))) ++n;
                if (!suppress) { WriteGuestString(m, args.u32(), rest.substr(0, n)); ++assigned; }
                ip += n;
                break;
            }
            case 'c': {
                const size_t n = std::min(width ? width : size_t(1), in.size() - ip);
                if (!suppress) {
                    const uint32_t dst = args.u32();
                    for (size_t i = 0; i < n; ++i) m.write<uint8_t>(dst + uint32_t(i), uint8_t(in[ip + i]));
                    ++assigned;
                }
                ip += n;
                break;
            }
            case '[': {
                bool neg = false, set[256] = {};
                if (fp < fmt.size() && fmt[fp] == '^') { neg = true; ++fp; }
                bool first = true;
                while (fp < fmt.size() && (fmt[fp] != ']' || first)) {
                    first = false;
                    unsigned char lo = static_cast<unsigned char>(fmt[fp]);
                    if (fp + 2 < fmt.size() && fmt[fp + 1] == '-' && fmt[fp + 2] != ']') {
                        unsigned char hi = static_cast<unsigned char>(fmt[fp + 2]);
                        for (unsigned ch = lo; ch <= hi; ++ch) set[ch] = true;
                        fp += 3;
                    } else { set[lo] = true; ++fp; }
                }
                if (fp < fmt.size()) ++fp;  // ']'
                size_t n = 0;
                while (n < rest.size() && (set[static_cast<unsigned char>(rest[n])] != neg)) ++n;
                if (n == 0) return uint32_t(assigned);
                if (!suppress) { WriteGuestString(m, args.u32(), rest.substr(0, n)); ++assigned; }
                ip += n;
                break;
            }
            default: return uint32_t(assigned);
        }
    }
    return uint32_t(assigned);
}

// ---- UTF-8 helpers (wchar_t is 32 bits on both sides) ----
int Utf8Encode(uint32_t wc, char* out) {
    if (wc < 0x80) { out[0] = char(wc); return 1; }
    if (wc < 0x800) { out[0] = char(0xC0 | (wc >> 6)); out[1] = char(0x80 | (wc & 0x3F)); return 2; }
    if (wc < 0x10000) { out[0] = char(0xE0 | (wc >> 12)); out[1] = char(0x80 | ((wc >> 6) & 0x3F)); out[2] = char(0x80 | (wc & 0x3F)); return 3; }
    out[0] = char(0xF0 | (wc >> 18)); out[1] = char(0x80 | ((wc >> 12) & 0x3F));
    out[2] = char(0x80 | ((wc >> 6) & 0x3F)); out[3] = char(0x80 | (wc & 0x3F));
    return 4;
}

HandleMap<regex_t*> g_regex(0x7C000000u);

}  // namespace

void RegisterMisc(Hle& h) {
    GuestMemory& m = h.mem;

    // ---- number parsing / misc ----
    h.Register("atoi", [&m](CallCtx& c) { c.ret(uint32_t(std::atoi(m.cstr(c.arg(0)).c_str()))); });
    h.Register("atol", [&m](CallCtx& c) { c.ret(uint32_t(int32_t(std::atol(m.cstr(c.arg(0)).c_str())))); });
    h.Register("strtod", [&m](CallCtx& c) {
        const std::string s = m.cstr(c.arg(0));
        char* e = nullptr;
        const double v = std::strtod(s.c_str(), &e);
        if (c.arg(1)) m.write<uint32_t>(c.arg(1), c.arg(0) + uint32_t(e - s.c_str()));
        c.retd(v);
    });
    h.Register("strtoull", [&m](CallCtx& c) {
        const std::string s = m.cstr(c.arg(0));
        char* e = nullptr;
        const unsigned long long v = std::strtoull(s.c_str(), &e, int(c.arg(2)));
        if (c.arg(1)) m.write<uint32_t>(c.arg(1), c.arg(0) + uint32_t(e - s.c_str()));
        c.ret64(v);
    });
    h.Register("strtok", [&m](CallCtx& c) {
        static uint32_t save = 0;
        uint32_t s = c.arg(0) ? c.arg(0) : save;
        const std::string delim = m.cstr(c.arg(1));
        auto is_delim = [&](uint8_t ch) { return delim.find(char(ch)) != std::string::npos; };
        while (s && m.read<uint8_t>(s) && is_delim(m.read<uint8_t>(s))) ++s;
        if (!s || !m.read<uint8_t>(s)) { save = 0; c.ret(0); return; }
        uint32_t e = s;
        while (m.read<uint8_t>(e) && !is_delim(m.read<uint8_t>(e))) ++e;
        if (m.read<uint8_t>(e)) { m.write<uint8_t>(e, 0); save = e + 1; } else save = 0;
        c.ret(s);
    });
    h.Register("strxfrm", [&m](CallCtx& c) {
        const std::string s = m.cstr(c.arg(1));
        if (c.arg(2) > s.size()) WriteGuestString(m, c.arg(0), s);
        c.ret(uint32_t(s.size()));
    });
    h.Register("ldexp", [](CallCtx& c) { c.retd(std::ldexp(c.argd(0), int(int32_t(c.arg(2))))); });
    h.Register("lrand48", [](CallCtx& c) { c.ret(uint32_t(::lrand48() & 0x7FFFFFFF)); });
    h.Register("setlocale", [&h](CallCtx& c) {
        static uint32_t cstr = 0;
        if (!cstr) cstr = PutGuestString(h, "C");
        c.ret(cstr);
    });
    h.Register("sscanf", [&m](CallCtx& c) {
        RegArgs a(c, 2);
        c.ret(DoScan(m, m.cstr(c.arg(0)), m.cstr(c.arg(1)), a));
    });

    // ---- process termination ----
    h.Register("abort", [&h](CallCtx&) { h.Fatal("the game called abort()"); });
    h.Register("exit", [&h](CallCtx& c) { h.Fatal("the game called exit(" + std::to_string(int32_t(c.arg(0))) + ")"); });
    h.Register("raise", [&h](CallCtx& c) { h.Fatal("the game raised signal " + std::to_string(int32_t(c.arg(0)))); c.ret(0); });
    h.Register("__stack_chk_fail", [&h](CallCtx&) { h.Fatal("stack smashing detected (__stack_chk_fail)"); });

    // ---- wide characters ----
    auto wptr = [&m](uint32_t a) { return reinterpret_cast<wchar_t*>(m.hostp(a, 4)); };
    h.Register("wcslen", [wptr](CallCtx& c) { const wchar_t* p = wptr(c.arg(0)); c.ret(p ? uint32_t(::wcslen(p)) : 0u); });
    h.Register("wmemchr", [&m, wptr](CallCtx& c) {
        wchar_t* p = wptr(c.arg(0));
        wchar_t* r = p ? ::wmemchr(p, wchar_t(c.arg(1)), c.arg(2)) : nullptr;
        c.ret(r ? uint32_t(reinterpret_cast<uint8_t*>(r) - m.base()) : 0u);
    });
    h.Register("wmemcmp", [wptr](CallCtx& c) { c.ret(uint32_t(::wmemcmp(wptr(c.arg(0)), wptr(c.arg(1)), c.arg(2)))); });
    auto wmemmove_fn = [&m](CallCtx& c) { if (c.arg(2)) std::memmove(m.host(c.arg(0)), m.host(c.arg(1)), size_t(c.arg(2)) * 4); c.ret(c.arg(0)); };
    h.Register("wmemcpy", wmemmove_fn);
    h.Register("wmemmove", wmemmove_fn);
    h.Register("wmemset", [wptr](CallCtx& c) { if (c.arg(2)) ::wmemset(wptr(c.arg(0)), wchar_t(c.arg(1)), c.arg(2)); c.ret(c.arg(0)); });
    h.Register("wcscoll", [&m](CallCtx& c) {
        uint32_t a = c.arg(0), b = c.arg(1);
        for (;; a += 4, b += 4) {
            const int32_t x = m.read<int32_t>(a), y = m.read<int32_t>(b);
            if (x != y) { c.ret(x < y ? 0xFFFFFFFFu : 1u); return; }
            if (!x) { c.ret(0); return; }
        }
    });
    h.Register("wcsxfrm", [&m](CallCtx& c) {
        uint32_t n = 0;
        while (m.read<uint32_t>(c.arg(1) + 4 * n)) ++n;
        if (c.arg(0) && c.arg(2) > n) std::memcpy(m.host(c.arg(0)), m.host(c.arg(1)), size_t(n + 1) * 4);
        c.ret(n);
    });
    h.Register("towlower", [](CallCtx& c) { c.ret(uint32_t(::towlower(wint_t(c.arg(0))))); });
    h.Register("towupper", [](CallCtx& c) { c.ret(uint32_t(::towupper(wint_t(c.arg(0))))); });
    h.Register("mbrtowc", [&h, &m](CallCtx& c) {  // UTF-8 decoder
        const uint32_t pwc = c.arg(0), s = c.arg(1), n = c.arg(2);
        if (!s) { c.ret(0); return; }
        if (n == 0) { c.ret(0xFFFFFFFEu); return; }
        const uint8_t b0 = m.read<uint8_t>(s);
        uint32_t len = b0 < 0x80 ? 1 : (b0 >> 5) == 6 ? 2 : (b0 >> 4) == 14 ? 3 : (b0 >> 3) == 30 ? 4 : 0;
        if (!len) { h.SetErrno(84); c.ret(kEOF); return; }  // EILSEQ
        if (n < len) { c.ret(0xFFFFFFFEu); return; }
        uint32_t wc = len == 1 ? b0 : (b0 & (0xFFu >> (len + 1)));
        for (uint32_t i = 1; i < len; ++i) {
            const uint8_t bi = m.read<uint8_t>(s + i);
            if ((bi & 0xC0) != 0x80) { h.SetErrno(84); c.ret(kEOF); return; }
            wc = (wc << 6) | (bi & 0x3F);
        }
        if (pwc) m.write<uint32_t>(pwc, wc);
        c.ret(wc ? len : 0u);
    });
    h.Register("wcrtomb", [&m](CallCtx& c) {
        if (!c.arg(0)) { c.ret(1); return; }
        char buf[4];
        const int n = Utf8Encode(c.arg(1), buf);
        for (int i = 0; i < n; ++i) m.write<uint8_t>(c.arg(0) + uint32_t(i), uint8_t(buf[i]));
        c.ret(uint32_t(n));
    });
    h.Register("wcstombs", [&m](CallCtx& c) {
        uint32_t total = 0;
        for (uint32_t i = 0;; ++i) {
            const uint32_t wc = m.read<uint32_t>(c.arg(1) + 4 * i);
            if (!wc) break;
            char buf[4];
            const int n = Utf8Encode(wc, buf);
            if (c.arg(0)) {
                if (total + uint32_t(n) > c.arg(2)) break;
                for (int k = 0; k < n; ++k) m.write<uint8_t>(c.arg(0) + total + uint32_t(k), uint8_t(buf[k]));
            }
            total += uint32_t(n);
        }
        if (c.arg(0) && total < c.arg(2)) m.write<uint8_t>(c.arg(0) + total, 0);
        c.ret(total);
    });

    // ---- POSIX regular expressions (bionic regex_t is 16 bytes; our handle lives in re_g at offset 12) ----
    auto to_host_cflags = [](uint32_t g) {
        int f = 0;
        if (g & 1) f |= REG_EXTENDED;
        if (g & 2) f |= REG_ICASE;
        if (g & 4) f |= REG_NOSUB;
        if (g & 8) f |= REG_NEWLINE;
        return f;
    };
    h.Register("regcomp", [&m, to_host_cflags](CallCtx& c) {
        auto* re = new regex_t;
        const int r = ::regcomp(re, m.cstr(c.arg(1)).c_str(), to_host_cflags(c.arg(2)));
        if (r != 0) { delete re; c.ret(uint32_t(r)); return; }
        m.write<uint32_t>(c.arg(0), 0x1234u);                    // re_magic
        m.write<uint32_t>(c.arg(0) + 4, uint32_t(re->re_nsub));  // re_nsub
        m.write<uint32_t>(c.arg(0) + 12, g_regex.Put(re));       // re_g
        c.ret(0);
    });
    h.Register("regexec", [&m](CallCtx& c) {
        regex_t* re = g_regex.GetOr(m.read<uint32_t>(c.arg(0) + 12), nullptr);
        if (!re) { c.ret(2); return; }  // REG_BADPAT
        const uint32_t nmatch = c.arg(2);
        std::vector<regmatch_t> pm(nmatch ? nmatch : 1);
        const int eflags = (c.arg(4) & 1 ? REG_NOTBOL : 0) | (c.arg(4) & 2 ? REG_NOTEOL : 0);
        const int r = ::regexec(re, m.cstr(c.arg(1)).c_str(), nmatch, pm.data(), eflags);
        if (r == 0)
            for (uint32_t i = 0; i < nmatch; ++i) {
                m.write<int32_t>(c.arg(3) + 8 * i, int32_t(pm[i].rm_so));
                m.write<int32_t>(c.arg(3) + 8 * i + 4, int32_t(pm[i].rm_eo));
            }
        c.ret(uint32_t(r));
    });
    h.Register("regfree", [&m](CallCtx& c) {
        const uint32_t id = m.read<uint32_t>(c.arg(0) + 12);
        if (regex_t* re = g_regex.GetOr(id, nullptr)) { ::regfree(re); delete re; g_regex.Erase(id); }
        c.ret(0);
    });

    // ---- qsort: the comparator is guest code, so it is called through a nested guest call ----
    h.Register("qsort", [&h, &m](CallCtx& c) {
        const uint32_t base = c.arg(0), n = c.arg(1), sz = c.arg(2), cmp = c.arg(3);
        if (n < 2 || !sz) return;
        std::vector<uint32_t> idx(n);
        std::iota(idx.begin(), idx.end(), 0u);
        bool err = false;
        auto less = [&](uint32_t a, uint32_t b) {
            uint32_t r0 = 0;
            std::string e;
            if (err || !h.call_guest || !h.call_guest(cmp, {base + a * sz, base + b * sz}, &r0, &e)) { err = true; return false; }
            return int32_t(r0) < 0;
        };
        std::stable_sort(idx.begin(), idx.end(), less);
        if (err) { h.Fatal("qsort: comparator call into guest code failed"); return; }
        std::vector<uint8_t> tmp(size_t(n) * sz);
        for (uint32_t i = 0; i < n; ++i) std::memcpy(tmp.data() + size_t(i) * sz, m.host(base + idx[i] * sz), sz);
        std::memcpy(m.host(base), tmp.data(), tmp.size());
    });

    // ---- setjmp / longjmp: saved state = r4-r11, sp, lr (10 words). The stub's own "bx lr" then resumes. ----
    h.Register("setjmp", [&m](CallCtx& c) {
        const uint32_t b = c.arg(0);
        for (int i = 0; i < 8; ++i) m.write<uint32_t>(b + 4u * i, c.r[4 + i]);
        m.write<uint32_t>(b + 32, c.r[13]);
        m.write<uint32_t>(b + 36, c.r[14]);
        c.ret(0);
    });
    h.Register("longjmp", [&m](CallCtx& c) {
        const uint32_t b = c.arg(0), val = c.arg(1);
        for (int i = 0; i < 8; ++i) c.r[4 + i] = m.read<uint32_t>(b + 4u * i);
        c.r[13] = m.read<uint32_t>(b + 32);
        c.r[14] = m.read<uint32_t>(b + 36);
        c.r[0] = val ? val : 1;
    });

    // ---- libgcc / unwinder ----
    h.Register("__gnu_ldivmod_helper", [&m](CallCtx& c) {
        const int64_t a = int64_t(c.arg64(0)), b = int64_t(c.arg64(2));
        const int64_t q = b ? a / b : 0;
        if (c.arg(4)) m.write<uint64_t>(c.arg(4), uint64_t(a - b * q));
        c.ret64(uint64_t(q));
    });
    // Soft-stub C++ exceptions: full unwinding is not implemented. When the game throws
    // (e.g. after a failed font load), log once and return failure so the process continues
    // instead of aborting with FATAL.
    for (const char* n : {"_Unwind_RaiseException", "_Unwind_Resume", "_Unwind_Resume_or_Rethrow"})
        h.Register(n, [](CallCtx& c) {
            static std::atomic<int> nthrow{0};
            if (nthrow++ < 8) Logf("[cxx] soft-stub %s (exception unwinding not implemented)", "throw");
            c.ret(9);  // _URC_FAILURE
        });
    h.Register("__gnu_unwind_frame", [](CallCtx& c) { c.ret(9); });  // _URC_FAILURE
    for (const char* n : {"_Unwind_Complete", "_Unwind_DeleteException", "_Unwind_GetDataRelBase", "_Unwind_GetLanguageSpecificData",
                          "_Unwind_GetRegionStart", "_Unwind_GetTextRelBase", "_Unwind_VRS_Get", "_Unwind_VRS_Set"})
        h.Register(n, [](CallCtx& c) { c.ret(0); });
    // __cxa_* throw path – swallow instead of aborting
    h.Register("__cxa_throw", [](CallCtx& c) {
        static std::atomic<int> n{0};
        if (n++ < 8) Logf("[cxx] soft-stub __cxa_throw");
        c.ret(0);
    });
    h.Register("__cxa_rethrow", [](CallCtx& c) { c.ret(0); });
    h.Register("__cxa_begin_catch", [](CallCtx& c) { c.ret(c.arg(0)); });
    h.Register("__cxa_end_catch", [](CallCtx&) {});
    h.Register("__cxa_allocate_exception", [&m](CallCtx& c) {
        // simple guest malloc-sized buffer so throw path does not get NULL
        const uint32_t sz = c.arg(0) ? c.arg(0) : 16;
        // fall back: return a small static-ish region if no real malloc available here
        c.ret(0);  // will soft-fault later if used; better than abort
        (void)sz; (void)m;
    });
    h.Register("__cxa_free_exception", [](CallCtx&) {});
    h.Register("__cxa_get_exception_ptr", [](CallCtx& c) { c.ret(c.arg(0)); });
    h.Register("__cxa_call_unexpected", [](CallCtx& c) { c.ret(0); });
}

}  // namespace t64
