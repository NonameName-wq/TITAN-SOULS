#include "host_gl.h"

#include <GLES2/gl2.h>

#include <initializer_list>

#include "log.h"

namespace t64 {

HostGl& Gl() {
    static HostGl g;
    return g;
}

int HostGl::Width() const {
    EGLint v = 0;
    if (surf_ != EGL_NO_SURFACE) eglQuerySurface(dpy_, surf_, EGL_WIDTH, &v);
    return v;
}
int HostGl::Height() const {
    EGLint v = 0;
    if (surf_ != EGL_NO_SURFACE) eglQuerySurface(dpy_, surf_, EGL_HEIGHT, &v);
    return v;
}

bool HostGl::InitDisplay() {
    if (dpy_ != EGL_NO_DISPLAY) return true;
    dpy_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    EGLint maj = 0, min = 0;
    if (dpy_ == EGL_NO_DISPLAY || !eglInitialize(dpy_, &maj, &min)) {
        Logf("[gl] eglInitialize failed (0x%x)", eglGetError());
        dpy_ = EGL_NO_DISPLAY;
        return false;
    }
    // Try the richest configuration first; the game gets whatever this returns, whatever it asks for.
    struct Try { EGLint depth, stencil; };
    for (Try t : {Try{24, 8}, Try{16, 8}, Try{16, 0}, Try{0, 0}}) {
        const EGLint attr[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                               EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
                               EGL_DEPTH_SIZE, t.depth, EGL_STENCIL_SIZE, t.stencil, EGL_NONE};
        EGLint n = 0;
        if (eglChooseConfig(dpy_, attr, &cfg_, 1, &n) && n > 0) {
            EGLint d = 0, s = 0;
            eglGetConfigAttrib(dpy_, cfg_, EGL_DEPTH_SIZE, &d);
            eglGetConfigAttrib(dpy_, cfg_, EGL_STENCIL_SIZE, &s);
            Logf("[gl] EGL %d.%d, config: RGBA8888 depth=%d stencil=%d", maj, min, d, s);
            break;
        }
        cfg_ = nullptr;
    }
    if (!cfg_) { Logf("[gl] no usable EGL config"); return false; }
    const EGLint cattr[] = {EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE};
    ctx_ = eglCreateContext(dpy_, cfg_, EGL_NO_CONTEXT, cattr);
    if (ctx_ == EGL_NO_CONTEXT) { Logf("[gl] eglCreateContext failed (0x%x)", eglGetError()); return false; }
    return true;
}

bool HostGl::Init(ANativeWindow* win) {
    std::lock_guard<std::recursive_mutex> lk(mu_);
    if (!InitDisplay()) return false;
    if (surf_ != EGL_NO_SURFACE && win_ == win) return true;
    if (surf_ != EGL_NO_SURFACE) DestroySurface();
    EGLint visual = 0;
    eglGetConfigAttrib(dpy_, cfg_, EGL_NATIVE_VISUAL_ID, &visual);
    ANativeWindow_setBuffersGeometry(win, 0, 0, visual);
    surf_ = eglCreateWindowSurface(dpy_, cfg_, win, nullptr);
    if (surf_ == EGL_NO_SURFACE) { Logf("[gl] eglCreateWindowSurface failed (0x%x)", eglGetError()); return false; }
    win_ = win;
    return true;
}

void HostGl::DestroySurface() {
    std::lock_guard<std::recursive_mutex> lk(mu_);
    if (dpy_ == EGL_NO_DISPLAY) return;
    eglMakeCurrent(dpy_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (surf_ != EGL_NO_SURFACE) eglDestroySurface(dpy_, surf_);
    surf_ = EGL_NO_SURFACE;
    win_ = nullptr;
}

bool HostGl::MakeCurrentHere() {
    std::lock_guard<std::recursive_mutex> lk(mu_);
    if (surf_ == EGL_NO_SURFACE || ctx_ == EGL_NO_CONTEXT) return false;
    return eglMakeCurrent(dpy_, surf_, surf_, ctx_) == EGL_TRUE;
}

void HostGl::ReleaseCurrent() {
    std::lock_guard<std::recursive_mutex> lk(mu_);
    if (dpy_ != EGL_NO_DISPLAY) eglMakeCurrent(dpy_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
}

bool HostGl::BuildBannerProgram() {
    if (prog_) return true;
    const char* vs = "attribute vec2 p; varying vec2 uv; void main(){ uv = vec2(p.x*0.5+0.5, 0.5-p.y*0.5); gl_Position = vec4(p, 0.0, 1.0); }";
    const char* fs = "precision mediump float; varying vec2 uv; uniform sampler2D t; void main(){ gl_FragColor = texture2D(t, uv); }";
    auto compile = [](GLenum type, const char* src) {
        GLuint s = glCreateShader(type);
        glShaderSource(s, 1, &src, nullptr);
        glCompileShader(s);
        return s;
    };
    GLuint v = compile(GL_VERTEX_SHADER, vs), f = compile(GL_FRAGMENT_SHADER, fs);
    prog_ = glCreateProgram();
    glAttachShader(prog_, v);
    glAttachShader(prog_, f);
    glBindAttribLocation(prog_, 0, "p");
    glLinkProgram(prog_);
    GLint ok = 0;
    glGetProgramiv(prog_, GL_LINK_STATUS, &ok);
    if (!ok) { Logf("[gl] banner shader failed to link"); prog_ = 0; return false; }
    loc_tex_ = glGetUniformLocation(prog_, "t");
    glGenTextures(1, &tex_);
    return true;
}

bool HostGl::Present(const uint32_t* rgba, int w, int h) {
    std::lock_guard<std::recursive_mutex> lk(mu_);
    if (!MakeCurrentHere()) return false;
    if (!BuildBannerProgram()) { ReleaseCurrent(); return false; }
    glViewport(0, 0, Width(), Height());
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
    glDisable(GL_CULL_FACE);
    glDisable(GL_SCISSOR_TEST);
    glUseProgram(prog_);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex_);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glUniform1i(loc_tex_, 0);
    static const GLfloat quad[8] = {-1, -1, 1, -1, -1, 1, 1, 1};
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, quad);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    const bool ok = eglSwapBuffers(dpy_, surf_) == EGL_TRUE;
    ReleaseCurrent();  // never keep the banner context bound between frames
    return ok;
}

}  // namespace t64
