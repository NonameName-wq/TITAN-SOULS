// Silent stand-ins for FMOD Ex (the game's audio engine, a closed-source 32-bit library) and the Amazon
// GameCircle client. Every call succeeds (FMOD_OK = 0) and fills its out-parameters with harmless values, so the game
// runs normally without sound. A real FMOD host library comes in a later milestone.
#include <algorithm>
#include <cstring>
#include <string>

#include "hle.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {

void RegisterFmod(Hle& h) {
    GuestMemory& m = h.mem;
    auto ok = [](CallCtx& c) { c.ret(0); };
    auto out_u32 = [&m](uint32_t p, uint32_t v) { if (p) m.write<uint32_t>(p, v); };
    auto new_obj = [&h, &m]() { uint32_t p = h.Alloc(64); if (p) std::memset(m.host(p), 0, 64); return p; };  // zeroed-on-first-use block used as an opaque FMOD object

    // C API entry point
    h.Register("FMOD_System_Create", [&, new_obj](CallCtx& c) { out_u32(c.arg(0), new_obj()); c.ret(0); });

    // FMOD::System
    for (const char* n : {"_ZN4FMOD6System11setCallbackEPF11FMOD_RESULTP11FMOD_SYSTEM24FMOD_SYSTEM_CALLBACKTYPEPvS5_E",
                          "_ZN4FMOD6System13setFileSystemEPF11FMOD_RESULTPKciPjPPvS6_EPFS1_S5_S5_EPFS1_S5_S5_jS4_S5_EPFS1_S5_jS5_EPFS1_P18FMOD_ASYNCREADINFOS5_ESA_i",
                          "_ZN4FMOD6System14setSpeakerModeE16FMOD_SPEAKERMODE", "_ZN4FMOD6System16setDSPBufferSizeEji",
                          "_ZN4FMOD6System17setSoftwareFormatEi17FMOD_SOUND_FORMATii18FMOD_DSP_RESAMPLER", "_ZN4FMOD6System4initEijPv",
                          "_ZN4FMOD6System5closeEv", "_ZN4FMOD6System6updateEv", "_ZN4FMOD6System7releaseEv", "_ZN4FMOD6System9setDriverEi",
                          "_ZN4FMOD6System9setOutputE15FMOD_OUTPUTTYPE"})
        h.Register(n, ok);
    h.Register("_ZN4FMOD6System10getVersionEPj", [out_u32](CallCtx& c) { out_u32(c.arg(1), 0x00044999u); c.ret(0); });
    h.Register("_ZN4FMOD6System13getNumDriversEPi", [out_u32](CallCtx& c) { out_u32(c.arg(1), 1); c.ret(0); });
    h.Register("_ZN4FMOD6System13getDriverCapsEiPjPiP16FMOD_SPEAKERMODE", [out_u32](CallCtx& c) {
        out_u32(c.arg(2), 0);       // FMOD_CAPS_NONE
        out_u32(c.arg(3), 44100);   // control panel sample rate
        out_u32(c.arg(4), 2);       // FMOD_SPEAKERMODE_STEREO
        c.ret(0);
    });
    h.Register("_ZN4FMOD6System13getDriverInfoEiPciP9FMOD_GUID", [&m](CallCtx& c) {
        if (c.arg(2) && c.arg(3)) {
            const std::string name = "Silent FMOD stub";
            const size_t n = std::min<size_t>(name.size(), c.arg(3) - 1);
            std::memcpy(m.host(c.arg(2)), name.c_str(), n);
            m.write<uint8_t>(c.arg(2) + uint32_t(n), 0);
        }
        if (c.arg(4)) std::memset(m.host(c.arg(4)), 0, 16);
        c.ret(0);
    });
    auto create_sound = [out_u32, new_obj](CallCtx& c) { out_u32(c.arg(4), new_obj()); c.ret(0); };  // (this,name,mode,exinfo,Sound**)
    h.Register("_ZN4FMOD6System11createSoundEPKcjP22FMOD_CREATESOUNDEXINFOPPNS_5SoundE", create_sound);
    h.Register("_ZN4FMOD6System12createStreamEPKcjP22FMOD_CREATESOUNDEXINFOPPNS_5SoundE", create_sound);
    h.Register("_ZN4FMOD6System9playSoundE17FMOD_CHANNELINDEXPNS_5SoundEbPPNS_7ChannelE",  // (this,index,sound,paused,Channel**)
               [out_u32, new_obj](CallCtx& c) { out_u32(c.arg(4), new_obj()); c.ret(0); });

    // FMOD::Sound
    for (const char* n : {"_ZN4FMOD5Sound7releaseEv", "_ZN4FMOD5Sound7setModeEj"}) h.Register(n, ok);
    h.Register("_ZN4FMOD5Sound12getOpenStateEP14FMOD_OPENSTATEPjPbS4_", [out_u32, &m](CallCtx& c) {
        out_u32(c.arg(1), 0);  // FMOD_OPENSTATE_READY
        out_u32(c.arg(2), 100);
        if (c.arg(3)) m.write<uint8_t>(c.arg(3), 0);
        if (c.arg(4)) m.write<uint8_t>(c.arg(4), 0);
        c.ret(0);
    });
    h.Register("_ZN4FMOD5Sound19getMusicNumChannelsEPi", [out_u32](CallCtx& c) { out_u32(c.arg(1), 0); c.ret(0); });

    // FMOD::Channel
    for (const char* n : {"_ZN4FMOD7Channel11setPositionEjj", "_ZN4FMOD7Channel12setFrequencyEf", "_ZN4FMOD7Channel12setLoopCountEi",
                          "_ZN4FMOD7Channel4stopEv", "_ZN4FMOD7Channel6setPanEf", "_ZN4FMOD7Channel7setModeEj",
                          "_ZN4FMOD7Channel9setPausedEb", "_ZN4FMOD7Channel9setVolumeEf"})
        h.Register(n, ok);
    h.Register("_ZN4FMOD7Channel11getPositionEPjj", [out_u32](CallCtx& c) { out_u32(c.arg(1), 0); c.ret(0); });
    h.Register("_ZN4FMOD7Channel12getFrequencyEPf", [out_u32](CallCtx& c) { out_u32(c.arg(1), 0x472C4400u /* 44100.0f */); c.ret(0); });
    h.Register("_ZN4FMOD7Channel9isPlayingEPb", [&m](CallCtx& c) { if (c.arg(1)) m.write<uint8_t>(c.arg(1), 0); c.ret(0); });

    // Amazon GameCircle (achievements / leaderboards / Whispersync): do nothing.
    h.Register("_ZN11AmazonGames17WhispersyncClient11getGameDataEv", [&h, new_obj](CallCtx& c) {
        static uint32_t obj = 0;
        if (!obj) obj = new_obj();
        c.ret(obj);
        (void)h;
    });
    for (const char* n : {"_ZN11AmazonGames27AchievementsClientInterface14updateProgressEPKcfPNS_17IUpdateProgressCbEi",
                          "_ZN11AmazonGames27AchievementsClientInterface23showAchievementsOverlayEv",
                          "_ZN11AmazonGames27LeaderboardsClientInterface11submitScoreEPKcxPNS_25ILeaderboardSubmitScoreCbEi",
                          "_ZN11AmazonGames9ICallbackD2Ev"})
        h.Register(n, ok);
}

}  // namespace t64
