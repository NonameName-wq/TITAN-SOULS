// Tiny logging hub: everything (host + HLE + game logs) goes through Logf so the Android build can
// show it on screen and in a log file.
#pragma once
namespace t64 {
using LogSink = void (*)(const char* line);
void SetLogSink(LogSink sink);
void Logf(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
}  // namespace t64
