#include "hle.h"
#include "log.h"
#include <cstdio>
#include <cstring>
#include <initializer_list>

namespace t64 {

Hle::Hle(GuestMemory& m) : mem(m) {
    mem.write<uint16_t>(kRetTramp, 0xBE00);  // Thumb: bkpt #0
    InstallKuserHelpers();
    RegisterBuiltins(*this);
}

// Linux/ARM "kernel user helpers" live at fixed addresses in the vector page. Inlined atomics in the
// game call them directly (bl 0xffff0fc0 etc.). Single guest thread for now, so plain code is atomic enough.
void Hle::InstallKuserHelpers() {
    auto put = [&](uint32_t addr, std::initializer_list<uint32_t> words) {
        uint32_t off = addr - kVecBase;
        for (uint32_t w : words) { std::memcpy(mem.vec() + off, &w, 4); off += 4; }
    };
    put(0xFFFF0FA0, {0xE12FFF1E});                                                    // __kuser_memory_barrier: bx lr
    put(0xFFFF0FC0, {0xE5923000, 0xE0533000, 0x05821000, 0xE2730000, 0xE12FFF1E});  // __kuser_cmpxchg(old,new,ptr)
    put(0xFFFF0FE0, {0xE59F0008, 0xE12FFF1E});                                       // __kuser_get_tls: ldr r0,[pc,#8]; bx lr
    put(0xFFFF0FF0, {kTlsBlock});                                                    // TLS pointer value
    put(0xFFFF0FFC, {5});                                                            // __kuser_helper_version
}

uint32_t Hle::Function(const std::string& name) {
    auto it = func_addr_.find(name);
    if (it != func_addr_.end()) return it->second;
    auto gi = guest_impl_.find(name);
    if (gi != guest_impl_.end()) {
        const uint32_t addr = guest_code_ptr_;
        for (uint32_t w : gi->second) { mem.write<uint32_t>(guest_code_ptr_, w); guest_code_ptr_ += 4; }
        func_addr_[name] = addr;
        return addr;
    }
    const uint32_t idx = static_cast<uint32_t>(entries_.size());
    const uint32_t addr = kStubBase + 8 * idx;
    mem.write<uint32_t>(addr, 0xEF000000u | idx);  // svc #idx
    mem.write<uint32_t>(addr + 4, 0xE12FFF1Eu);    // bx lr
    entries_.push_back({name});
    func_addr_[name] = addr;
    return addr;  // even address: ARM mode
}

static void FillCtypeTables(GuestMemory& mem, uint32_t ctype, uint32_t lower, uint32_t upper) {
    // Old bionic layout: _ctype_[1 + c] holds flags; tolower/toupper tables are int16_t[257] indexed by c+1.
    enum { U = 0x01, L = 0x02, N = 0x04, S = 0x08, P = 0x10, C = 0x20, X = 0x40, B = 0x80 };
    mem.write<uint8_t>(ctype, 0);
    mem.write<int16_t>(lower, -1);
    mem.write<int16_t>(upper, -1);
    for (int c = 0; c < 256; ++c) {
        uint8_t f = 0;
        if (c >= '0' && c <= '9') f |= N;
        if (c >= 'A' && c <= 'Z') f |= U;
        if (c >= 'a' && c <= 'z') f |= L;
        if ((c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f') || (c >= '0' && c <= '9')) f |= X;
        if (c == ' ') f |= S | B;
        else if (c >= 9 && c <= 13) f |= S | C;
        else if (c < 32 || c == 127) f |= C;
        else if (c > 32 && c < 127 && !(f & (N | U | L))) f |= P;
        mem.write<uint8_t>(ctype + 1 + c, f);
        mem.write<int16_t>(lower + 2 + 2 * c, (c >= 'A' && c <= 'Z') ? c + 32 : c);
        mem.write<int16_t>(upper + 2 + 2 * c, (c >= 'a' && c <= 'z') ? c - 32 : c);
    }
}

uint32_t Hle::Data(const std::string& name, uint32_t size) {
    auto it = data_addr_.find(name);
    if (it != data_addr_.end()) return it->second;
    uint32_t n = size;
    if (name == "__stack_chk_guard") n = 4;
    else if (name == "_ctype_") n = 257;
    else if (name == "_tolower_tab_" || name == "_toupper_tab_") n = 514;
    else if (name == "__sF") n = 3 * 84;  // stdin/stdout/stderr, sizeof(FILE) in old bionic
    if (n == 0) n = 64;
    data_ptr_ = (data_ptr_ + 15) & ~15u;
    const uint32_t addr = data_ptr_;
    data_ptr_ += n;
    if (data_ptr_ > kDataEnd) throw std::runtime_error("out of import-data space");
    data_addr_[name] = addr;
    if (name == "__stack_chk_guard") mem.write<uint32_t>(addr, 0x4F2A1C03u);
    if (name == "_ctype_") {
        FillCtypeTables(mem, addr, Data("_tolower_tab_", 514), Data("_toupper_tab_", 514));
    }
    return addr;
}

uint32_t Hle::Alloc(uint32_t size, uint32_t align) {
    uint32_t p = (heap_ptr_ + 8 + align - 1) & ~(align - 1);
    if (uint64_t(p) + size > kHeapEnd) return 0;
    mem.write<uint32_t>(p - 8, size);
    heap_ptr_ = p + size;
    return p;  // fresh arena memory is already zero (bump allocator never reuses)
}

void Hle::Dispatch(uint32_t index, std::array<uint32_t, 16>& regs) {
    if (index >= entries_.size()) {
        halt_requested = true;
        halt_reason = "svc with unknown index " + std::to_string(index);
        return;
    }
    const std::string& name = entries_[index].name;
    auto it = fns_.find(name);
    if (it == fns_.end()) {
        if (missing_called.insert(name).second) Logf("[hle] UNIMPLEMENTED import called: %s", name.c_str());
        regs[0] = 0;
        return;
    }
    CallCtx ctx{mem, regs};
    it->second(ctx);
}

}  // namespace t64
