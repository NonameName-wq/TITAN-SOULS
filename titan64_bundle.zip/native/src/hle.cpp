#include "hle.h"
#include "log.h"
#include <cstdio>
#include <cstring>
#include <initializer_list>

namespace t64 {

namespace {
struct ThreadDbg {
    uint32_t serial = 0;
    std::array<uint32_t, 16>* regs = nullptr;
    const std::string* cur = nullptr;
    uint64_t calls = 0;
    uint64_t calls_at_last_dump = 0;
    struct Rec { const std::string* name; uint32_t a0, a1, a2; };
    Rec ring[64] = {};
    uint32_t ring_pos = 0;
};
std::mutex g_dbg_mu;
std::vector<ThreadDbg*>& DbgList() { static auto* v = new std::vector<ThreadDbg*>; return *v; }
thread_local ThreadDbg* t_dbg = nullptr;
ThreadDbg* Dbg() {
    if (!t_dbg) {
        t_dbg = new ThreadDbg;
        std::lock_guard<std::mutex> lk(g_dbg_mu);
        t_dbg->serial = static_cast<uint32_t>(DbgList().size()) + 1;
        DbgList().push_back(t_dbg);
    }
    return t_dbg;
}
}  // namespace

void Hle::DbgDetach() {
    if (t_dbg) { t_dbg->regs = nullptr; t_dbg->cur = nullptr; }
}

std::vector<std::string> Hle::DebugThreads() {
    std::vector<ThreadDbg*> list;
    {
        std::lock_guard<std::mutex> lk(g_dbg_mu);
        list = DbgList();
    }
    std::vector<std::string> out;
    for (ThreadDbg* d : list) {
        char b[256];
        std::string line;
        const uint64_t calls = d->calls, delta = calls - d->calls_at_last_dump;
        d->calls_at_last_dump = calls;
        auto* regs = d->regs;
        if (!regs) { std::snprintf(b, sizeof b, "thread#%u: finished (%llu system calls)", d->serial, (unsigned long long)calls); out.push_back(b); continue; }
        const uint32_t pc = (*regs)[15], lr = (*regs)[14], sp = (*regs)[13];
        const std::string* cur = d->cur;
        std::snprintf(b, sizeof b, "thread#%u: %s%s | +%llu calls | pc=0x%08x", d->serial, cur ? "INSIDE " : "guest code",
                      cur ? cur->c_str() : "", (unsigned long long)delta, pc);
        line = b;
        if (symbolize) line += " " + symbolize(pc);
        std::snprintf(b, sizeof b, " lr=0x%08x", lr);
        line += b;
        if (symbolize) line += " " + symbolize(lr);
        std::snprintf(b, sizeof b, " sp=0x%08x | last:", sp);
        line += b;
        auto str_arg = [&](uint32_t a) -> std::string {  // a short quoted C string if `a` looks like a pointer to one
            if (a < 0x1000 || !mem.valid(a, 1)) return "?";
            std::string s = "\"";
            for (uint32_t i = 0; i < 28 && mem.valid(a + i, 1); ++i) {
                const uint8_t ch = mem.read<uint8_t>(a + i);
                if (!ch) break;
                s += (ch >= 32 && ch < 127) ? char(ch) : '.';
            }
            return s + "\"";
        };
        auto bytes_at = [&](uint32_t a) -> std::string {  // "[xx xx ...]" first 10 bytes at a guest address
            if (a < 0x1000 || !mem.valid(a, 10)) return "";
            std::string s = "[";
            for (uint32_t i = 0; i < 10; ++i) { char x[8]; std::snprintf(x, sizeof x, i ? " %02x" : "%02x", mem.read<uint8_t>(a + i)); s += x; }
            return s + "]";
        };
        for (uint32_t i = 40; i > 0; --i) {
            const ThreadDbg::Rec& r = d->ring[(d->ring_pos - i) & 63];
            if (!r.name) continue;
            const std::string& n = *r.name;
            char a[96];
            if (n == "strcmp" || n == "strncmp" || n == "strstr" || n == "strcpy" || n == "strcat" || n == "strncpy")
                std::snprintf(a, sizeof a, " %s(%s,%s)", n.c_str(), str_arg(r.a0).c_str(), str_arg(r.a1).c_str());
            else if (n == "strlen" || n == "strchr" || n == "strrchr" || n == "fopen" || n == "atoi" || n == "strtol")
                std::snprintf(a, sizeof a, " %s(%s)", n.c_str(), str_arg(r.a0).c_str());
            else if (n == "memcmp")
                std::snprintf(a, sizeof a, " memcmp(%x%s,%x,%x)", r.a0, bytes_at(r.a0).c_str(), r.a1, r.a2);
            else if (n == "memcpy" || n == "memmove")
                std::snprintf(a, sizeof a, " %s(%x,%x%s,%x)", n.c_str(), r.a0, r.a1, bytes_at(r.a1).c_str(), r.a2);
            else
                std::snprintf(a, sizeof a, " %s(%x,%x,%x)", n.c_str(), r.a0, r.a1, r.a2);
            line += a;
        }
        out.push_back(line);
    }
    return out;
}

Hle::Hle(GuestMemory& m) : mem(m) {
    mem.write<uint16_t>(kRetTramp, 0xBE00);  // Thumb: bkpt #0
    InstallKuserHelpers();
    RegisterBuiltins(*this);
    RegisterSync(*this);  // overrides the single-threaded pthread stubs
    RegisterIo(*this);
    RegisterMisc(*this);
    RegisterFmod(*this);
}

// Linux/ARM "kernel user helpers" live at fixed addresses in the vector page. Inlined atomics in the
// game call them directly (bl 0xffff0fc0 etc.).
void Hle::InstallKuserHelpers() {
    auto put = [&](uint32_t addr, std::initializer_list<uint32_t> words) {
        uint32_t off = addr - kVecBase;
        for (uint32_t w : words) { std::memcpy(mem.vec() + off, &w, 4); off += 4; }
    };
    put(0xFFFF0FA0, {0xE12FFF1E});                                                    // __kuser_memory_barrier: bx lr
    put(0xFFFF0FC0, {0xE1923F9F, 0xE0533000, 0x01823F91, 0x03330001, 0x0AFFFFFA,
                     0xE2730000, 0xE12FFF1E});  // __kuser_cmpxchg(old,new,ptr), SMP version: ldrex/strex loop
    put(0xFFFF0FE0, {0xE59F0008, 0xE12FFF1E});                                       // __kuser_get_tls: ldr r0,[pc,#8]; bx lr
    put(0xFFFF0FF0, {kTlsBlock});                                                    // TLS pointer value
    put(0xFFFF0FFC, {5});                                                            // __kuser_helper_version
}

uint32_t Hle::Function(const std::string& name) {
    auto it = func_addr_.find(name);
    if (it != func_addr_.end()) return it->second;
    auto gi = guest_impl_.find(name);
    if (gi != guest_impl_.end()) {
        const uint32_t addr = guest_code_ptr_;
        for (uint32_t w : gi->second) { mem.write<uint32_t>(guest_code_ptr_, w); guest_code_ptr_ += 4; }
        func_addr_[name] = addr;
        return addr;
    }
    const uint32_t idx = static_cast<uint32_t>(entries_.size());
    const uint32_t addr = kStubBase + 8 * idx;
    mem.write<uint32_t>(addr, 0xEF000000u | idx);  // svc #idx
    mem.write<uint32_t>(addr + 4, 0xE12FFF1Eu);    // bx lr
    entries_.push_back({name});
    func_addr_[name] = addr;
    return addr;  // even address: ARM mode
}

static void FillCtypeTables(GuestMemory& mem, uint32_t ctype, uint32_t lower, uint32_t upper) {
    // Old bionic layout: _ctype_[1 + c] holds flags; tolower/toupper tables are int16_t[257] indexed by c+1.
    enum { U = 0x01, L = 0x02, N = 0x04, S = 0x08, P = 0x10, C = 0x20, X = 0x40, B = 0x80 };
    mem.write<uint8_t>(ctype, 0);
    mem.write<int16_t>(lower, -1);
    mem.write<int16_t>(upper, -1);
    for (int c = 0; c < 256; ++c) {
        uint8_t f = 0;
        if (c >= '0' && c <= '9') f |= N;
        if (c >= 'A' && c <= 'Z') f |= U;
        if (c >= 'a' && c <= 'z') f |= L;
        if ((c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f') || (c >= '0' && c <= '9')) f |= X;
        if (c == ' ') f |= S | B;
        else if (c >= 9 && c <= 13) f |= S | C;
        else if (c < 32 || c == 127) f |= C;
        else if (c > 32 && c < 127 && !(f & (N | U | L))) f |= P;
        mem.write<uint8_t>(ctype + 1 + c, f);
        mem.write<int16_t>(lower + 2 + 2 * c, (c >= 'A' && c <= 'Z') ? c + 32 : c);
        mem.write<int16_t>(upper + 2 + 2 * c, (c >= 'a' && c <= 'z') ? c - 32 : c);
    }
}

uint32_t Hle::Data(const std::string& name, uint32_t size) {
    auto it = data_addr_.find(name);
    if (it != data_addr_.end()) return it->second;
    uint32_t n = size;
    if (name == "__stack_chk_guard") n = 4;
    else if (name == "_ctype_") n = 257;
    else if (name == "_tolower_tab_" || name == "_toupper_tab_") n = 514;
    else if (name == "__sF") n = 3 * 84;  // stdin/stdout/stderr, sizeof(FILE) in old bionic
    if (n == 0) n = 64;
    data_ptr_ = (data_ptr_ + 15) & ~15u;
    const uint32_t addr = data_ptr_;
    data_ptr_ += n;
    if (data_ptr_ > kDataEnd) throw std::runtime_error("out of import-data space");
    data_addr_[name] = addr;
    if (name == "__stack_chk_guard") mem.write<uint32_t>(addr, 0x4F2A1C03u);
    if (name == "_ctype_") {
        FillCtypeTables(mem, addr, Data("_tolower_tab_", 514), Data("_toupper_tab_", 514));
    }
    return addr;
}

// ------------------------------------------------------------------------------------------------
// Heap. Block layout: [size:u32][magic:u32][pad:8][payload...]; payload is 16-byte aligned.
// ------------------------------------------------------------------------------------------------
static constexpr uint32_t kMagicUsed = 0xA110C8EDu, kMagicFree = 0xF2EEF2EEu;

std::string Hle::HeapStats() {
    std::lock_guard<std::mutex> lk(heap_mu_);
    uint64_t free_bytes = 0;
    for (const auto& f : free_by_addr_) free_bytes += f.second;
    char b[128];
    std::snprintf(b, sizeof b, "top=0x%08x used-span=%uMB free-blocks=%zu free-bytes=%lluKB", heap_top_, (heap_top_ - kHeapBase) >> 20,
                  free_by_addr_.size(), static_cast<unsigned long long>(free_bytes >> 10));
    return b;
}

uint32_t Hle::Alloc(uint32_t size, uint32_t /*align*/) {
    std::lock_guard<std::mutex> lk(heap_mu_);
    const uint32_t payload = ((size ? size : 1u) + 15u) & ~15u;
    uint32_t total = payload + 16;
    uint32_t blk;
    auto it = free_by_size_.lower_bound({total, 0});
    if (it != free_by_size_.end()) {
        const uint32_t bsz = it->first;
        blk = it->second;
        free_by_size_.erase(it);
        free_by_addr_.erase(blk);
        if (bsz >= total + 48) {  // split off the remainder
            const uint32_t rest = blk + total, rsz = bsz - total;
            free_by_addr_[rest] = rsz;
            free_by_size_.insert({rsz, rest});
        } else {
            total = bsz;
        }
    } else {
        if (uint64_t(heap_top_) + total > kHeapEnd) {
            static int reported = 0;
            if (reported++ < 10) Logf("[heap] OUT OF MEMORY: Alloc(%u) failed, heap top=0x%08x", size, heap_top_);
            return 0;
        }
        blk = heap_top_;
        heap_top_ += total;
    }
    mem.write<uint32_t>(blk, total - 16);
    mem.write<uint32_t>(blk + 4, kMagicUsed);
    return blk + 16;
}

void Hle::Free(uint32_t p) {
    if (!p) return;
    std::lock_guard<std::mutex> lk(heap_mu_);
    uint32_t blk = p - 16;
    if (p < kHeapBase + 16 || p >= heap_top_ || mem.read<uint32_t>(blk + 4) != kMagicUsed) {
        static int warned = 0;
        if (warned++ < 10) Logf("[heap] bad free(0x%08x)", p);
        return;
    }
    uint32_t sz = mem.read<uint32_t>(blk) + 16;
    mem.write<uint32_t>(blk + 4, kMagicFree);
    auto nx = free_by_addr_.find(blk + sz);  // merge with the following free block
    if (nx != free_by_addr_.end()) {
        sz += nx->second;
        free_by_size_.erase({nx->second, nx->first});
        free_by_addr_.erase(nx);
    }
    auto pv = free_by_addr_.lower_bound(blk);  // merge with the preceding free block
    if (pv != free_by_addr_.begin()) {
        --pv;
        if (pv->first + pv->second == blk) {
            blk = pv->first;
            sz += pv->second;
            free_by_size_.erase({pv->second, pv->first});
            free_by_addr_.erase(pv);
        }
    }
    if (blk + sz == heap_top_) { heap_top_ = blk; return; }  // give the tail back to the bump region
    free_by_addr_[blk] = sz;
    free_by_size_.insert({sz, blk});
}

uint32_t Hle::Realloc(uint32_t p, uint32_t n) {
    if (!p) return Alloc(n);
    if (n == 0) { Free(p); return 0; }
    const uint32_t cap = AllocSize(p);
    if (n <= cap) return p;
    const uint32_t np = Alloc(n);
    if (!np) return 0;
    std::memcpy(mem.host(np), mem.host(p), cap);
    Free(p);
    return np;
}

uint32_t Hle::AllocStack(uint32_t size) {
    std::lock_guard<std::mutex> lk(stack_mu_);
    size = (size + 0xFFFFu) & ~0xFFFFu;
    for (size_t i = 0; i < free_stacks_.size(); ++i)
        if (free_stacks_[i].first == size) {
            uint32_t top = free_stacks_[i].second;
            free_stacks_.erase(free_stacks_.begin() + static_cast<long>(i));
            return top;
        }
    if (uint64_t(stack_ptr_) + size > kThreadStackEnd) return 0;
    stack_ptr_ += size;
    return stack_ptr_;
}

void Hle::FreeStack(uint32_t top, uint32_t size) {
    std::lock_guard<std::mutex> lk(stack_mu_);
    size = (size + 0xFFFFu) & ~0xFFFFu;
    free_stacks_.push_back({size, top});
}

uint32_t Hle::ErrnoAddr() {
    static thread_local uint32_t addr = 0;
    if (!addr) addr = Alloc(16);
    return addr;
}

void Hle::Fatal(const std::string& why) {
    bool expected = false;
    if (!fatal.compare_exchange_strong(expected, true)) return;
    halt_reason = why;
    halt_requested = true;
    Logf("FATAL: %s", why.c_str());
    for (const std::string& l : DebugThreads()) Logf("[crash] %s", l.c_str());
    if (on_fatal) on_fatal(why);
    if (wake_hook) wake_hook();
}

void Hle::Dispatch(uint32_t index, std::array<uint32_t, 16>& regs) {
    if (index >= entries_.size()) {
        Fatal("svc with unknown index " + std::to_string(index));
        return;
    }
    const std::string& name = entries_[index].name;
    ThreadDbg* dbg = Dbg();
    dbg->regs = &regs;
    dbg->ring[dbg->ring_pos++ & 63] = {&name, regs[0], regs[1], regs[2]};
    ++dbg->calls;
    auto it = fns_.find(name);
    if (it == fns_.end()) {
        bool first;
        {
            std::lock_guard<std::mutex> lk(miss_mu_);
            first = missing_called.insert(name).second;
        }
        if (first) Logf("[hle] UNIMPLEMENTED import called: %s", name.c_str());
        regs[0] = 0;
        return;
    }
    CallCtx ctx{mem, regs};
    dbg->cur = &name;
    try {
        it->second(ctx);
    } catch (const GuestFault& f) {
        char b[160];
        std::snprintf(b, sizeof b, "segmentation fault: %s() was given a bad guest pointer 0x%08x (%zu bytes)", name.c_str(), f.addr, f.size);
        std::string msg = b;
        if (symbolize) msg += " called from " + symbolize(regs[14]);
        Fatal(msg);
    }
    dbg->cur = nullptr;
}

}  // namespace t64
