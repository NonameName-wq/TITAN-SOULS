#include "log.h"
#include <cstdarg>
#include <cstdio>
namespace t64 {
static LogSink g_sink = nullptr;
void SetLogSink(LogSink sink) { g_sink = sink; }
void Logf(const char* fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    if (g_sink) g_sink(buf);
    else std::fprintf(stderr, "%s\n", buf);
}
}  // namespace t64
