// Android entry point (NativeActivity). Milestone 4:
//   * loads the original 32-bit ARM libTestSuite.so (shipped as asset guest/libTestSuite.so)
//   * boots it inside Dynarmic (our host lib is the arm64 libTestSuite.so that NativeActivity loads)
//   * runs the game's static constructors, then the game's own ANativeActivity_onCreate (native_app_glue)
//   * forwards Android lifecycle events (window, input queue, focus, pause/resume) to the guest
//   * shows a status banner through the app's EGL surface until the game takes the screen over; log goes to a file
#include <android/asset_manager.h>
#include <android/input.h>
#include <android/log.h>
#include <android/native_activity.h>
#include <android/native_window.h>
#include <pthread.h>
#include <sys/stat.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <future>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include "android_hle.h"
#include "cpu.h"
#include "elf32.h"
#include "font8x16.h"
#include "hle.h"
#include "host_gl.h"
#include "libc_util.h"
#include "log.h"

using namespace t64;

namespace {

constexpr uint32_t Rgb(uint32_t r, uint32_t g, uint32_t b) { return 0xFF000000u | (b << 16) | (g << 8) | r; }  // RGBA_8888, little endian

enum class Ev { Start, Resume, Pause, Stop, WindowCreated, WindowDestroyed, InputCreated, InputDestroyed, Focus };
struct Event {
    Ev type;
    void* ptr = nullptr;
    int arg = 0;
    std::shared_ptr<std::promise<void>> done;  // set when the guest has processed it (UI thread waits for "destroyed" events)
};

struct State {
    ANativeActivity* act = nullptr;
    std::mutex mu;
    std::condition_variable cv;
    ANativeWindow* win = nullptr;
    std::deque<Event> events;
    std::vector<std::string> lines;
    std::string banner = "titan64: starting...";
    uint32_t banner_color = Rgb(200, 150, 0);
    FILE* log1 = nullptr;
    FILE* log2 = nullptr;
    bool need_redraw = true;
    std::atomic<bool> game_started{false};   // ANativeActivity_onCreate of the guest has been called
    std::atomic<bool> surface_taken{false};  // the game created its EGL window surface: the banner must not draw any more
    std::atomic<bool> fatal{false};
};
State g;

void FillRect(uint32_t* px, int stride, int W, int H, int x0, int y0, int w, int h, uint32_t c) {
    for (int y = y0; y < y0 + h && y < H; ++y)
        for (int x = x0; x < x0 + w && x < W; ++x) px[y * stride + x] = c;
}

void DrawText(uint32_t* px, int stride, int W, int H, int x, int y, int sc, const char* s, uint32_t col) {
    for (; *s; ++s, x += 8 * sc) {
        unsigned char ch = static_cast<unsigned char>(*s);
        if (ch < 32 || ch > 126) ch = '?';
        const uint8_t* gl = kFont8x16[ch - 32];
        for (int r = 0; r < 16; ++r)
            for (int c = 0; c < 8; ++c)
                if (gl[r] & (0x80 >> c)) FillRect(px, stride, W, H, x + c * sc, y + r * sc, sc, sc, col);
    }
}

// Painter thread only. Renders the status banner + log tail into a bitmap and shows it through the app's own EGL surface.
void Draw() {
    if (g.surface_taken) return;
    std::vector<std::string> lines;
    std::string banner;
    uint32_t banner_color;
    ANativeWindow* win;
    {
        std::lock_guard<std::mutex> lk(g.mu);
        win = g.win;
        lines = g.lines;
        banner = g.banner;
        banner_color = g.banner_color;
    }
    if (!win) return;
    HostGl& gl = Gl();
    if (!gl.Init(win)) return;
    const int W = gl.Width(), H = gl.Height();
    if (W <= 0 || H <= 0) return;
    std::vector<uint32_t> px(static_cast<size_t>(W) * static_cast<size_t>(H));
    FillRect(px.data(), W, W, H, 0, 0, W, H, Rgb(18, 20, 28));
    const int sc = W >= 1600 ? 3 : 2;
    const int bar = 16 * (sc + 1) + 24;
    FillRect(px.data(), W, W, H, 0, 0, W, bar, banner_color);
    DrawText(px.data(), W, W, H, 16, 12, sc + 1, banner.c_str(), Rgb(255, 255, 255));
    const int cols = (W - 32) / (8 * sc);
    const int rows = (H - bar - 24) / (16 * sc);
    std::vector<std::string> wrapped;
    for (const auto& l : lines) {
        if (l.empty()) { wrapped.emplace_back(); continue; }
        for (size_t i = 0; i < l.size(); i += static_cast<size_t>(cols)) wrapped.push_back(l.substr(i, static_cast<size_t>(cols)));
    }
    int start = static_cast<int>(wrapped.size()) > rows ? static_cast<int>(wrapped.size()) - rows : 0;
    int y = bar + 16;
    for (int i = start; i < static_cast<int>(wrapped.size()); ++i, y += 16 * sc)
        DrawText(px.data(), W, W, H, 16, y, sc, wrapped[static_cast<size_t>(i)].c_str(), Rgb(220, 220, 220));
    if (g.surface_taken) return;
    if (gl.Present(px.data(), W, H)) {
        std::lock_guard<std::mutex> lk(g.mu);
        g.need_redraw = false;
    }
}

void Sink(const char* line) {
    __android_log_print(ANDROID_LOG_INFO, "titan64", "%s", line);
    std::lock_guard<std::mutex> lk(g.mu);
    g.lines.emplace_back(line);
    g.need_redraw = true;
    if (g.lines.size() > 400) g.lines.erase(g.lines.begin(), g.lines.begin() + 100);
    if (g.log1) { std::fprintf(g.log1, "%s\n", line); std::fflush(g.log1); }
    if (g.log2) { std::fprintf(g.log2, "%s\n", line); std::fflush(g.log2); }
}

void RequestRedraw() {
    std::lock_guard<std::mutex> lk(g.mu);
    g.need_redraw = true;
}

void SetBanner(const char* text, uint32_t color) {
    std::lock_guard<std::mutex> lk(g.mu);
    g.banner = text;
    g.banner_color = color;
    g.need_redraw = true;
}

// ---------------------------------------------------------------------------------------------- guest activity
// ANativeActivityCallbacks slots (the guest's native_app_glue fills these during ANativeActivity_onCreate).
enum CbSlot { kOnStart = 0, kOnResume = 1, kOnPause = 3, kOnStop = 4, kOnWindowFocusChanged = 6, kOnNativeWindowCreated = 7,
              kOnNativeWindowDestroyed = 10, kOnInputQueueCreated = 11, kOnInputQueueDestroyed = 12 };

struct Game {
    GuestMemory mem;
    Hle hle{mem};
    std::unique_ptr<Cpu> cpu;
    LoadedLib lib;
    uint32_t guest_activity = 0, guest_callbacks = 0;
    std::unordered_map<void*, uint32_t> handles;  // host window / input queue -> guest handle
};

bool CallCb(Game& gm, CbSlot slot, std::vector<uint32_t> extra) {
    const uint32_t fn = gm.mem.read<uint32_t>(gm.guest_callbacks + 4u * slot);
    if (!fn) return true;
    std::vector<uint32_t> args{gm.guest_activity};
    args.insert(args.end(), extra.begin(), extra.end());
    CallResult r = gm.cpu->Call(fn, args, kForever);
    if (!r.ok) Logf("[activity] guest callback %d failed: %s", int(slot), r.error.c_str());
    return r.ok;
}

void BuildActivity(Game& gm) {
    Hle& hle = gm.hle;
    GuestMemory& m = gm.mem;
    uint32_t vm = 0, env = 0;
    RegisterJni(hle, &vm, &env);
    gm.guest_callbacks = hle.Alloc(64);
    std::memset(m.host(gm.guest_callbacks), 0, 64);
    gm.guest_activity = hle.Alloc(64);
    std::memset(m.host(gm.guest_activity), 0, 64);
    ANativeActivity* a = g.act;
    m.write<uint32_t>(gm.guest_activity + 0, gm.guest_callbacks);
    m.write<uint32_t>(gm.guest_activity + 4, vm);
    m.write<uint32_t>(gm.guest_activity + 8, env);
    m.write<uint32_t>(gm.guest_activity + 12, 0x7A000010u);  // jobject clazz (opaque)
    m.write<uint32_t>(gm.guest_activity + 16, PutGuestString(hle, a->internalDataPath ? a->internalDataPath : ""));
    m.write<uint32_t>(gm.guest_activity + 20, PutGuestString(hle, a->externalDataPath ? a->externalDataPath : ""));
    m.write<int32_t>(gm.guest_activity + 24, a->sdkVersion);
    m.write<uint32_t>(gm.guest_activity + 28, 0);
    m.write<uint32_t>(gm.guest_activity + 32, Bridge().WrapAssetManager(a->assetManager));
    m.write<uint32_t>(gm.guest_activity + 36, PutGuestString(hle, a->obbPath ? a->obbPath : ""));
}

// Delivers one Android lifecycle event to the guest's native_app_glue (Worker thread).
void Deliver(Game& gm, Event& ev) {
    auto handle_of = [&](void* p, bool queue) {
        auto it = gm.handles.find(p);
        if (it != gm.handles.end()) return it->second;
        const uint32_t hnd = queue ? Bridge().WrapInputQueue(static_cast<AInputQueue*>(p)) : Bridge().WrapWindow(static_cast<ANativeWindow*>(p));
        gm.handles[p] = hnd;
        return hnd;
    };
    switch (ev.type) {
        case Ev::Start: CallCb(gm, kOnStart, {}); break;
        case Ev::Resume: CallCb(gm, kOnResume, {}); break;
        case Ev::Pause: CallCb(gm, kOnPause, {}); break;
        case Ev::Stop: CallCb(gm, kOnStop, {}); break;
        case Ev::Focus: CallCb(gm, kOnWindowFocusChanged, {uint32_t(ev.arg)}); break;
        case Ev::WindowCreated: {
            auto* w = static_cast<ANativeWindow*>(ev.ptr);
            Gl().Init(w);  // make sure the app's surface exists before the game asks for it
            CallCb(gm, kOnNativeWindowCreated, {handle_of(w, false)});
            break;
        }
        case Ev::WindowDestroyed: {
            auto* w = static_cast<ANativeWindow*>(ev.ptr);
            CallCb(gm, kOnNativeWindowDestroyed, {handle_of(w, false)});
            Bridge().ForgetWindow(handle_of(w, false));
            gm.handles.erase(w);
            g.surface_taken = false;
            Gl().DestroySurface();
            break;
        }
        case Ev::InputCreated: CallCb(gm, kOnInputQueueCreated, {handle_of(ev.ptr, true)}); break;
        case Ev::InputDestroyed: {
            CallCb(gm, kOnInputQueueDestroyed, {handle_of(ev.ptr, true)});
            Bridge().ForgetInputQueue(handle_of(ev.ptr, true));
            gm.handles.erase(ev.ptr);
            break;
        }
    }
    if (ev.done) ev.done->set_value();
}

void RunGame() {
    Logf("titan64 milestone 4 - the game runs on Dynarmic (arm64 Android)");
    AAsset* a = AAssetManager_open(g.act->assetManager, "guest/libTestSuite.so", AASSET_MODE_BUFFER);
    if (!a) throw std::runtime_error("asset guest/libTestSuite.so not found in APK");
    const size_t n = static_cast<size_t>(AAsset_getLength(a));
    const auto* data = static_cast<const uint8_t*>(AAsset_getBuffer(a));
    if (!data) throw std::runtime_error("cannot read guest lib asset");
    Logf("guest lib: %zu bytes", n);

    auto gm = std::make_unique<Game>();  // lives until the process dies
    Game& G = *gm;
    Bridge().assets = g.act->assetManager;
    Bridge().on_window_taken = [](bool taken) {
        g.surface_taken = taken;
        if (taken) Logf("[gl] the game created its window surface and now owns the screen");
    };
    RegisterAndroid(G.hle);
    RegisterGles(G.hle);
    RegisterZlib(G.hle);
    InstallGuestRunner(G.hle);
    G.hle.on_fatal = [](const std::string& why) {
        g.fatal = true;
        g.surface_taken = false;  // take the screen back for the banner
        SetBanner(("FATAL: " + why).substr(0, 90).c_str(), Rgb(190, 40, 40));
    };
    G.lib = LoadElf32Bytes(data, n, G.mem, G.hle);
    AAsset_close(a);
    Logf("loaded: image=0x%x bytes, exports=%zu, imports=%zu funcs + %zu data", G.lib.image_size, G.lib.exports.size(),
         G.lib.imported_functions.size(), G.lib.imported_data.size());
    RequestRedraw();

    {  // symbol names for crash / watchdog reports
        auto syms = std::make_shared<std::vector<std::pair<uint32_t, std::string>>>();
        for (const auto& kv : G.lib.exports) syms->emplace_back(kv.second & ~1u, kv.first);
        std::sort(syms->begin(), syms->end());
        G.hle.symbolize = [syms](uint32_t a) -> std::string {
            auto it = std::upper_bound(syms->begin(), syms->end(), a, [](uint32_t v, const std::pair<uint32_t, std::string>& s) { return v < s.first; });
            if (it == syms->begin()) return "[?]";
            --it;
            if (a - it->first > 0x20000) return "[?]";
            char b[24];
            std::snprintf(b, sizeof b, "+0x%x", a - it->first);
            return "[" + it->second + b + "]";
        };
    }
    G.cpu = std::make_unique<Cpu>(G.mem, G.hle);
    G.mem.write<uint16_t>(kScratch, 0x0088);      // lsls r0, r1, #2
    G.mem.write<uint16_t>(kScratch + 2, 0x4770);  // bx lr
    CallResult st = G.cpu->Call(kScratch | 1, {1, 2});
    Logf("CPU self-test: ok=%d r0=%u (expect 8) %s", st.ok, st.r0, st.error.c_str());
    if (!st.ok || st.r0 != 8) {
        SetBanner("FAILED: CPU self-test", Rgb(190, 40, 40));
        return;
    }
    SetBanner("CPU OK - running game constructors...", Rgb(200, 150, 0));
    RequestRedraw();

    int done = 0, total = 0;
    for (uint32_t fn : G.lib.init_array)
        if (fn != 0 && fn != 0xFFFFFFFFu) ++total;
    for (uint32_t fn : G.lib.init_array) {
        if (fn == 0 || fn == 0xFFFFFFFFu) continue;
        CallResult r = G.cpu->Call(fn, {});
        if (!r.ok) {
            Logf("constructor #%d @0x%08x FAILED: %s", done, fn, r.error.c_str());
            char b[96];
            std::snprintf(b, sizeof b, "FAILED at constructor %d/%d", done, total);
            SetBanner(b, Rgb(190, 40, 40));
            return;
        }
        ++done;
        if (done % 100 == 0) Logf("constructors: %d/%d", done, total);
    }
    Logf("all %d constructors ran OK", done);

    auto it = G.lib.exports.find("ANativeActivity_onCreate");
    if (it == G.lib.exports.end()) {
        Logf("the game has no ANativeActivity_onCreate export");
        SetBanner("FAILED: no ANativeActivity_onCreate", Rgb(190, 40, 40));
        return;
    }
    BuildActivity(G);
    SetBanner("Starting the game (native_app_glue)...", Rgb(200, 150, 0));
    g.game_started = true;
    std::thread([&G] {  // watchdog: what is every guest thread doing? (first 30 s every 5 s, then every minute)
        for (int n = 0;; ++n) {
            std::this_thread::sleep_for(std::chrono::seconds(n < 6 ? 5 : 60));
            for (const std::string& l : G.hle.DebugThreads()) Logf("[watch] %s", l.c_str());
        }
    }).detach();
    Logf("calling ANativeActivity_onCreate @0x%08x", it->second);
    CallResult r = G.cpu->Call(it->second, {G.guest_activity, 0, 0}, kForever);
    if (!r.ok) {
        Logf("ANativeActivity_onCreate FAILED: %s", r.error.c_str());
        G.hle.Fatal("ANativeActivity_onCreate failed: " + r.error);
    } else {
        Logf("ANativeActivity_onCreate returned; the game thread is running");
    }

    // Event loop: forwards Android lifecycle events to the guest, keeps the banner alive when the game is not running.
    int idle_log = 0;
    for (;;) {
        Event ev{Ev::Start};
        bool have = false;
        {
            std::unique_lock<std::mutex> lk(g.mu);
            g.cv.wait_for(lk, std::chrono::milliseconds(250), [] { return !g.events.empty(); });
            if (!g.events.empty()) { ev = g.events.front(); g.events.pop_front(); have = true; }
        }
        if (have) {
            if (g.game_started && !g.fatal) {
                Deliver(G, ev);
            } else {  // banner mode: only the surface bookkeeping matters
                if (ev.type == Ev::WindowDestroyed) Gl().DestroySurface();
                if (ev.done) ev.done->set_value();
            }
        }
        if (++idle_log % 120 == 0)  // every ~30 s
            Logf("[status] game %s, %zu imports still unimplemented", g.surface_taken ? "running" : "starting", G.hle.missing_called.size());
    }
}

void* Worker(void*) {
    try {
        RunGame();
    } catch (const std::exception& e) {
        Logf("EXCEPTION: %s", e.what());
        SetBanner("FAILED (exception) - see text", Rgb(190, 40, 40));
    }
    for (;;) std::this_thread::sleep_for(std::chrono::seconds(1));  // the painter keeps the banner on screen
    return nullptr;
}

// Redraws the banner (status + live log) whenever something changed and the game does not own the surface yet.
void* Painter(void*) {
    for (;;) {
        std::this_thread::sleep_for(std::chrono::milliseconds(120));
        bool redraw;
        {
            std::lock_guard<std::mutex> lk(g.mu);
            redraw = g.need_redraw;
        }
        if (redraw && !g.surface_taken) Draw();
    }
    return nullptr;
}

// ---------------------------------------------------------------------------------------------- Android callbacks (UI thread)
void Post(Ev type, void* ptr = nullptr, int arg = 0, bool wait = false) {
    Event ev{type, ptr, arg, nullptr};
    std::future<void> fut;
    if (wait) {
        ev.done = std::make_shared<std::promise<void>>();
        fut = ev.done->get_future();
    }
    {
        std::lock_guard<std::mutex> lk(g.mu);
        g.events.push_back(ev);
    }
    g.cv.notify_all();
    if (wait) fut.wait_for(std::chrono::seconds(2));  // Android needs the window released before we return
}

void OnStart(ANativeActivity*) { Post(Ev::Start); }
void OnResume(ANativeActivity*) { Post(Ev::Resume); }
void OnPause(ANativeActivity*) { Post(Ev::Pause); }
void OnStop(ANativeActivity*) { Post(Ev::Stop); }
void OnFocus(ANativeActivity*, int focus) { Post(Ev::Focus, nullptr, focus); }
void OnWindowCreated(ANativeActivity*, ANativeWindow* w) {
    {
        std::lock_guard<std::mutex> lk(g.mu);
        g.win = w;
        g.need_redraw = true;
    }
    Post(Ev::WindowCreated, w);
}
void OnWindowRedraw(ANativeActivity*, ANativeWindow*) {
    std::lock_guard<std::mutex> lk(g.mu);
    g.need_redraw = true;
    g.cv.notify_all();
}
void OnWindowDestroyed(ANativeActivity*, ANativeWindow* w) {
    {
        std::lock_guard<std::mutex> lk(g.mu);
        g.win = nullptr;
    }
    Post(Ev::WindowDestroyed, w, 0, true);
}
void OnInputCreated(ANativeActivity*, AInputQueue* q) { Post(Ev::InputCreated, q); }
void OnInputDestroyed(ANativeActivity*, AInputQueue* q) { Post(Ev::InputDestroyed, q, 0, true); }
void* OnSaveState(ANativeActivity*, size_t* outLen) { *outLen = 0; return nullptr; }

}  // namespace

extern "C" __attribute__((visibility("default"))) void ANativeActivity_onCreate(ANativeActivity* activity, void*, size_t) {
    g.act = activity;
    ANativeActivityCallbacks* cb = activity->callbacks;
    cb->onStart = OnStart;
    cb->onResume = OnResume;
    cb->onPause = OnPause;
    cb->onStop = OnStop;
    cb->onSaveInstanceState = OnSaveState;
    cb->onWindowFocusChanged = OnFocus;
    cb->onNativeWindowCreated = OnWindowCreated;
    cb->onNativeWindowRedrawNeeded = OnWindowRedraw;
    cb->onNativeWindowDestroyed = OnWindowDestroyed;
    cb->onInputQueueCreated = OnInputCreated;
    cb->onInputQueueDestroyed = OnInputDestroyed;

    if (activity->externalDataPath) {
        std::string p = std::string(activity->externalDataPath) + "/titan64.log";
        g.log1 = std::fopen(p.c_str(), "w");
    }
    mkdir("/sdcard/TitanSoulsSave", 0777);
    g.log2 = std::fopen("/sdcard/TitanSoulsSave/titan64.log", "w");
    SetLogSink(Sink);

    pthread_attr_t at;
    pthread_attr_init(&at);
    pthread_attr_setstacksize(&at, 8u << 20);
    pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
    pthread_t t, painter;
    pthread_create(&painter, &at, Painter, nullptr);
    pthread_create(&t, &at, Worker, nullptr);
    pthread_attr_destroy(&at);
}
