// Android entry point (NativeActivity). Milestone 3:
//   * loads the original 32-bit ARM libTestSuite.so (shipped as asset guest/libTestSuite.so)
//   * boots it inside Dynarmic (our host lib is the arm64 libTestSuite.so that NativeActivity loads)
//   * runs a CPU self-test and the game's static constructors
//   * shows the result on screen (bitmap font) and in a log file
#include <android/asset_manager.h>
#include <android/log.h>
#include <android/native_activity.h>
#include <android/native_window.h>
#include <pthread.h>
#include <sys/stat.h>

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

#include "cpu.h"
#include "elf32.h"
#include "font8x16.h"
#include "hle.h"
#include "log.h"

using namespace t64;

namespace {

constexpr uint32_t Rgb(uint32_t r, uint32_t g, uint32_t b) { return 0xFF000000u | (b << 16) | (g << 8) | r; }  // RGBA_8888, little endian

struct State {
    ANativeActivity* act = nullptr;
    std::mutex mu;
    ANativeWindow* win = nullptr;
    std::vector<std::string> lines;
    std::string banner = "titan64: starting...";
    uint32_t banner_color = Rgb(200, 150, 0);
    FILE* log1 = nullptr;
    FILE* log2 = nullptr;
};
State g;

void FillRect(uint32_t* px, int stride, int W, int H, int x0, int y0, int w, int h, uint32_t c) {
    for (int y = y0; y < y0 + h && y < H; ++y)
        for (int x = x0; x < x0 + w && x < W; ++x) px[y * stride + x] = c;
}

void DrawText(uint32_t* px, int stride, int W, int H, int x, int y, int sc, const char* s, uint32_t col) {
    for (; *s; ++s, x += 8 * sc) {
        unsigned char ch = static_cast<unsigned char>(*s);
        if (ch < 32 || ch > 126) ch = '?';
        const uint8_t* gl = kFont8x16[ch - 32];
        for (int r = 0; r < 16; ++r)
            for (int c = 0; c < 8; ++c)
                if (gl[r] & (0x80 >> c)) FillRect(px, stride, W, H, x + c * sc, y + r * sc, sc, sc, col);
    }
}

void Draw() {
    std::lock_guard<std::mutex> lk(g.mu);
    if (!g.win) return;
    ANativeWindow_Buffer b;
    if (ANativeWindow_lock(g.win, &b, nullptr) != 0) return;
    auto* px = static_cast<uint32_t*>(b.bits);
    const int W = b.width, H = b.height, S = b.stride;
    FillRect(px, S, W, H, 0, 0, W, H, Rgb(18, 20, 28));
    const int sc = W >= 1600 ? 3 : 2;
    const int bar = 16 * (sc + 1) + 24;
    FillRect(px, S, W, H, 0, 0, W, bar, g.banner_color);
    DrawText(px, S, W, H, 16, 12, sc + 1, g.banner.c_str(), Rgb(255, 255, 255));
    const int cols = (W - 32) / (8 * sc);
    const int rows = (H - bar - 24) / (16 * sc);
    // wrap lines, then show the tail that fits
    std::vector<std::string> wrapped;
    for (const auto& l : g.lines) {
        if (l.empty()) { wrapped.emplace_back(); continue; }
        for (size_t i = 0; i < l.size(); i += static_cast<size_t>(cols)) wrapped.push_back(l.substr(i, static_cast<size_t>(cols)));
    }
    int start = static_cast<int>(wrapped.size()) > rows ? static_cast<int>(wrapped.size()) - rows : 0;
    int y = bar + 16;
    for (int i = start; i < static_cast<int>(wrapped.size()); ++i, y += 16 * sc)
        DrawText(px, S, W, H, 16, y, sc, wrapped[static_cast<size_t>(i)].c_str(), Rgb(220, 220, 220));
    ANativeWindow_unlockAndPost(g.win);
}

void Sink(const char* line) {
    __android_log_print(ANDROID_LOG_INFO, "titan64", "%s", line);
    {
        std::lock_guard<std::mutex> lk(g.mu);
        g.lines.emplace_back(line);
        if (g.lines.size() > 400) g.lines.erase(g.lines.begin(), g.lines.begin() + 100);
        if (g.log1) { std::fprintf(g.log1, "%s\n", line); std::fflush(g.log1); }
        if (g.log2) { std::fprintf(g.log2, "%s\n", line); std::fflush(g.log2); }
    }
}

void SetBanner(const char* text, uint32_t color) {
    std::lock_guard<std::mutex> lk(g.mu);
    g.banner = text;
    g.banner_color = color;
}

void RunMilestone() {
    Logf("titan64 milestone 3 - Dynarmic on arm64 Android");
    AAsset* a = AAssetManager_open(g.act->assetManager, "guest/libTestSuite.so", AASSET_MODE_BUFFER);
    if (!a) throw std::runtime_error("asset guest/libTestSuite.so not found in APK");
    const size_t n = static_cast<size_t>(AAsset_getLength(a));
    const auto* data = static_cast<const uint8_t*>(AAsset_getBuffer(a));
    if (!data) throw std::runtime_error("cannot read guest lib asset");
    Logf("guest lib: %zu bytes", n);

    GuestMemory mem;
    Hle hle(mem);
    LoadedLib lib = LoadElf32Bytes(data, n, mem, hle);
    AAsset_close(a);
    Logf("loaded: image=0x%x bytes, exports=%zu, imports=%zu funcs + %zu data", lib.image_size, lib.exports.size(),
         lib.imported_functions.size(), lib.imported_data.size());
    Draw();

    Cpu cpu(mem, hle);
    mem.write<uint16_t>(kScratch, 0x0088);      // lsls r0, r1, #2
    mem.write<uint16_t>(kScratch + 2, 0x4770);  // bx lr
    CallResult st = cpu.Call(kScratch | 1, {1, 2});
    Logf("CPU self-test: ok=%d r0=%u (expect 8) %s", st.ok, st.r0, st.error.c_str());
    if (!st.ok || st.r0 != 8) {
        SetBanner("FAILED: CPU self-test", Rgb(190, 40, 40));
        return;
    }
    SetBanner("CPU OK - running game constructors...", Rgb(200, 150, 0));
    Draw();

    int done = 0, total = 0;
    for (uint32_t fn : lib.init_array)
        if (fn != 0 && fn != 0xFFFFFFFFu) ++total;
    for (uint32_t fn : lib.init_array) {
        if (fn == 0 || fn == 0xFFFFFFFFu) continue;
        CallResult r = cpu.Call(fn, {});
        if (!r.ok) {
            Logf("constructor #%d @0x%08x FAILED: %s", done, fn, r.error.c_str());
            char b[96];
            std::snprintf(b, sizeof b, "FAILED at constructor %d/%d", done, total);
            SetBanner(b, Rgb(190, 40, 40));
            return;
        }
        ++done;
        if (done % 50 == 0) { Logf("constructors: %d/%d", done, total); Draw(); }
    }
    Logf("all %d constructors ran OK. imports called but missing: %zu", done, hle.missing_called.size());
    for (const auto& m : hle.missing_called) Logf("  missing import: %s", m.c_str());
    char b[96];
    std::snprintf(b, sizeof b, "MILESTONE 3 OK: %d/%d constructors", done, total);
    SetBanner(b, Rgb(30, 150, 60));
    Logf("Next milestone: android_main / EGL / GL.");
}

void* Worker(void*) {
    try {
        RunMilestone();
    } catch (const std::exception& e) {
        Logf("EXCEPTION: %s", e.what());
        SetBanner("FAILED (exception) - see text", Rgb(190, 40, 40));
    }
    Draw();
    return nullptr;
}

void OnWindowCreated(ANativeActivity*, ANativeWindow* w) {
    ANativeWindow_setBuffersGeometry(w, 0, 0, WINDOW_FORMAT_RGBA_8888);
    {
        std::lock_guard<std::mutex> lk(g.mu);
        g.win = w;
    }
    Draw();
}
void OnWindowRedraw(ANativeActivity*, ANativeWindow*) { Draw(); }
void OnWindowDestroyed(ANativeActivity*, ANativeWindow*) {
    std::lock_guard<std::mutex> lk(g.mu);
    g.win = nullptr;
}

}  // namespace

extern "C" __attribute__((visibility("default"))) void ANativeActivity_onCreate(ANativeActivity* activity, void*, size_t) {
    g.act = activity;
    activity->callbacks->onNativeWindowCreated = OnWindowCreated;
    activity->callbacks->onNativeWindowRedrawNeeded = OnWindowRedraw;
    activity->callbacks->onNativeWindowDestroyed = OnWindowDestroyed;

    if (activity->externalDataPath) {
        std::string p = std::string(activity->externalDataPath) + "/titan64.log";
        g.log1 = std::fopen(p.c_str(), "w");
    }
    mkdir("/sdcard/TitanSoulsSave", 0777);
    g.log2 = std::fopen("/sdcard/TitanSoulsSave/titan64.log", "w");
    SetLogSink(Sink);

    pthread_attr_t at;
    pthread_attr_init(&at);
    pthread_attr_setstacksize(&at, 8u << 20);
    pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
    pthread_t t;
    pthread_create(&t, &at, Worker, nullptr);
    pthread_attr_destroy(&at);
}
