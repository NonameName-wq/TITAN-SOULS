// pthread / semaphore / sleep / errno emulation for the guest.
// Every guest thread runs on its own host thread with its own Dynarmic instance. All blocking primitives
// share ONE global lock + condition variable ("big lock"): simple, obviously correct, and plenty fast for the
// handful of threads a game like this creates.
#include <pthread.h>
#include <unistd.h>

#include <chrono>
#include <condition_variable>
#include <ctime>
#include <memory>
#include <mutex>
#include <thread>
#include <unordered_map>

#include "hle.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {
namespace {

constexpr uint32_t kESRCH = 3, kEAGAIN = 11, kEBUSY = 16, kEINVAL = 22, kETIMEDOUT = 110;

struct MutexState { uint32_t owner = 0; int count = 0; int type = 0; };  // type: 0 normal, 1 recursive, 2 errorcheck
struct CondState { int waiters = 0; int permits = 0; };
struct ThreadState { bool finished = false; uint32_t ret = 0; };

struct Sync {
    std::mutex mu;
    std::condition_variable cv;
    std::unordered_map<uint32_t, MutexState> mutexes;
    std::unordered_map<uint32_t, CondState> conds;
    std::unordered_map<uint32_t, int64_t> sems;
    std::unordered_map<uint32_t, ThreadState> threads;
    uint32_t next_tid = 2;
    std::atomic<uint32_t> next_key{1};
};
Sync& S() { static Sync* s = new Sync; return *s; }  // intentionally leaked (threads may outlive static destruction)

thread_local uint32_t t_tid = 0;
thread_local std::unordered_map<uint32_t, uint32_t> t_tls;

uint32_t Self() {
    if (!t_tid) {
        std::lock_guard<std::mutex> lk(S().mu);
        t_tid = S().next_tid++;
    }
    return t_tid;
}

// Absolute CLOCK_REALTIME timespec in guest memory -> time left from now, in nanoseconds (>= 0).
std::chrono::nanoseconds Remaining(GuestMemory& m, uint32_t ts) {
    using namespace std::chrono;
    const int64_t sec = m.read<int32_t>(ts), nsec = m.read<int32_t>(ts + 4);
    auto target = seconds(sec) + nanoseconds(nsec);
    auto now = duration_cast<nanoseconds>(system_clock::now().time_since_epoch());
    auto left = target - now;
    return left.count() > 0 ? duration_cast<nanoseconds>(left) : nanoseconds(0);
}

MutexState& GetMutex(GuestMemory& m, uint32_t addr) {
    auto& mx = S().mutexes;
    auto it = mx.find(addr);
    if (it == mx.end()) {
        MutexState st;
        st.type = int((m.read<uint32_t>(addr) >> 14) & 3);  // bionic static initializers: 0x0000 normal, 0x4000 recursive, 0x8000 errorcheck
        it = mx.emplace(addr, st).first;
    }
    return it->second;
}

void HostThread(std::function<void()> fn) {
    struct Box { std::function<void()> fn; };
    auto* box = new Box{std::move(fn)};
    pthread_attr_t at;
    pthread_attr_init(&at);
    pthread_attr_setstacksize(&at, 8u << 20);  // Dynarmic's translator recurses deeply
    pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
    pthread_t t;
    pthread_create(&t, &at, [](void* p) -> void* {
        std::unique_ptr<Box> b(static_cast<Box*>(p));
        b->fn();
        return nullptr;
    }, box);
    pthread_attr_destroy(&at);
}

}  // namespace

void RegisterSync(Hle& h) {
    GuestMemory& m = h.mem;
    h.wake_hook = [] {
        { std::lock_guard<std::mutex> lk(S().mu); }  // pairs with the predicates below
        S().cv.notify_all();
    };
    auto stop = [&h] { return h.fatal.load(); };

    // ---- errno / misc ----
    h.Register("__errno", [&h](CallCtx& c) { c.ret(h.ErrnoAddr()); });
    h.Register("sched_yield", [](CallCtx& c) { std::this_thread::yield(); c.ret(0); });
    h.Register("prctl", [](CallCtx& c) { c.ret(0); });
    h.Register("sysconf", [](CallCtx& c) {
        switch (c.arg(0)) {
            case 2: c.ret(100); break;                               // _SC_CLK_TCK
            case 4: c.ret(1024); break;                              // _SC_OPEN_MAX
            case 39: c.ret(4096); break;                             // _SC_PAGESIZE
            case 96: case 97: {                                      // _SC_NPROCESSORS_CONF / ONLN
                unsigned n = std::thread::hardware_concurrency();
                c.ret(n ? n : 4);
                break;
            }
            case 98: c.ret(kArenaSize / 4096); break;                // _SC_PHYS_PAGES
            case 99: c.ret(kArenaSize / 8192); break;                // _SC_AVPHYS_PAGES
            default: c.ret(0xFFFFFFFFu); break;
        }
    });
    h.Register("syscall", [&h](CallCtx& c) {
        if (c.arg(0) == 224) { c.ret(Self()); return; }  // gettid
        h.SetErrno(38);                                   // ENOSYS
        c.ret(0xFFFFFFFFu);
    });

    // ---- sleeping (wakes early on fatal errors) ----
    auto sleep_ns = [stop](std::chrono::nanoseconds ns) {
        std::unique_lock<std::mutex> lk(S().mu);
        S().cv.wait_for(lk, ns, stop);
    };
    h.Register("nanosleep", [&m, sleep_ns](CallCtx& c) {
        const int64_t sec = m.read<int32_t>(c.arg(0)), nsec = m.read<int32_t>(c.arg(0) + 4);
        sleep_ns(std::chrono::seconds(sec) + std::chrono::nanoseconds(nsec));
        if (c.arg(1)) { m.write<int32_t>(c.arg(1), 0); m.write<int32_t>(c.arg(1) + 4, 0); }
        c.ret(0);
    });
    h.Register("sleep", [sleep_ns](CallCtx& c) { sleep_ns(std::chrono::seconds(c.arg(0))); c.ret(0); });

    // ---- thread attributes (bionic pthread_attr_t: flags, stack_base, stack_size, guard, policy, priority) ----
    h.Register("pthread_attr_init", [&m](CallCtx& c) {
        for (uint32_t i = 0; i < 24; i += 4) m.write<uint32_t>(c.arg(0) + i, 0);
        m.write<uint32_t>(c.arg(0) + 8, 1u << 20);
        c.ret(0);
    });
    h.Register("pthread_attr_destroy", [](CallCtx& c) { c.ret(0); });
    h.Register("pthread_attr_setdetachstate", [&m](CallCtx& c) {
        uint32_t fl = m.read<uint32_t>(c.arg(0));
        fl = c.arg(1) == 1 ? (fl | 1u) : (fl & ~1u);
        m.write<uint32_t>(c.arg(0), fl);
        c.ret(0);
    });
    h.Register("pthread_attr_setstacksize", [&m](CallCtx& c) { m.write<uint32_t>(c.arg(0) + 8, c.arg(1)); c.ret(0); });
    h.Register("pthread_setname_np", [](CallCtx& c) { c.ret(0); });

    // ---- thread lifecycle ----
    h.Register("pthread_create", [&h, &m](CallCtx& c) {
        const uint32_t out = c.arg(0), attr = c.arg(1), start = c.arg(2), arg = c.arg(3);
        uint32_t stack_size = 1u << 20;
        if (attr) {
            const uint32_t ss = m.read<uint32_t>(attr + 8);
            if (ss) stack_size = ss;
        }
        if (stack_size < (64u << 10)) stack_size = 64u << 10;
        if (stack_size > (8u << 20)) stack_size = 8u << 20;
        stack_size = (stack_size + 0xFFFFu) & ~0xFFFFu;
        const uint32_t top = h.AllocStack(stack_size);
        if (!top) { Logf("[thread] out of guest stack space"); c.ret(kEAGAIN); return; }
        uint32_t tid;
        {
            std::lock_guard<std::mutex> lk(S().mu);
            tid = S().next_tid++;
            S().threads[tid] = ThreadState{};
        }
        if (out) m.write<uint32_t>(out, tid);
        Logf("[thread] create tid=%u entry=0x%08x stack=%uKB", tid, start, stack_size >> 10);
        HostThread([&h, tid, start, arg, top, stack_size] {
            t_tid = tid;
            uint32_t r0 = 0;
            std::string err;
            const bool ok = h.run_thread ? h.run_thread(start, arg, top, &r0, &err) : false;
            if (!ok && !h.fatal) h.Fatal("guest thread " + std::to_string(tid) + " stopped: " + (err.empty() ? "no runner" : err));
            if (h.on_thread_exit) h.on_thread_exit();
            h.FreeStack(top, stack_size);
            {
                std::lock_guard<std::mutex> lk(S().mu);
                auto& t = S().threads[tid];
                t.finished = true;
                t.ret = r0;
            }
            S().cv.notify_all();
        });
        c.ret(0);
    });
    h.Register("pthread_join", [&m, stop](CallCtx& c) {
        const uint32_t tid = c.arg(0);
        std::unique_lock<std::mutex> lk(S().mu);
        auto it = S().threads.find(tid);
        if (it == S().threads.end()) { c.ret(kESRCH); return; }
        S().cv.wait(lk, [&] { return S().threads[tid].finished || stop(); });
        const uint32_t ret = S().threads[tid].ret;
        S().threads.erase(tid);
        lk.unlock();
        if (c.arg(1)) m.write<uint32_t>(c.arg(1), ret);
        c.ret(0);
    });
    h.Register("pthread_detach", [](CallCtx& c) { c.ret(0); });
    h.Register("pthread_self", [](CallCtx& c) { c.ret(Self()); });
    h.Register("pthread_equal", [](CallCtx& c) { c.ret(c.arg(0) == c.arg(1)); });
    h.Register("pthread_key_create", [&m](CallCtx& c) { m.write<uint32_t>(c.arg(0), S().next_key++); c.ret(0); });
    h.Register("pthread_key_delete", [](CallCtx& c) { c.ret(0); });
    h.Register("pthread_setspecific", [](CallCtx& c) { t_tls[c.arg(0)] = c.arg(1); c.ret(0); });
    h.Register("pthread_getspecific", [](CallCtx& c) {
        auto it = t_tls.find(c.arg(0));
        c.ret(it == t_tls.end() ? 0 : it->second);
    });

    // ---- mutexes (bionic pthread_mutex_t is one int; bits 14-15 hold the type) ----
    h.Register("pthread_mutexattr_init", [&m](CallCtx& c) { m.write<uint32_t>(c.arg(0), 0); c.ret(0); });
    h.Register("pthread_mutexattr_destroy", [](CallCtx& c) { c.ret(0); });
    h.Register("pthread_mutexattr_settype", [&m](CallCtx& c) { m.write<uint32_t>(c.arg(0), c.arg(1)); c.ret(0); });
    h.Register("pthread_mutex_init", [&m](CallCtx& c) {
        const uint32_t type = c.arg(1) ? (m.read<uint32_t>(c.arg(1)) & 3u) : 0u;
        std::lock_guard<std::mutex> lk(S().mu);
        MutexState st;
        st.type = int(type);
        S().mutexes[c.arg(0)] = st;
        m.write<uint32_t>(c.arg(0), type << 14);
        c.ret(0);
    });
    h.Register("pthread_mutex_destroy", [](CallCtx& c) {
        std::lock_guard<std::mutex> lk(S().mu);
        S().mutexes.erase(c.arg(0));
        c.ret(0);
    });
    h.Register("pthread_mutex_lock", [&m, stop](CallCtx& c) {
        const uint32_t me = Self();
        std::unique_lock<std::mutex> lk(S().mu);
        MutexState& mx = GetMutex(m, c.arg(0));
        if (mx.owner == me) { ++mx.count; c.ret(0); return; }  // recursive (a normal mutex would deadlock; be forgiving)
        S().cv.wait(lk, [&] { return mx.owner == 0 || stop(); });
        mx.owner = me;
        mx.count = 1;
        c.ret(0);
    });
    h.Register("pthread_mutex_trylock", [&m](CallCtx& c) {
        const uint32_t me = Self();
        std::lock_guard<std::mutex> lk(S().mu);
        MutexState& mx = GetMutex(m, c.arg(0));
        if (mx.owner == me && mx.type == 1) { ++mx.count; c.ret(0); return; }
        if (mx.owner != 0) { c.ret(kEBUSY); return; }
        mx.owner = me;
        mx.count = 1;
        c.ret(0);
    });
    h.Register("pthread_mutex_unlock", [&m](CallCtx& c) {
        const uint32_t me = Self();
        bool released = false;
        {
            std::lock_guard<std::mutex> lk(S().mu);
            MutexState& mx = GetMutex(m, c.arg(0));
            if (mx.owner == me && --mx.count <= 0) { mx.owner = 0; mx.count = 0; released = true; }
        }
        if (released) S().cv.notify_all();
        c.ret(0);
    });

    // ---- condition variables (permit counting gives exact signal/broadcast semantics, with timeouts) ----
    h.Register("pthread_cond_init", [&m](CallCtx& c) {
        std::lock_guard<std::mutex> lk(S().mu);
        S().conds[c.arg(0)] = CondState{};
        m.write<uint32_t>(c.arg(0), 0);
        c.ret(0);
    });
    h.Register("pthread_cond_destroy", [](CallCtx& c) { c.ret(0); });
    auto cond_wait = [&m, stop](CallCtx& c, bool timed) {
        const uint32_t me = Self();
        std::unique_lock<std::mutex> lk(S().mu);
        MutexState& mx = GetMutex(m, c.arg(1));
        const int saved = mx.count > 0 ? mx.count : 1;
        mx.owner = 0;
        mx.count = 0;
        CondState& cd = S().conds[c.arg(0)];
        ++cd.waiters;
        S().cv.notify_all();  // the mutex was released
        bool signalled = true;
        if (timed) {
            signalled = S().cv.wait_for(lk, Remaining(m, c.arg(2)), [&] { return cd.permits > 0 || stop(); });
        } else {
            S().cv.wait(lk, [&] { return cd.permits > 0 || stop(); });
        }
        if (cd.permits > 0) --cd.permits;
        --cd.waiters;
        S().cv.wait(lk, [&] { return mx.owner == 0 || stop(); });  // re-acquire the mutex
        mx.owner = me;
        mx.count = saved;
        c.ret(signalled ? 0 : kETIMEDOUT);
    };
    h.Register("pthread_cond_wait", [cond_wait](CallCtx& c) { cond_wait(c, false); });
    h.Register("pthread_cond_timedwait", [cond_wait](CallCtx& c) { cond_wait(c, true); });
    h.Register("pthread_cond_signal", [](CallCtx& c) {
        {
            std::lock_guard<std::mutex> lk(S().mu);
            CondState& cd = S().conds[c.arg(0)];
            if (cd.permits < cd.waiters) ++cd.permits;
        }
        S().cv.notify_all();
        c.ret(0);
    });
    h.Register("pthread_cond_broadcast", [](CallCtx& c) {
        {
            std::lock_guard<std::mutex> lk(S().mu);
            CondState& cd = S().conds[c.arg(0)];
            cd.permits = cd.waiters;
        }
        S().cv.notify_all();
        c.ret(0);
    });

    // ---- semaphores ----
    h.Register("sem_init", [](CallCtx& c) {
        std::lock_guard<std::mutex> lk(S().mu);
        S().sems[c.arg(0)] = int64_t(c.arg(2));
        c.ret(0);
    });
    h.Register("sem_destroy", [](CallCtx& c) { c.ret(0); });
    h.Register("sem_post", [](CallCtx& c) {
        {
            std::lock_guard<std::mutex> lk(S().mu);
            ++S().sems[c.arg(0)];
        }
        S().cv.notify_all();
        c.ret(0);
    });
    h.Register("sem_wait", [stop](CallCtx& c) {
        std::unique_lock<std::mutex> lk(S().mu);
        int64_t& v = S().sems[c.arg(0)];
        S().cv.wait(lk, [&] { return v > 0 || stop(); });
        if (v > 0) --v;
        c.ret(0);
    });
    h.Register("sem_trywait", [&h](CallCtx& c) {
        std::unique_lock<std::mutex> lk(S().mu);
        int64_t& v = S().sems[c.arg(0)];
        if (v > 0) { --v; c.ret(0); return; }
        lk.unlock();
        h.SetErrno(int(kEAGAIN));
        c.ret(0xFFFFFFFFu);
    });
    h.Register("sem_timedwait", [&h, &m, stop](CallCtx& c) {
        std::unique_lock<std::mutex> lk(S().mu);
        int64_t& v = S().sems[c.arg(0)];
        const bool ok = S().cv.wait_for(lk, Remaining(m, c.arg(1)), [&] { return v > 0 || stop(); });
        if (ok && v > 0) { --v; c.ret(0); return; }
        lk.unlock();
        h.SetErrno(int(kETIMEDOUT));
        c.ret(0xFFFFFFFFu);
    });
    (void)kEINVAL;
}

}  // namespace t64
