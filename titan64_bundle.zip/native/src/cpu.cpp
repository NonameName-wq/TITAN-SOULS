#include "cpu.h"
#include <atomic>
#include <cstdio>
#include <dynarmic/interface/A32/a32.h>
#include <dynarmic/interface/A32/config.h>
#include <dynarmic/interface/exclusive_monitor.h>

namespace t64 {

using namespace Dynarmic::A32;

namespace {

constexpr bool kUsePageTable = true;  // direct memory access for the whole arena; callbacks only for the vector page / faults
constexpr size_t kMaxProcessors = 64;

Dynarmic::ExclusiveMonitor& GlobalMonitor() {
    static auto* m = new Dynarmic::ExclusiveMonitor(kMaxProcessors);
    return *m;
}
std::atomic<size_t> g_next_processor{0};

using PageTable = std::array<uint8_t*, UserConfig::NUM_PAGE_TABLE_ENTRIES>;
PageTable* GetPageTable(GuestMemory& mem) {
    static PageTable* table = [&mem] {
        auto* t = new PageTable;
        t->fill(nullptr);
        for (uint32_t p = 0; p < kArenaSize / 4096; ++p) (*t)[p] = mem.host(p * 4096);
        return t;
    }();
    return table;
}

}  // namespace

struct Cpu::Impl final : UserCallbacks {
    GuestMemory& mem;
    Hle& hle;
    std::unique_ptr<Jit> jit;
    uint32_t stack_top;
    uint64_t ticks_left = 0;
    bool done = false;
    std::string error;

    Impl(GuestMemory& m, Hle& h, uint32_t top, bool small_cache) : mem(m), hle(h), stack_top(top) {
        UserConfig cfg;
        cfg.callbacks = this;
        cfg.arch_version = ArchVersion::v7;  // Android armeabi-v7a
        cfg.global_monitor = &GlobalMonitor();
        cfg.processor_id = g_next_processor++ % kMaxProcessors;
        cfg.code_cache_size = small_cache ? 48u * 1024 * 1024 : 128u * 1024 * 1024;
        if (kUsePageTable) cfg.page_table = GetPageTable(mem);
        jit = std::make_unique<Jit>(cfg);
    }

    uint8_t MemoryRead8(uint32_t a) override { return mem.read<uint8_t>(a); }
    uint16_t MemoryRead16(uint32_t a) override { return mem.read<uint16_t>(a); }
    uint32_t MemoryRead32(uint32_t a) override { return mem.read<uint32_t>(a); }
    uint64_t MemoryRead64(uint32_t a) override { return mem.read<uint64_t>(a); }
    void MemoryWrite8(uint32_t a, uint8_t v) override { mem.write(a, v); }
    void MemoryWrite16(uint32_t a, uint16_t v) override { mem.write(a, v); }
    void MemoryWrite32(uint32_t a, uint32_t v) override { mem.write(a, v); }
    void MemoryWrite64(uint32_t a, uint64_t v) override { mem.write(a, v); }

    // ldrex/strex: the monitor decides whether the reservation is still valid; the actual store is a real host CAS
    // so that several guest threads can safely share lock words.
    template <class T> bool WriteExclusive(uint32_t a, T v, T expected) {
        if (!mem.valid(a, sizeof(T))) return false;
        T* p = reinterpret_cast<T*>(mem.host(a));
        return __atomic_compare_exchange_n(p, &expected, v, false, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST);
    }
    bool MemoryWriteExclusive8(uint32_t a, uint8_t v, uint8_t e) override { return WriteExclusive(a, v, e); }
    bool MemoryWriteExclusive16(uint32_t a, uint16_t v, uint16_t e) override { return WriteExclusive(a, v, e); }
    bool MemoryWriteExclusive32(uint32_t a, uint32_t v, uint32_t e) override { return WriteExclusive(a, v, e); }
    bool MemoryWriteExclusive64(uint32_t a, uint64_t v, uint64_t e) override { return WriteExclusive(a, v, e); }

    void InterpreterFallback(uint32_t pc, size_t n) override {
        char b[96];
        std::snprintf(b, sizeof b, "InterpreterFallback at pc=0x%08x (%zu instr)", pc, n);
        error = b;
        jit->HaltExecution();
    }
    void CallSVC(uint32_t swi) override {
        hle.Dispatch(swi, jit->Regs());
        if (hle.halt_requested) {
            error = hle.halt_reason.empty() ? std::string("halted") : hle.halt_reason;
            jit->HaltExecution();
        }
    }
    void ExceptionRaised(uint32_t pc, Exception e) override {
        if (e == Exception::Breakpoint && (pc & ~1u) == kRetTramp) {
            done = true;
        } else {
            char b[96];
            std::snprintf(b, sizeof b, "exception %d at pc=0x%08x", static_cast<int>(e), pc);
            error = b;
        }
        jit->HaltExecution();
    }
    void AddTicks(uint64_t t) override { ticks_left = t > ticks_left ? 0 : ticks_left - t; }
    uint64_t GetTicksRemaining() override { return ticks_left; }
};

Cpu::Cpu(GuestMemory& mem, Hle& hle, uint32_t stack_top, bool small_cache)
    : p_(std::make_unique<Impl>(mem, hle, stack_top, small_cache)) {}
Cpu::~Cpu() = default;

CallResult Cpu::Call(uint32_t addr, const std::vector<uint32_t>& args, uint64_t max_ticks) {
    Impl& s = *p_;
    auto& R = s.jit->Regs();
    R.fill(0);
    const uint32_t extra = args.size() > 4 ? static_cast<uint32_t>(args.size() - 4) : 0;
    const uint32_t sp = (s.stack_top - 0x100 - 4 * extra) & ~7u;
    for (size_t i = 0; i < args.size(); ++i) {
        if (i < 4) R[i] = args[i];
        else s.mem.write<uint32_t>(sp + 4 * static_cast<uint32_t>(i - 4), args[i]);
    }
    R[13] = sp;
    R[14] = kRetTramp | 1;
    R[15] = addr & ~1u;
    s.jit->SetCpsr((addr & 1) ? 0x30u : 0x10u);  // user mode, T bit for Thumb
    s.jit->ClearHalt();
    s.done = false;
    s.error.clear();
    s.ticks_left = max_ticks;

    while (!s.done && s.error.empty()) {
        if (s.hle.halt_requested) { s.error = s.hle.halt_reason.empty() ? std::string("halted") : s.hle.halt_reason; break; }
        s.jit->Run();
        if (s.done || !s.error.empty()) break;
        if (s.ticks_left == 0) { s.error = "tick budget exhausted (possible infinite loop)"; break; }
        s.error = "unexpected halt";
    }
    CallResult res;
    res.ok = s.done && s.error.empty();
    res.error = s.error;
    res.r0 = s.jit->Regs()[0];
    res.r1 = s.jit->Regs()[1];
    return res;
}

void InstallGuestRunner(Hle& hle) {
    // Nested call on the current host thread. Each nesting level uses its own small Cpu + stack (kept per thread).
    hle.call_guest = [&hle](uint32_t addr, const std::vector<uint32_t>& args, uint32_t* r0, std::string* err) -> bool {
        thread_local std::vector<std::unique_ptr<Cpu>> pool;
        thread_local size_t depth = 0;
        if (depth >= pool.size()) {
            const uint32_t top = hle.AllocStack(256u << 10);
            if (!top) { if (err) *err = "out of guest stack space for a nested call"; return false; }
            pool.push_back(std::make_unique<Cpu>(hle.mem, hle, top, true));
        }
        Cpu& c = *pool[depth++];
        const CallResult r = c.Call(addr, args, kForever);
        --depth;
        if (r0) *r0 = r.r0;
        if (!r.ok && err) *err = r.error;
        return r.ok;
    };
    // A brand-new guest thread: fresh Cpu with the stack that pthread_create allocated.
    hle.run_thread = [&hle](uint32_t addr, uint32_t arg, uint32_t top, uint32_t* r0, std::string* err) -> bool {
        Cpu cpu(hle.mem, hle, top, true);
        const CallResult r = cpu.Call(addr, {arg}, kForever);
        if (r0) *r0 = r.r0;
        if (!r.ok && err) *err = r.error;
        return r.ok;
    };
}

}  // namespace t64
