#include "cpu.h"
#include <cstdio>
#include <dynarmic/interface/A32/a32.h>
#include <dynarmic/interface/A32/config.h>
#include <dynarmic/interface/exclusive_monitor.h>

namespace t64 {

using namespace Dynarmic::A32;

struct Cpu::Impl final : UserCallbacks {
    GuestMemory& mem;
    Hle& hle;
    Dynarmic::ExclusiveMonitor monitor{1};
    std::unique_ptr<Jit> jit;
    uint64_t ticks_left = 0;
    bool done = false;
    std::string error;

    Impl(GuestMemory& m, Hle& h) : mem(m), hle(h) {
        UserConfig cfg;
        cfg.callbacks = this;
        cfg.arch_version = ArchVersion::v7;  // Android armeabi-v7a
        cfg.global_monitor = &monitor;
        cfg.processor_id = 0;
        jit = std::make_unique<Jit>(cfg);
        // TODO (speed): use cfg.fastmem_pointer / page_table pointing at the arena instead of callbacks.
    }

    uint8_t MemoryRead8(uint32_t a) override { return mem.read<uint8_t>(a); }
    uint16_t MemoryRead16(uint32_t a) override { return mem.read<uint16_t>(a); }
    uint32_t MemoryRead32(uint32_t a) override { return mem.read<uint32_t>(a); }
    uint64_t MemoryRead64(uint32_t a) override { return mem.read<uint64_t>(a); }
    void MemoryWrite8(uint32_t a, uint8_t v) override { mem.write(a, v); }
    void MemoryWrite16(uint32_t a, uint16_t v) override { mem.write(a, v); }
    void MemoryWrite32(uint32_t a, uint32_t v) override { mem.write(a, v); }
    void MemoryWrite64(uint32_t a, uint64_t v) override { mem.write(a, v); }

    template <class T> bool WriteExclusive(uint32_t a, T v, T expected) {
        if (mem.read<T>(a) != expected) return false;
        mem.write<T>(a, v);
        return true;
    }
    bool MemoryWriteExclusive8(uint32_t a, uint8_t v, uint8_t e) override { return WriteExclusive(a, v, e); }
    bool MemoryWriteExclusive16(uint32_t a, uint16_t v, uint16_t e) override { return WriteExclusive(a, v, e); }
    bool MemoryWriteExclusive32(uint32_t a, uint32_t v, uint32_t e) override { return WriteExclusive(a, v, e); }
    bool MemoryWriteExclusive64(uint32_t a, uint64_t v, uint64_t e) override { return WriteExclusive(a, v, e); }

    void InterpreterFallback(uint32_t pc, size_t n) override {
        char b[96];
        std::snprintf(b, sizeof b, "InterpreterFallback at pc=0x%08x (%zu instr)", pc, n);
        error = b;
        jit->HaltExecution();
    }
    void CallSVC(uint32_t swi) override {
        hle.Dispatch(swi, jit->Regs());
        if (hle.halt_requested) { error = hle.halt_reason; jit->HaltExecution(); }
    }
    void ExceptionRaised(uint32_t pc, Exception e) override {
        if (e == Exception::Breakpoint && (pc & ~1u) == kRetTramp) {
            done = true;
        } else {
            char b[96];
            std::snprintf(b, sizeof b, "exception %d at pc=0x%08x", static_cast<int>(e), pc);
            error = b;
        }
        jit->HaltExecution();
    }
    void AddTicks(uint64_t t) override { ticks_left = t > ticks_left ? 0 : ticks_left - t; }
    uint64_t GetTicksRemaining() override { return ticks_left; }
};

Cpu::Cpu(GuestMemory& mem, Hle& hle) : p_(std::make_unique<Impl>(mem, hle)) {}
Cpu::~Cpu() = default;

CallResult Cpu::Call(uint32_t addr, const std::vector<uint32_t>& args, uint64_t max_ticks) {
    Impl& s = *p_;
    auto& R = s.jit->Regs();
    R.fill(0);
    const uint32_t extra = args.size() > 4 ? static_cast<uint32_t>(args.size() - 4) : 0;
    const uint32_t sp = (kStackTop - 0x100 - 4 * extra) & ~7u;
    for (size_t i = 0; i < args.size(); ++i) {
        if (i < 4) R[i] = args[i];
        else s.mem.write<uint32_t>(sp + 4 * static_cast<uint32_t>(i - 4), args[i]);
    }
    R[13] = sp;
    R[14] = kRetTramp | 1;
    R[15] = addr & ~1u;
    s.jit->SetCpsr((addr & 1) ? 0x30u : 0x10u);  // user mode, T bit for Thumb
    s.jit->ClearHalt();
    s.done = false;
    s.error.clear();
    s.ticks_left = max_ticks;
    s.hle.halt_requested = false;

    while (!s.done && s.error.empty()) {
        s.jit->Run();
        if (s.done || !s.error.empty()) break;
        if (s.ticks_left == 0) { s.error = "tick budget exhausted (possible infinite loop)"; break; }
        s.error = "unexpected halt";
    }
    CallResult res;
    res.ok = s.done && s.error.empty();
    res.error = s.error;
    res.r0 = s.jit->Regs()[0];
    res.r1 = s.jit->Regs()[1];
    return res;
}

}  // namespace t64
