#include "elf32.h"
#include <elf.h>
#include <fstream>
#include <iterator>
#include <stdexcept>

namespace t64 {

static std::vector<uint8_t> ReadFile(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("cannot open " + path);
    return std::vector<uint8_t>(std::istreambuf_iterator<char>(in), {});
}

LoadedLib LoadElf32(const std::string& path, GuestMemory& mem, ImportResolver& res) {
    const std::vector<uint8_t> f = ReadFile(path);
    return LoadElf32Bytes(f.data(), f.size(), mem, res);
}

LoadedLib LoadElf32Bytes(const uint8_t* fdata, size_t fsize, GuestMemory& mem, ImportResolver& res) {
    struct Span { const uint8_t* p; size_t n; const uint8_t* data() const { return p; } size_t size() const { return n; } };
    const Span f{fdata, fsize};
    if (f.size() < sizeof(Elf32_Ehdr)) throw std::runtime_error("file too small");
    const auto* eh = reinterpret_cast<const Elf32_Ehdr*>(f.data());
    if (std::memcmp(eh->e_ident, ELFMAG, SELFMAG) != 0 || eh->e_ident[EI_CLASS] != ELFCLASS32 ||
        eh->e_machine != EM_ARM || eh->e_type != ET_DYN)
        throw std::runtime_error("not a 32-bit ARM shared object");

    LoadedLib lib;
    lib.base = kLibBase;
    const uint32_t base = lib.base;
    uint32_t dyn_vaddr = 0;
    for (unsigned i = 0; i < eh->e_phnum; ++i) {
        const auto* ph = reinterpret_cast<const Elf32_Phdr*>(f.data() + eh->e_phoff + i * eh->e_phentsize);
        if (ph->p_type == PT_LOAD) {
            if (ph->p_offset + ph->p_filesz > f.size()) throw std::runtime_error("truncated segment");
            if (!mem.valid(base + ph->p_vaddr, ph->p_memsz)) throw std::runtime_error("segment outside arena");
            std::memcpy(mem.host(base + ph->p_vaddr), f.data() + ph->p_offset, ph->p_filesz);
            lib.image_size = std::max(lib.image_size, ph->p_vaddr + ph->p_memsz);
        } else if (ph->p_type == PT_DYNAMIC) {
            dyn_vaddr = ph->p_vaddr;
        }
    }
    if (!dyn_vaddr) throw std::runtime_error("no PT_DYNAMIC");

    uint32_t symtab = 0, strtab = 0, hash = 0, rel = 0, relsz = 0, jmprel = 0, pltrelsz = 0;
    uint32_t init_arr = 0, init_sz = 0, fini_arr = 0, fini_sz = 0;
    for (uint32_t a = base + dyn_vaddr;; a += sizeof(Elf32_Dyn)) {
        const auto d = mem.read<Elf32_Dyn>(a);
        if (d.d_tag == DT_NULL) break;
        const uint32_t v = d.d_un.d_val;
        switch (d.d_tag) {
            case DT_SYMTAB: symtab = v; break;
            case DT_STRTAB: strtab = v; break;
            case DT_HASH: hash = v; break;
            case DT_REL: rel = v; break;
            case DT_RELSZ: relsz = v; break;
            case DT_JMPREL: jmprel = v; break;
            case DT_PLTRELSZ: pltrelsz = v; break;
            case DT_INIT_ARRAY: init_arr = v; break;
            case DT_INIT_ARRAYSZ: init_sz = v; break;
            case DT_FINI_ARRAY: fini_arr = v; break;
            case DT_FINI_ARRAYSZ: fini_sz = v; break;
        }
    }
    if (!symtab || !strtab || !hash) throw std::runtime_error("missing DT_SYMTAB/DT_STRTAB/DT_HASH");
    const uint32_t nsyms = mem.read<uint32_t>(base + hash + 4);

    lib.syms.resize(nsyms);
    for (uint32_t i = 0; i < nsyms; ++i) {
        const auto s = mem.read<Elf32_Sym>(base + symtab + i * sizeof(Elf32_Sym));
        ElfSym& o = lib.syms[i];
        o.name = mem.cstr(base + strtab + s.st_name, 1024);
        o.value = s.st_value; o.size = s.st_size;
        o.type = ELF32_ST_TYPE(s.st_info); o.bind = ELF32_ST_BIND(s.st_info); o.shndx = s.st_shndx;
        if (o.shndx != SHN_UNDEF && !o.name.empty() && (o.bind == STB_GLOBAL || o.bind == STB_WEAK))
            lib.exports[o.name] = base + o.value;
    }

    std::vector<int64_t> cache(nsyms, -1);
    auto resolve = [&](uint32_t idx) -> uint32_t {
        if (idx >= nsyms) throw std::runtime_error("bad symbol index");
        if (cache[idx] >= 0) return static_cast<uint32_t>(cache[idx]);
        const ElfSym& s = lib.syms[idx];
        uint32_t addr;
        if (s.shndx != SHN_UNDEF) {
            addr = base + s.value;
        } else if (s.type == STT_OBJECT) {
            addr = res.Data(s.name, s.size);
            lib.imported_data.push_back(s.name);
        } else {
            addr = res.Function(s.name);
            lib.imported_functions.push_back(s.name);
        }
        cache[idx] = addr;
        return addr;
    };

    auto apply = [&](uint32_t table, uint32_t bytes) {
        for (uint32_t off = 0; off + sizeof(Elf32_Rel) <= bytes; off += sizeof(Elf32_Rel)) {
            const auto r = mem.read<Elf32_Rel>(base + table + off);
            const uint32_t P = base + r.r_offset;
            switch (ELF32_R_TYPE(r.r_info)) {
                case R_ARM_RELATIVE: mem.write<uint32_t>(P, mem.read<uint32_t>(P) + base); lib.n_relative++; break;
                case R_ARM_ABS32:
                    mem.write<uint32_t>(P, mem.read<uint32_t>(P) + resolve(ELF32_R_SYM(r.r_info))); lib.n_abs32++; break;
                case R_ARM_GLOB_DAT:
                    mem.write<uint32_t>(P, resolve(ELF32_R_SYM(r.r_info))); lib.n_glob_dat++; break;
                case R_ARM_JUMP_SLOT:
                    mem.write<uint32_t>(P, resolve(ELF32_R_SYM(r.r_info))); lib.n_jump_slot++; break;
                default: lib.n_other++; break;
            }
        }
    };
    if (rel) apply(rel, relsz);
    if (jmprel) apply(jmprel, pltrelsz);

    for (uint32_t i = 0; i < init_sz / 4; ++i) lib.init_array.push_back(mem.read<uint32_t>(base + init_arr + 4 * i));
    for (uint32_t i = 0; i < fini_sz / 4; ++i) lib.fini_array.push_back(mem.read<uint32_t>(base + fini_arr + 4 * i));
    return lib;
}

}  // namespace t64
