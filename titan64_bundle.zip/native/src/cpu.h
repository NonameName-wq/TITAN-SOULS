// Thin wrapper around Dynarmic's A32 JIT: runs 32-bit ARM/Thumb guest code on the 64-bit host.
#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "hle.h"

namespace t64 {

struct CallResult {
    bool ok = false;
    uint32_t r0 = 0, r1 = 0;
    std::string error;
};

class Cpu {
public:
    Cpu(GuestMemory& mem, Hle& hle);
    ~Cpu();
    // Calls a guest function (odd address = Thumb). Returns when it returns to the trampoline.
    CallResult Call(uint32_t addr, const std::vector<uint32_t>& args, uint64_t max_ticks = 4'000'000'000ull);

private:
    struct Impl;
    std::unique_ptr<Impl> p_;
};

}  // namespace t64
