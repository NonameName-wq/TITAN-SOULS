// Thin wrapper around Dynarmic's A32 JIT: runs 32-bit ARM/Thumb guest code on the 64-bit host.
// One Cpu = one guest thread of execution (own registers, own stack, own JIT code cache).
#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "hle.h"

namespace t64 {

struct CallResult {
    bool ok = false;
    uint32_t r0 = 0, r1 = 0;
    std::string error;
};

constexpr uint64_t kForever = 0x3FFFFFFFFFFFFFFFull;

class Cpu {
public:
    // stack_top: highest address of this CPU's stack (grows down). small_cache: use a smaller JIT code cache.
    Cpu(GuestMemory& mem, Hle& hle, uint32_t stack_top = kStackTop, bool small_cache = false);
    ~Cpu();
    // Calls a guest function (odd address = Thumb). Returns when it returns to the trampoline.
    CallResult Call(uint32_t addr, const std::vector<uint32_t>& args, uint64_t max_ticks = 4'000'000'000ull);

private:
    struct Impl;
    std::unique_ptr<Impl> p_;
};

// Installs Hle::call_guest (nested calls, e.g. qsort comparators) and Hle::run_thread (guest threads).
void InstallGuestRunner(Hle& hle);

}  // namespace t64
