// Android-only parts of the HLE layer: NativeActivity glue (window, assets, looper, input) and the GL/EGL bridge.
#pragma once
#include <android/asset_manager.h>
#include <android/input.h>
#include <android/native_window.h>
#include <functional>
#include "hle.h"

namespace t64 {

struct AndroidBridge {
    AAssetManager* assets = nullptr;
    // Wrap host objects into 32-bit guest handles.
    uint32_t WrapWindow(ANativeWindow* w);
    uint32_t WrapAssetManager(AAssetManager* m);
    uint32_t WrapInputQueue(AInputQueue* q);
    ANativeWindow* Window(uint32_t handle);
    void ForgetWindow(uint32_t handle);
    void ForgetInputQueue(uint32_t handle);
    // Called (on the guest's GL thread) when the game takes the window over with an EGL surface / gives it back.
    std::function<void(bool taken)> on_window_taken;
    // Releases this host thread's EGL context/surface (used when the game stops, so the banner can be drawn again).
    void ReleaseEglOnThisThread();
};
AndroidBridge& Bridge();

void RegisterAndroid(Hle& h);  // android_hle.cpp : AAsset*, AConfiguration*, ALooper*, AInputQueue*, ANativeWindow_*
void RegisterGles(Hle& h);     // gles_bridge.cpp : EGL + OpenGL ES 2 pass-through
void RegisterZlib(Hle& h);     // zlib_bridge.cpp : inflate/deflate/uncompress
void RegisterJni(Hle& h, uint32_t* vm_out, uint32_t* env_out);  // jni_bridge.cpp : guest JavaVM / JNIEnv tables forwarded to the real JVM
void JniSetHost(void* java_vm);        // the app's JavaVM* (ANativeActivity::vm)
uint32_t JniWrapGlobal(void* jobj);    // guest handle for a host jobject (a new global reference is taken)
void JniThreadExit();                  // detach the calling host thread from the VM

}  // namespace t64
