// Host-side implementations of the libc/libm/pthread imports needed so far.
// Anything not listed here is reported as UNIMPLEMENTED when the game calls it.
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include "hle.h"
#include "log.h"

namespace t64 {
namespace {

template <class T> std::string Fmt(const std::string& spec, T v) {
    int n = std::snprintf(nullptr, 0, spec.c_str(), v);
    std::string s(static_cast<size_t>(n) + 1, '\0');
    std::snprintf(s.data(), s.size(), spec.c_str(), v);
    s.resize(static_cast<size_t>(n));
    return s;
}

// printf-style formatter reading arguments from the guest (soft-float ABI).
std::string GuestFormat(CallCtx& c, uint32_t fmt_addr, int argi) {
    const std::string fmt = c.mem.cstr(fmt_addr);
    std::string out;
    for (size_t i = 0; i < fmt.size(); ++i) {
        if (fmt[i] != '%') { out += fmt[i]; continue; }
        size_t j = i + 1;
        std::string spec = "%";
        while (j < fmt.size() && std::strchr("-+ #0", fmt[j])) spec += fmt[j++];
        if (j < fmt.size() && fmt[j] == '*') { spec += std::to_string(int(c.arg(argi++))); ++j; }
        while (j < fmt.size() && std::isdigit(static_cast<unsigned char>(fmt[j]))) spec += fmt[j++];
        if (j < fmt.size() && fmt[j] == '.') {
            spec += fmt[j++];
            if (j < fmt.size() && fmt[j] == '*') { spec += std::to_string(int(c.arg(argi++))); ++j; }
            while (j < fmt.size() && std::isdigit(static_cast<unsigned char>(fmt[j]))) spec += fmt[j++];
        }
        int longs = 0;
        while (j < fmt.size() && std::strchr("hlzjt", fmt[j])) { if (fmt[j] == 'l') ++longs; ++j; }
        if (j >= fmt.size()) break;
        const char cv = fmt[j];
        switch (cv) {
            case '%': out += '%'; break;
            case 'd': case 'i':
                if (longs >= 2) { if (argi & 1) ++argi; out += Fmt(spec + "lld", static_cast<long long>(c.arg64(argi))); argi += 2; }
                else out += Fmt(spec + "d", static_cast<int>(c.arg(argi++)));
                break;
            case 'u': case 'x': case 'X': case 'o':
                if (longs >= 2) { if (argi & 1) ++argi; out += Fmt(spec + "ll" + cv, static_cast<unsigned long long>(c.arg64(argi))); argi += 2; }
                else out += Fmt(spec + cv, static_cast<unsigned>(c.arg(argi++)));
                break;
            case 'c': out += Fmt(spec + "c", static_cast<int>(c.arg(argi++))); break;
            case 's': out += Fmt(spec + "s", c.mem.cstr(c.arg(argi++)).c_str()); break;
            case 'p': out += Fmt(std::string("0x%x"), static_cast<unsigned>(c.arg(argi++))); break;
            case 'f': case 'F': case 'e': case 'E': case 'g': case 'G':
                if (argi & 1) ++argi;
                out += Fmt(spec + cv, c.argd(argi)); argi += 2;
                break;
            default: out += spec + cv; break;
        }
        i = j;
    }
    return out;
}

uint32_t PutString(Hle& h, const std::string& s) {
    uint32_t p = h.Alloc(static_cast<uint32_t>(s.size()) + 1);
    if (p) std::memcpy(h.mem.host(p), s.c_str(), s.size() + 1);
    return p;
}

}  // namespace

void RegisterBuiltins(Hle& h) {
    GuestMemory& m = h.mem;

    // ---- memory ----
    h.Register("malloc", [&h](CallCtx& c) { c.ret(h.Alloc(c.arg(0))); });
    h.Register("calloc", [&h](CallCtx& c) { c.ret(h.Alloc(c.arg(0) * c.arg(1))); });
    h.Register("free", [](CallCtx&) {});  // bump allocator: never reuses memory (milestone only)
    h.Register("realloc", [&h, &m](CallCtx& c) {
        uint32_t old = c.arg(0), n = c.arg(1), np = h.Alloc(n);
        if (old && np) std::memcpy(m.host(np), m.host(old), std::min(n, h.AllocSize(old)));
        c.ret(np);
    });
    auto memcpy_fn = [&m](CallCtx& c) { std::memmove(m.host(c.arg(0)), m.host(c.arg(1)), c.arg(2)); c.ret(c.arg(0)); };
    h.Register("memcpy", memcpy_fn);
    h.Register("memmove", memcpy_fn);
    h.Register("memset", [&m](CallCtx& c) { std::memset(m.host(c.arg(0)), int(c.arg(1)), c.arg(2)); c.ret(c.arg(0)); });
    h.Register("memcmp", [&m](CallCtx& c) { c.ret(uint32_t(std::memcmp(m.host(c.arg(0)), m.host(c.arg(1)), c.arg(2)))); });
    h.Register("memchr", [&m](CallCtx& c) {
        auto* p = static_cast<uint8_t*>(std::memchr(m.host(c.arg(0)), int(c.arg(1)), c.arg(2)));
        c.ret(p ? uint32_t(p - m.host(0)) : 0);
    });
    // ARM EABI helpers (note: __aeabi_memset has (dest, n, value) order)
    for (const char* n : {"__aeabi_memcpy", "__aeabi_memcpy4", "__aeabi_memcpy8", "__aeabi_memmove", "__aeabi_memmove4", "__aeabi_memmove8"})
        h.Register(n, memcpy_fn);
    for (const char* n : {"__aeabi_memset", "__aeabi_memset4", "__aeabi_memset8"})
        h.Register(n, [&m](CallCtx& c) { std::memset(m.host(c.arg(0)), int(c.arg(2)), c.arg(1)); });
    for (const char* n : {"__aeabi_memclr", "__aeabi_memclr4", "__aeabi_memclr8"})
        h.Register(n, [&m](CallCtx& c) { std::memset(m.host(c.arg(0)), 0, c.arg(1)); });

    // ---- strings ----
    h.Register("strlen", [&m](CallCtx& c) { c.ret(uint32_t(m.cstr(c.arg(0)).size())); });
    h.Register("strcmp", [&m](CallCtx& c) { c.ret(uint32_t(std::strcmp(m.cstr(c.arg(0)).c_str(), m.cstr(c.arg(1)).c_str()))); });
    h.Register("strcoll", [&m](CallCtx& c) { c.ret(uint32_t(std::strcmp(m.cstr(c.arg(0)).c_str(), m.cstr(c.arg(1)).c_str()))); });
    h.Register("strncmp", [&m](CallCtx& c) { c.ret(uint32_t(std::strncmp(m.cstr(c.arg(0)).c_str(), m.cstr(c.arg(1)).c_str(), c.arg(2)))); });
    h.Register("strcpy", [&m](CallCtx& c) { std::string s = m.cstr(c.arg(1)); std::memcpy(m.host(c.arg(0)), s.c_str(), s.size() + 1); c.ret(c.arg(0)); });
    h.Register("strncpy", [&m](CallCtx& c) { std::strncpy(reinterpret_cast<char*>(m.host(c.arg(0))), m.cstr(c.arg(1)).c_str(), c.arg(2)); c.ret(c.arg(0)); });
    h.Register("strcat", [&m](CallCtx& c) { std::string d = m.cstr(c.arg(0)), s = m.cstr(c.arg(1)); std::memcpy(m.host(c.arg(0)) + d.size(), s.c_str(), s.size() + 1); c.ret(c.arg(0)); });
    h.Register("strchr", [&m](CallCtx& c) { std::string s = m.cstr(c.arg(0)); size_t i = (char(c.arg(1)) == 0) ? s.size() : s.find(char(c.arg(1))); c.ret(i == std::string::npos ? 0 : c.arg(0) + uint32_t(i)); });
    h.Register("strrchr", [&m](CallCtx& c) { std::string s = m.cstr(c.arg(0)); size_t i = (char(c.arg(1)) == 0) ? s.size() : s.rfind(char(c.arg(1))); c.ret(i == std::string::npos ? 0 : c.arg(0) + uint32_t(i)); });
    h.Register("strstr", [&m](CallCtx& c) { std::string s = m.cstr(c.arg(0)), n = m.cstr(c.arg(1)); size_t i = s.find(n); c.ret(i == std::string::npos ? 0 : c.arg(0) + uint32_t(i)); });
    h.Register("strdup", [&h, &m](CallCtx& c) { c.ret(PutString(h, m.cstr(c.arg(0)))); });
    h.Register("strerror", [&h](CallCtx& c) { c.ret(PutString(h, "error " + std::to_string(int(c.arg(0))))); });
    h.Register("strtol", [&m](CallCtx& c) {
        std::string s = m.cstr(c.arg(0)); char* e; long v = std::strtol(s.c_str(), &e, int(c.arg(2)));
        if (c.arg(1)) m.write<uint32_t>(c.arg(1), c.arg(0) + uint32_t(e - s.c_str()));
        c.ret(uint32_t(v));
    });
    h.Register("strtoul", [&m](CallCtx& c) {
        std::string s = m.cstr(c.arg(0)); char* e; unsigned long v = std::strtoul(s.c_str(), &e, int(c.arg(2)));
        if (c.arg(1)) m.write<uint32_t>(c.arg(1), c.arg(0) + uint32_t(e - s.c_str()));
        c.ret(uint32_t(v));
    });

    // ---- printf family / logging ----
    h.Register("printf", [](CallCtx& c) { std::string s = GuestFormat(c, c.arg(0), 1); Logf("[printf] %s", s.c_str()); c.ret(uint32_t(s.size())); });
    h.Register("sprintf", [&m](CallCtx& c) { std::string s = GuestFormat(c, c.arg(1), 2); std::memcpy(m.host(c.arg(0)), s.c_str(), s.size() + 1); c.ret(uint32_t(s.size())); });
    h.Register("snprintf", [&m](CallCtx& c) {
        std::string s = GuestFormat(c, c.arg(2), 3); uint32_t cap = c.arg(1);
        if (cap) { size_t n = std::min<size_t>(s.size(), cap - 1); std::memcpy(m.host(c.arg(0)), s.c_str(), n); m.write<uint8_t>(c.arg(0) + uint32_t(n), 0); }
        c.ret(uint32_t(s.size()));
    });
    h.Register("__android_log_print", [&m](CallCtx& c) {
        std::string s = GuestFormat(c, c.arg(2), 3);
        Logf("[game:%s] %s", m.cstr(c.arg(1)).c_str(), s.c_str());
        c.ret(1);
    });

    // ---- time ----
    h.Register("time", [&m](CallCtx& c) { uint32_t t = uint32_t(std::time(nullptr)); if (c.arg(0)) m.write<uint32_t>(c.arg(0), t); c.ret(t); });
    h.Register("clock", [](CallCtx& c) { c.ret(uint32_t(std::clock())); });
    h.Register("gettimeofday", [&m](CallCtx& c) {
        auto us = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
        if (c.arg(0)) { m.write<int32_t>(c.arg(0), int32_t(us / 1000000)); m.write<int32_t>(c.arg(0) + 4, int32_t(us % 1000000)); }
        c.ret(0);
    });
    h.Register("clock_gettime", [&m](CallCtx& c) {
        auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
        m.write<int32_t>(c.arg(1), int32_t(ns / 1000000000)); m.write<int32_t>(c.arg(1) + 4, int32_t(ns % 1000000000));
        c.ret(0);
    });
    h.Register("srand48", [](CallCtx&) {});

    // ---- math (soft-float ABI) ----
    h.Register("sinf", [](CallCtx& c) { c.retf(std::sin(c.argf(0))); });
    h.Register("cosf", [](CallCtx& c) { c.retf(std::cos(c.argf(0))); });
    h.Register("tanf", [](CallCtx& c) { c.retf(std::tan(c.argf(0))); });
    h.Register("atanf", [](CallCtx& c) { c.retf(std::atan(c.argf(0))); });
    h.Register("atan2f", [](CallCtx& c) { c.retf(std::atan2(c.argf(0), c.argf(1))); });
    h.Register("expf", [](CallCtx& c) { c.retf(std::exp(c.argf(0))); });
    h.Register("powf", [](CallCtx& c) { c.retf(std::pow(c.argf(0), c.argf(1))); });
    h.Register("sqrtf", [](CallCtx& c) { c.retf(std::sqrt(c.argf(0))); });
    h.Register("floorf", [](CallCtx& c) { c.retf(std::floor(c.argf(0))); });
    h.Register("ceilf", [](CallCtx& c) { c.retf(std::ceil(c.argf(0))); });
    h.Register("sin", [](CallCtx& c) { c.retd(std::sin(c.argd(0))); });
    h.Register("floor", [](CallCtx& c) { c.retd(std::floor(c.argd(0))); });
    h.Register("ceil", [](CallCtx& c) { c.retd(std::ceil(c.argd(0))); });
    h.Register("pow", [](CallCtx& c) { c.retd(std::pow(c.argd(0), c.argd(2))); });
    h.Register("fmod", [](CallCtx& c) { c.retd(std::fmod(c.argd(0), c.argd(2))); });

    // ---- ARM EABI integer/long helpers ----
    h.Register("__aeabi_idiv", [](CallCtx& c) { int32_t b = int32_t(c.arg(1)); c.ret(b ? uint32_t(int32_t(c.arg(0)) / b) : 0); });
    h.Register("__aeabi_uidiv", [](CallCtx& c) { c.ret(c.arg(1) ? c.arg(0) / c.arg(1) : 0); });
    h.Register("__aeabi_idivmod", [](CallCtx& c) { int32_t a = int32_t(c.arg(0)), b = int32_t(c.arg(1)); c.r[0] = b ? uint32_t(a / b) : 0; c.r[1] = b ? uint32_t(a % b) : 0; });
    h.Register("__aeabi_uidivmod", [](CallCtx& c) { uint32_t a = c.arg(0), b = c.arg(1); c.r[0] = b ? a / b : 0; c.r[1] = b ? a % b : 0; });
    h.Register("__aeabi_uldivmod", [](CallCtx& c) {
        uint64_t a = c.arg64(0), b = c.arg64(2);
        uint64_t q = b ? a / b : 0, r = b ? a % b : 0;
        c.r[0] = uint32_t(q); c.r[1] = uint32_t(q >> 32); c.r[2] = uint32_t(r); c.r[3] = uint32_t(r >> 32);
    });
    h.Register("__aeabi_d2lz", [](CallCtx& c) { c.ret64(uint64_t(int64_t(c.argd(0)))); });
    h.Register("__aeabi_d2ulz", [](CallCtx& c) { c.ret64(uint64_t(c.argd(0))); });
    h.Register("__aeabi_ul2d", [](CallCtx& c) { c.retd(double(c.arg64(0))); });

    // ---- C++ runtime / pthread (single-threaded stubs) ----
    h.Register("__cxa_atexit", [](CallCtx& c) { c.ret(0); });
    h.Register("__cxa_finalize", [](CallCtx&) {});
    h.Register("dlsym", [](CallCtx& c) { c.ret(0); });
    for (const char* n : {"pthread_mutex_init", "pthread_mutex_lock", "pthread_mutex_unlock", "pthread_mutex_destroy",
                          "pthread_mutexattr_init", "pthread_mutexattr_destroy", "pthread_mutexattr_settype",
                          "pthread_cond_init", "pthread_cond_signal", "pthread_cond_broadcast", "pthread_cond_destroy",
                          "pthread_attr_init", "pthread_attr_destroy", "pthread_attr_setdetachstate", "pthread_attr_setstacksize",
                          "pthread_setname_np", "pthread_detach"})
        h.Register(n, [](CallCtx& c) { c.ret(0); });
    // pthread_once must call the guest init routine, so it is written as guest ARM code.
    h.RegisterGuest("pthread_once", {0xE5902000,   // ldr r2,[r0]
                                     0xE3520000,   // cmp r2,#0
                                     0x112FFF1E,   // bxne lr
                                     0xE3A02001,   // mov r2,#1
                                     0xE5802000,   // str r2,[r0]
                                     0xE52DE004,   // push {lr}
                                     0xE12FFF31,   // blx r1
                                     0xE3A00000,   // mov r0,#0
                                     0xE49DF004}); // pop {pc}
    // ---- minimal wide-char / ctype helpers (ASCII range) ----
    h.Register("btowc", [](CallCtx& c) { uint32_t v = c.arg(0); c.ret(v < 128 ? v : 0xFFFFFFFFu); });
    h.Register("wctob", [](CallCtx& c) { uint32_t v = c.arg(0); c.ret(v < 128 ? v : 0xFFFFFFFFu); });
    h.Register("wctype", [&m](CallCtx& c) {
        static const char* names[] = {"alnum","alpha","blank","cntrl","digit","graph","lower","print","punct","space","upper","xdigit"};
        std::string s = m.cstr(c.arg(0)); uint32_t r = 0;
        for (uint32_t i = 0; i < 12; ++i) if (s == names[i]) r = i + 1;
        c.ret(r);
    });
    h.Register("iswctype", [](CallCtx& c) {
        uint32_t w = c.arg(0), t = c.arg(1); int ch = w < 256 ? int(w) : 0; bool r = false;
        switch (t) { case 1: r = std::isalnum(ch); break; case 2: r = std::isalpha(ch); break; case 3: r = ch == ' ' || ch == '\t'; break;
            case 4: r = std::iscntrl(ch); break; case 5: r = std::isdigit(ch); break; case 6: r = std::isgraph(ch); break;
            case 7: r = std::islower(ch); break; case 8: r = std::isprint(ch); break; case 9: r = std::ispunct(ch); break;
            case 10: r = std::isspace(ch); break; case 11: r = std::isupper(ch); break; case 12: r = std::isxdigit(ch); break; }
        c.ret(r ? 1 : 0);
    });
    h.Register("pthread_self", [](CallCtx& c) { c.ret(1); });
    h.Register("pthread_equal", [](CallCtx& c) { c.ret(c.arg(0) == c.arg(1)); });
    h.Register("pthread_key_create", [&m](CallCtx& c) { static uint32_t next = 1; m.write<uint32_t>(c.arg(0), next++); c.ret(0); });
    h.Register("pthread_key_delete", [](CallCtx& c) { c.ret(0); });
    static std::unordered_map<uint32_t, uint32_t> tls;
    h.Register("pthread_setspecific", [](CallCtx& c) { tls[c.arg(0)] = c.arg(1); c.ret(0); });
    h.Register("pthread_getspecific", [](CallCtx& c) { auto it = tls.find(c.arg(0)); c.ret(it == tls.end() ? 0 : it->second); });
}

}  // namespace t64
