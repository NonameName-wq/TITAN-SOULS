// Helpers shared by the libc emulation files.
#pragma once
#include <string>
#include "hle.h"

namespace t64 {

// Source of printf-style variadic arguments (ARM soft-float ABI: 64-bit values are 8-byte aligned).
struct ArgSrc {
    virtual ~ArgSrc() = default;
    virtual uint32_t u32() = 0;
    virtual uint64_t u64() = 0;
};
// Arguments that are still in registers / on the stack of the HLE call.
struct RegArgs : ArgSrc {
    CallCtx& c;
    int i;
    RegArgs(CallCtx& cc, int first) : c(cc), i(first) {}
    uint32_t u32() override { return c.arg(i++); }
    uint64_t u64() override { if (i & 1) ++i; uint64_t v = c.arg64(i); i += 2; return v; }
};
// A guest va_list (ARM EABI: the register holds the pointer to the next argument slot).
struct VaArgs : ArgSrc {
    GuestMemory& m;
    uint32_t p;
    VaArgs(GuestMemory& mm, uint32_t ap) : m(mm), p(ap) {}
    uint32_t u32() override { uint32_t v = m.read<uint32_t>(p); p += 4; return v; }
    uint64_t u64() override { p = (p + 7) & ~7u; uint64_t v = m.read<uint64_t>(p); p += 8; return v; }
};

std::string GuestFormat(GuestMemory& mem, uint32_t fmt_addr, ArgSrc& args);                       // builtins.cpp
std::string FormatRegs(CallCtx& c, int fmt_index);                                                 // format string at arg(fmt_index), varargs follow
uint32_t PutGuestString(Hle& h, const std::string& s);                                              // allocates a guest copy
inline void WriteGuestString(GuestMemory& m, uint32_t addr, const std::string& s) {
    if (uint8_t* p = m.hostp(addr, s.size() + 1)) std::memcpy(p, s.c_str(), s.size() + 1);
}
// Logs full lines written by the game to stdout/stderr.
void GameConsole(int fd, const std::string& text);                                                  // libc_io.cpp

}  // namespace t64
