// The app's own EGL display / config / window surface. It draws the status banner with OpenGL ES (a window that has
// been drawn on through ANativeWindow_lock can no longer be used with EGL), and then hands the very same surface to
// the game: the guest's eglCreateWindowSurface() returns this surface.
#pragma once
#include <EGL/egl.h>
#include <android/native_window.h>
#include <cstdint>
#include <mutex>

namespace t64 {

class HostGl {
public:
    bool Init(ANativeWindow* win);                      // display/config/context once, surface for this window (never left current)
    void DestroySurface();                              // releases the current context on this thread and destroys the surface
    bool MakeCurrentHere();                             // banner context + surface current on the calling thread
    void ReleaseCurrent();                              // un-bind from the calling thread (so the game's thread can bind)
    bool Present(const uint32_t* rgba, int w, int h);   // banner bitmap -> full screen, then swap
    EGLDisplay display() const { return dpy_; }
    EGLConfig config() const { return cfg_; }
    EGLSurface surface() const { return surf_; }
    ANativeWindow* window() const { return win_; }
    bool has_surface() const { return surf_ != EGL_NO_SURFACE; }
    // Every operation takes this lock; the game's eglCreateWindowSurface/eglMakeCurrent take it too, so the banner painter
    // can never hold the surface while the game binds it.
    std::recursive_mutex& mutex() { return mu_; }
    int Width() const;
    int Height() const;

private:
    bool InitDisplay();
    bool BuildBannerProgram();
    std::recursive_mutex mu_;
    EGLDisplay dpy_ = EGL_NO_DISPLAY;
    EGLConfig cfg_ = nullptr;
    EGLContext ctx_ = EGL_NO_CONTEXT;
    EGLSurface surf_ = EGL_NO_SURFACE;
    ANativeWindow* win_ = nullptr;
    uint32_t prog_ = 0, tex_ = 0;
    int loc_tex_ = -1;
};

HostGl& Gl();

}  // namespace t64
