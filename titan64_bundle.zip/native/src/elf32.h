// Minimal loader for 32-bit ARM Android shared objects (ET_DYN, DT_HASH, REL relocations).
#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>
#include "guest_memory.h"

namespace t64 {

struct ImportResolver {
    virtual ~ImportResolver() = default;
    virtual uint32_t Function(const std::string& name) = 0;               // returns guest stub address
    virtual uint32_t Data(const std::string& name, uint32_t size) = 0;    // returns guest data address
};

struct ElfSym {
    std::string name;
    uint32_t value = 0, size = 0;
    uint8_t type = 0, bind = 0;
    uint16_t shndx = 0;
};

struct LoadedLib {
    uint32_t base = 0, image_size = 0;
    std::vector<ElfSym> syms;
    std::unordered_map<std::string, uint32_t> exports;  // name -> guest address (Thumb bit kept)
    std::vector<uint32_t> init_array, fini_array;       // guest function addresses
    std::vector<std::string> imported_functions, imported_data;
    uint32_t n_relative = 0, n_jump_slot = 0, n_glob_dat = 0, n_abs32 = 0, n_other = 0;
};

LoadedLib LoadElf32(const std::string& path, GuestMemory& mem, ImportResolver& res);
LoadedLib LoadElf32Bytes(const uint8_t* data, size_t size, GuestMemory& mem, ImportResolver& res);

}  // namespace t64
