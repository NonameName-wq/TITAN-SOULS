// stdio, POSIX file/directory/pipe calls and calendar time for the 32-bit guest.
// The guest sees opaque 32-bit handles for FILE*/DIR*; struct layouts follow the old 32-bit ARM bionic ABI.
#include <dirent.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <mutex>
#include <string>
#include <vector>

#include "handles.h"
#include "hle.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {

void GameConsole(int fd, const std::string& text) {
    static std::mutex mu;
    static std::string buf[3];
    std::lock_guard<std::mutex> lk(mu);
    std::string& b = buf[fd == 2 ? 2 : 1];
    b += text;
    size_t nl;
    while ((nl = b.find('\n')) != std::string::npos) {
        Logf("[%s] %s", fd == 2 ? "stderr" : "stdout", b.substr(0, nl).c_str());
        b.erase(0, nl + 1);
    }
    if (b.size() > 2048) {
        Logf("[%s] %s", fd == 2 ? "stderr" : "stdout", b.c_str());
        b.clear();
    }
}

namespace {

struct HFile { FILE* f = nullptr; int kind = 0; };  // kind: 0 real file, 1 stdout, 2 stderr, 3 stdin
HFile g_stdin{nullptr, 3}, g_stdout{nullptr, 1}, g_stderr{nullptr, 2};
HandleMap<HFile*> g_files(0x7D000000u);
HandleMap<DIR*> g_dirs(0x7D100000u);
uint32_t g_sf = 0;  // guest address of __sF (stdin, stdout, stderr; 84 bytes each)

HFile* GetFile(uint32_t h) {
    if (g_sf) {
        if (h == g_sf) return &g_stdin;
        if (h == g_sf + 84) return &g_stdout;
        if (h == g_sf + 168) return &g_stderr;
    }
    return g_files.GetOr(h, nullptr);
}

constexpr uint32_t kEOF = 0xFFFFFFFFu;

// Old bionic ARM `struct stat` (104 bytes, identical to the kernel's stat64).
void FillStat(GuestMemory& m, uint32_t p, const struct stat& st) {
    uint8_t* d = m.hostp(p, 104);
    if (!d) return;
    std::memset(d, 0, 104);
    auto w32 = [&](uint32_t off, uint32_t v) { std::memcpy(d + off, &v, 4); };
    auto w64 = [&](uint32_t off, uint64_t v) { std::memcpy(d + off, &v, 8); };
    w64(0, st.st_dev);
    w32(12, uint32_t(st.st_ino));
    w32(16, st.st_mode);
    w32(20, uint32_t(st.st_nlink));
    w32(24, st.st_uid);
    w32(28, st.st_gid);
    w64(32, st.st_rdev);
    w64(48, uint64_t(st.st_size));
    w32(56, uint32_t(st.st_blksize));
    w64(64, uint64_t(st.st_blocks));
    w32(72, uint32_t(st.st_atim.tv_sec));
    w32(76, uint32_t(st.st_atim.tv_nsec));
    w32(80, uint32_t(st.st_mtim.tv_sec));
    w32(84, uint32_t(st.st_mtim.tv_nsec));
    w32(88, uint32_t(st.st_ctim.tv_sec));
    w32(92, uint32_t(st.st_ctim.tv_nsec));
    w64(96, uint64_t(st.st_ino));
}

int HostOpenFlags(uint32_t g) {
    int f = int(g & 3u);  // O_RDONLY / O_WRONLY / O_RDWR
    if (g & 0x40) f |= O_CREAT;
    if (g & 0x80) f |= O_EXCL;
    if (g & 0x200) f |= O_TRUNC;
    if (g & 0x400) f |= O_APPEND;
    if (g & 0x800) f |= O_NONBLOCK;
    if (g & 0x40000) f |= O_DIRECTORY;  // ARM32 value
    if (g & 0x80000) f |= O_CLOEXEC;
    return f;
}

// struct tm of the ARM bionic ABI: 9 ints, tm_gmtoff (long), tm_zone (char*) = 44 bytes.
void TmToGuest(GuestMemory& m, uint32_t p, const struct tm& t) {
    const int32_t v[9] = {t.tm_sec, t.tm_min, t.tm_hour, t.tm_mday, t.tm_mon, t.tm_year, t.tm_wday, t.tm_yday, t.tm_isdst};
    for (int i = 0; i < 9; ++i) m.write<int32_t>(p + 4u * i, v[i]);
    m.write<int32_t>(p + 36, int32_t(t.tm_gmtoff));
    m.write<uint32_t>(p + 40, 0);
}
struct tm TmFromGuest(GuestMemory& m, uint32_t p) {
    struct tm t;
    std::memset(&t, 0, sizeof t);
    t.tm_sec = m.read<int32_t>(p);
    t.tm_min = m.read<int32_t>(p + 4);
    t.tm_hour = m.read<int32_t>(p + 8);
    t.tm_mday = m.read<int32_t>(p + 12);
    t.tm_mon = m.read<int32_t>(p + 16);
    t.tm_year = m.read<int32_t>(p + 20);
    t.tm_wday = m.read<int32_t>(p + 24);
    t.tm_yday = m.read<int32_t>(p + 28);
    t.tm_isdst = m.read<int32_t>(p + 32);
    t.tm_gmtoff = m.read<int32_t>(p + 36);
    return t;
}

}  // namespace

void RegisterIo(Hle& h) {
    GuestMemory& m = h.mem;
    g_sf = h.Data("__sF", 3 * 84);

    // ---------------------------------------------------------------- stdio
    h.Register("fopen", [&h, &m](CallCtx& c) {
        FILE* f = std::fopen(m.cstr(c.arg(0)).c_str(), m.cstr(c.arg(1)).c_str());
        if (!f) { h.SetErrno(errno); c.ret(0); return; }
        c.ret(g_files.Put(new HFile{f, 0}));
    });
    h.Register("fdopen", [&h, &m](CallCtx& c) {
        FILE* f = ::fdopen(int(c.arg(0)), m.cstr(c.arg(1)).c_str());
        if (!f) { h.SetErrno(errno); c.ret(0); return; }
        c.ret(g_files.Put(new HFile{f, 0}));
    });
    h.Register("fclose", [](CallCtx& c) {
        HFile* f = GetFile(c.arg(0));
        if (!f || f->kind) { c.ret(0); return; }
        int r = std::fclose(f->f);
        g_files.Erase(c.arg(0));
        delete f;
        c.ret(uint32_t(r));
    });
    h.Register("fflush", [](CallCtx& c) {
        HFile* f = c.arg(0) ? GetFile(c.arg(0)) : nullptr;
        c.ret(f && f->f ? uint32_t(std::fflush(f->f)) : 0u);
    });
    h.Register("fread", [&m](CallCtx& c) {
        HFile* f = GetFile(c.arg(3));
        const uint64_t total = uint64_t(c.arg(1)) * c.arg(2);
        uint8_t* d = m.hostp(c.arg(0), size_t(total));
        if (!f || !f->f || !d || !c.arg(1)) { c.ret(0); return; }
        c.ret(uint32_t(std::fread(d, c.arg(1), c.arg(2), f->f)));
    });
    h.Register("fwrite", [&m](CallCtx& c) {
        HFile* f = GetFile(c.arg(3));
        const uint64_t total = uint64_t(c.arg(1)) * c.arg(2);
        uint8_t* d = m.hostp(c.arg(0), size_t(total));
        if (!f || !d || !c.arg(1)) { c.ret(0); return; }
        if (f->kind == 1 || f->kind == 2) {
            GameConsole(f->kind, std::string(reinterpret_cast<char*>(d), size_t(total)));
            c.ret(c.arg(2));
            return;
        }
        c.ret(f->f ? uint32_t(std::fwrite(d, c.arg(1), c.arg(2), f->f)) : 0u);
    });
    h.Register("fseek", [](CallCtx& c) {
        HFile* f = GetFile(c.arg(0));
        c.ret(f && f->f ? uint32_t(std::fseek(f->f, long(int32_t(c.arg(1))), int(c.arg(2)))) : 0xFFFFFFFFu);
    });
    h.Register("ftell", [](CallCtx& c) {
        HFile* f = GetFile(c.arg(0));
        c.ret(f && f->f ? uint32_t(std::ftell(f->f)) : 0xFFFFFFFFu);
    });
    h.Register("getc", [](CallCtx& c) {
        HFile* f = GetFile(c.arg(0));
        c.ret(f && f->f && f->kind == 0 ? uint32_t(std::fgetc(f->f)) : kEOF);
    });
    h.Register("ungetc", [](CallCtx& c) {
        HFile* f = GetFile(c.arg(1));
        c.ret(f && f->f && f->kind == 0 ? uint32_t(std::ungetc(int(c.arg(0)), f->f)) : kEOF);
    });
    auto putc_fn = [](CallCtx& c) {
        HFile* f = GetFile(c.arg(1));
        const int ch = int(c.arg(0)) & 0xFF;
        if (!f) { c.ret(kEOF); return; }
        if (f->kind == 1 || f->kind == 2) { GameConsole(f->kind, std::string(1, char(ch))); c.ret(uint32_t(ch)); return; }
        c.ret(f->f ? uint32_t(std::fputc(ch, f->f)) : kEOF);
    };
    h.Register("fputc", putc_fn);
    h.Register("putc", putc_fn);
    h.Register("fputs", [&m](CallCtx& c) {
        HFile* f = GetFile(c.arg(1));
        const std::string s = m.cstr(c.arg(0));
        if (!f) { c.ret(kEOF); return; }
        if (f->kind == 1 || f->kind == 2) { GameConsole(f->kind, s); c.ret(1); return; }
        c.ret(f->f ? uint32_t(std::fputs(s.c_str(), f->f)) : kEOF);
    });
    h.Register("putchar", [](CallCtx& c) { GameConsole(1, std::string(1, char(c.arg(0)))); c.ret(c.arg(0) & 0xFF); });
    h.Register("puts", [&m](CallCtx& c) { GameConsole(1, m.cstr(c.arg(0)) + "\n"); c.ret(1); });
    h.Register("setvbuf", [](CallCtx& c) { c.ret(0); });
    h.Register("fprintf", [](CallCtx& c) {
        HFile* f = GetFile(c.arg(0));
        const std::string s = FormatRegs(c, 1);
        if (f && (f->kind == 1 || f->kind == 2)) GameConsole(f->kind, s);
        else if (f && f->f) std::fputs(s.c_str(), f->f);
        c.ret(uint32_t(s.size()));
    });
    h.Register("vprintf", [&m](CallCtx& c) {
        VaArgs a(m, c.arg(1));
        const std::string s = GuestFormat(m, c.arg(0), a);
        GameConsole(1, s);
        c.ret(uint32_t(s.size()));
    });
    h.Register("vsprintf", [&m](CallCtx& c) {
        VaArgs a(m, c.arg(2));
        const std::string s = GuestFormat(m, c.arg(1), a);
        WriteGuestString(m, c.arg(0), s);
        c.ret(uint32_t(s.size()));
    });
    h.Register("vasprintf", [&h, &m](CallCtx& c) {
        VaArgs a(m, c.arg(2));
        const std::string s = GuestFormat(m, c.arg(1), a);
        const uint32_t p = PutGuestString(h, s);
        m.write<uint32_t>(c.arg(0), p);
        c.ret(p ? uint32_t(s.size()) : 0xFFFFFFFFu);
    });
    // wide-character stream functions (not really used; keep the game going)
    h.Register("getwc", [](CallCtx& c) { c.ret(kEOF); });
    h.Register("ungetwc", [](CallCtx& c) { c.ret(kEOF); });
    h.Register("putwc", [](CallCtx& c) {
        HFile* f = GetFile(c.arg(1));
        const uint32_t wc = c.arg(0);
        if (f && (f->kind == 1 || f->kind == 2)) GameConsole(f->kind, std::string(1, wc < 128 ? char(wc) : '?'));
        c.ret(wc);
    });

    // ---------------------------------------------------------------- POSIX file descriptors
    h.Register("open", [&h, &m](CallCtx& c) {
        const int fd = ::open(m.cstr(c.arg(0)).c_str(), HostOpenFlags(c.arg(1)), c.arg(2));
        if (fd < 0) h.SetErrno(errno);
        c.ret(uint32_t(fd));
    });
    h.Register("close", [&h](CallCtx& c) {
        const int r = ::close(int(c.arg(0)));
        if (r < 0) h.SetErrno(errno);
        c.ret(uint32_t(r));
    });
    h.Register("read", [&h, &m](CallCtx& c) {
        uint8_t* d = m.hostp(c.arg(1), c.arg(2));
        if (!d && c.arg(2)) { h.SetErrno(14); c.ret(0xFFFFFFFFu); return; }
        const ssize_t r = ::read(int(c.arg(0)), d, c.arg(2));
        if (r < 0) h.SetErrno(errno);
        c.ret(uint32_t(int32_t(r)));
    });
    h.Register("write", [&h, &m](CallCtx& c) {
        uint8_t* d = m.hostp(c.arg(1), c.arg(2));
        if (!d && c.arg(2)) { h.SetErrno(14); c.ret(0xFFFFFFFFu); return; }
        const int fd = int(c.arg(0));
        if (fd == 1 || fd == 2) { GameConsole(fd, std::string(reinterpret_cast<char*>(d), c.arg(2))); c.ret(c.arg(2)); return; }
        const ssize_t r = ::write(fd, d, c.arg(2));
        if (r < 0) h.SetErrno(errno);
        c.ret(uint32_t(int32_t(r)));
    });
    h.Register("writev", [&h, &m](CallCtx& c) {  // guest iovec = {void* base; size_t len}
        const int fd = int(c.arg(0));
        int32_t total = 0;
        for (uint32_t i = 0; i < c.arg(2); ++i) {
            const uint32_t base = m.read<uint32_t>(c.arg(1) + 8 * i), len = m.read<uint32_t>(c.arg(1) + 8 * i + 4);
            uint8_t* d = m.hostp(base, len);
            if (!d) continue;
            if (fd == 1 || fd == 2) GameConsole(fd, std::string(reinterpret_cast<char*>(d), len));
            else if (::write(fd, d, len) < 0) { h.SetErrno(errno); c.ret(0xFFFFFFFFu); return; }
            total += int32_t(len);
        }
        c.ret(uint32_t(total));
    });
    h.Register("lseek", [&h](CallCtx& c) {
        const off_t r = ::lseek(int(c.arg(0)), off_t(int32_t(c.arg(1))), int(c.arg(2)));
        if (r < 0) h.SetErrno(errno);
        c.ret(uint32_t(int32_t(r)));
    });
    h.Register("pipe", [&h, &m](CallCtx& c) {
        int fds[2];
        if (::pipe(fds) < 0) { h.SetErrno(errno); c.ret(0xFFFFFFFFu); return; }
        m.write<int32_t>(c.arg(0), fds[0]);
        m.write<int32_t>(c.arg(0) + 4, fds[1]);
        c.ret(0);
    });
    h.Register("poll", [&h, &m](CallCtx& c) {  // guest pollfd {int fd; short events; short revents} == host layout
        const uint32_t n = c.arg(1);
        std::vector<struct pollfd> v(n);
        for (uint32_t i = 0; i < n; ++i) {
            v[i].fd = m.read<int32_t>(c.arg(0) + 8 * i);
            v[i].events = m.read<int16_t>(c.arg(0) + 8 * i + 4);
            v[i].revents = 0;
        }
        const int r = ::poll(v.data(), n, int(int32_t(c.arg(2))));
        if (r < 0) h.SetErrno(errno);
        for (uint32_t i = 0; i < n; ++i) m.write<int16_t>(c.arg(0) + 8 * i + 6, v[i].revents);
        c.ret(uint32_t(r));
    });
    h.Register("ioctl", [&h](CallCtx& c) { h.SetErrno(25); c.ret(0xFFFFFFFFu); });  // ENOTTY
    h.Register("system", [](CallCtx& c) { c.ret(0xFFFFFFFFu); });

    // ---------------------------------------------------------------- files and directories
    h.Register("stat", [&h, &m](CallCtx& c) {
        struct stat st;
        if (::stat(m.cstr(c.arg(0)).c_str(), &st) < 0) { h.SetErrno(errno); c.ret(0xFFFFFFFFu); return; }
        FillStat(m, c.arg(1), st);
        c.ret(0);
    });
    h.Register("fstat", [&h, &m](CallCtx& c) {
        struct stat st;
        if (::fstat(int(c.arg(0)), &st) < 0) { h.SetErrno(errno); c.ret(0xFFFFFFFFu); return; }
        FillStat(m, c.arg(1), st);
        c.ret(0);
    });
    h.Register("mkdir", [&h, &m](CallCtx& c) {
        const int r = ::mkdir(m.cstr(c.arg(0)).c_str(), mode_t(c.arg(1)));
        if (r < 0) h.SetErrno(errno);
        c.ret(uint32_t(r));
    });
    h.Register("rmdir", [&h, &m](CallCtx& c) {
        const int r = ::rmdir(m.cstr(c.arg(0)).c_str());
        if (r < 0) h.SetErrno(errno);
        c.ret(uint32_t(r));
    });
    h.Register("unlink", [&h, &m](CallCtx& c) {
        const int r = ::unlink(m.cstr(c.arg(0)).c_str());
        if (r < 0) h.SetErrno(errno);
        c.ret(uint32_t(r));
    });
    h.Register("remove", [&h, &m](CallCtx& c) {
        const int r = std::remove(m.cstr(c.arg(0)).c_str());
        if (r < 0) h.SetErrno(errno);
        c.ret(uint32_t(r));
    });
    // DIR*: guest handle -> host DIR*; every handle owns one guest `struct dirent` (280 bytes) that readdir() fills.
    static std::mutex dir_mu;
    static std::unordered_map<uint32_t, uint32_t> dirent_buf;
    h.Register("opendir", [&h, &m](CallCtx& c) {
        DIR* d = ::opendir(m.cstr(c.arg(0)).c_str());
        if (!d) { h.SetErrno(errno); c.ret(0); return; }
        const uint32_t hd = g_dirs.Put(d);
        std::lock_guard<std::mutex> lk(dir_mu);
        dirent_buf[hd] = h.Alloc(288);
        c.ret(hd);
    });
    h.Register("readdir", [&m](CallCtx& c) {
        DIR* d = g_dirs.GetOr(c.arg(0), nullptr);
        if (!d) { c.ret(0); return; }
        struct dirent* e = ::readdir(d);
        if (!e) { c.ret(0); return; }
        uint32_t buf;
        {
            std::lock_guard<std::mutex> lk(dir_mu);
            buf = dirent_buf[c.arg(0)];
        }
        if (!buf) { c.ret(0); return; }
        std::memset(m.host(buf), 0, 288);
        m.write<uint64_t>(buf, uint64_t(e->d_ino));
        m.write<uint16_t>(buf + 16, 280);
        m.write<uint8_t>(buf + 18, e->d_type);
        std::strncpy(reinterpret_cast<char*>(m.host(buf + 19)), e->d_name, 255);
        c.ret(buf);
    });
    h.Register("closedir", [&h](CallCtx& c) {
        DIR* d = g_dirs.GetOr(c.arg(0), nullptr);
        if (d) ::closedir(d);
        g_dirs.Erase(c.arg(0));
        uint32_t buf = 0;
        {
            std::lock_guard<std::mutex> lk(dir_mu);
            auto it = dirent_buf.find(c.arg(0));
            if (it != dirent_buf.end()) { buf = it->second; dirent_buf.erase(it); }
        }
        h.Free(buf);
        c.ret(0);
    });

    // ---------------------------------------------------------------- calendar time (32-bit time_t)
    static uint32_t tm_static = 0;
    auto localtime_fn = [&h, &m](CallCtx& c, bool reentrant) {
        const time_t t = time_t(int32_t(m.read<uint32_t>(c.arg(0))));
        struct tm out;
        ::localtime_r(&t, &out);
        uint32_t dst = reentrant ? c.arg(1) : (tm_static ? tm_static : (tm_static = h.Alloc(64)));
        TmToGuest(m, dst, out);
        c.ret(dst);
    };
    h.Register("localtime", [localtime_fn](CallCtx& c) { localtime_fn(c, false); });
    h.Register("localtime_r", [localtime_fn](CallCtx& c) { localtime_fn(c, true); });
    h.Register("strftime", [&m](CallCtx& c) {
        struct tm t = TmFromGuest(m, c.arg(3));
        std::vector<char> buf(c.arg(1) + 1);
        const size_t n = c.arg(1) ? ::strftime(buf.data(), c.arg(1), m.cstr(c.arg(2)).c_str(), &t) : 0;
        if (n && m.hostp(c.arg(0), n + 1)) std::memcpy(m.host(c.arg(0)), buf.data(), n + 1);
        c.ret(uint32_t(n));
    });
    h.Register("wcsftime", [](CallCtx& c) { c.ret(0); });
}

}  // namespace t64
