// EGL + OpenGL ES 2 pass-through from the 32-bit guest to the phone's real (64-bit) driver.
// Guest pointers are plain offsets into the arena, so client-side vertex/index/pixel data can be handed to the driver
// directly. EGL objects are mapped to small guest handles; the window surface is the app's own surface (host_gl.cpp).
#include <EGL/egl.h>
#include <GLES2/gl2.h>

#include <atomic>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "android_hle.h"
#include "handles.h"
#include "host_gl.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {
namespace {

constexpr uint32_t kDisplayH = 0x7A00D001u, kConfigH = 0x7A00C001u, kSurfaceH = 0x7A00F001u;
HandleMap<EGLContext> g_contexts(0x7A010000u);

std::atomic<uint32_t> g_array_buffer{0}, g_element_buffer{0};  // client-array vs buffer-offset decision for pointer arguments
std::atomic<uint32_t> g_frames{0};

std::vector<EGLint> ReadAttribs(GuestMemory& m, uint32_t p) {
    std::vector<EGLint> v;
    if (!p) { v.push_back(EGL_NONE); return v; }
    for (int i = 0; i < 128; ++i) {
        const EGLint k = m.read<int32_t>(p + 8u * i);
        v.push_back(k);
        if (k == EGL_NONE) return v;
        v.push_back(m.read<int32_t>(p + 8u * i + 4));
    }
    v.push_back(EGL_NONE);
    return v;
}

}  // namespace

void AndroidBridge::ReleaseEglOnThisThread() {
    if (Gl().display() != EGL_NO_DISPLAY) eglMakeCurrent(Gl().display(), EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
}

void RegisterGles(Hle& h) {
    GuestMemory& m = h.mem;
    h.on_thread_exit = [] { Bridge().ReleaseEglOnThisThread(); JniThreadExit(); };

    // =========================================================================================== EGL
    h.Register("eglGetDisplay", [](CallCtx& c) { c.ret(kDisplayH); });
    h.Register("eglInitialize", [&m](CallCtx& c) {
        if (c.arg(1)) m.write<int32_t>(c.arg(1), 1);
        if (c.arg(2)) m.write<int32_t>(c.arg(2), 4);
        c.ret(EGL_TRUE);
    });
    h.Register("eglChooseConfig", [&m](CallCtx& c) {  // (dpy, attribs, configs*, size, num*): the game always gets the app's config
        if (c.arg(2) && int32_t(c.arg(3)) > 0) m.write<uint32_t>(c.arg(2), kConfigH);
        if (c.arg(4)) m.write<int32_t>(c.arg(4), 1);
        c.ret(EGL_TRUE);
    });
    h.Register("eglGetConfigAttrib", [&m](CallCtx& c) {  // (dpy, config, attribute, int* value)
        EGLint v = 0;
        const EGLBoolean ok = eglGetConfigAttrib(Gl().display(), Gl().config(), EGLint(c.arg(2)), &v);
        if (ok && c.arg(3)) m.write<int32_t>(c.arg(3), v);
        c.ret(uint32_t(ok));
    });
    h.Register("eglCreateContext", [&m](CallCtx& c) {  // (dpy, config, share_context, attribs)
        std::vector<EGLint> attr = ReadAttribs(m, c.arg(3));
        EGLContext share = g_contexts.GetOr(c.arg(2), EGL_NO_CONTEXT);
        EGLContext ctx = eglCreateContext(Gl().display(), Gl().config(), share, attr.data());
        if (ctx == EGL_NO_CONTEXT) Logf("[egl] eglCreateContext failed (0x%x)", eglGetError());
        c.ret(ctx == EGL_NO_CONTEXT ? 0u : g_contexts.Put(ctx));
    });
    h.Register("eglCreateWindowSurface", [](CallCtx& c) {  // (dpy, config, native_window, attribs)
        std::lock_guard<std::recursive_mutex> lk(Gl().mutex());  // waits for a banner frame that may be in flight
        if (!Gl().has_surface() || Bridge().Window(c.arg(2)) != Gl().window()) {
            Logf("[egl] eglCreateWindowSurface: window is not the app's surface");
            c.ret(0);
            return;
        }
        if (Bridge().on_window_taken) Bridge().on_window_taken(true);
        c.ret(kSurfaceH);
    });
    h.Register("eglDestroySurface", [](CallCtx& c) { c.ret(EGL_TRUE); });  // the app owns the surface
    h.Register("eglMakeCurrent", [](CallCtx& c) {  // (dpy, draw, read, ctx)
        std::lock_guard<std::recursive_mutex> lk(Gl().mutex());
        EGLContext ctx = g_contexts.GetOr(c.arg(3), EGL_NO_CONTEXT);
        EGLSurface s = (c.arg(1) == kSurfaceH) ? Gl().surface() : EGL_NO_SURFACE;
        EGLSurface r = (c.arg(2) == kSurfaceH) ? Gl().surface() : EGL_NO_SURFACE;
        const EGLBoolean ok = eglMakeCurrent(Gl().display(), s, r, ctx);
        if (!ok) Logf("[egl] eglMakeCurrent failed (0x%x)", eglGetError());
        c.ret(uint32_t(ok));
    });
    h.Register("eglQuerySurface", [&m](CallCtx& c) {  // (dpy, surface, attribute, int* value)
        EGLint v = 0;
        const EGLBoolean ok = Gl().has_surface() && eglQuerySurface(Gl().display(), Gl().surface(), EGLint(c.arg(2)), &v);
        if (ok && c.arg(3)) m.write<int32_t>(c.arg(3), v);
        c.ret(uint32_t(ok));
    });
    h.Register("eglSwapBuffers", [](CallCtx& c) {
        const EGLBoolean ok = Gl().has_surface() ? eglSwapBuffers(Gl().display(), Gl().surface()) : EGL_FALSE;
        const uint32_t n = ++g_frames;
        if (n == 1 || n == 2 || n == 60 || n == 600 || n % 6000 == 0) Logf("[gl] frame %u swapped (ok=%d)", n, int(ok));
        if (!ok && (n < 10)) Logf("[egl] eglSwapBuffers failed (0x%x)", eglGetError());
        c.ret(uint32_t(ok));
    });

    // =========================================================================================== OpenGL ES 2
    h.Register("glActiveTexture", [](CallCtx& c) { glActiveTexture(c.arg(0)); });
    h.Register("glAttachShader", [](CallCtx& c) { glAttachShader(c.arg(0), c.arg(1)); });
    h.Register("glBindAttribLocation", [&m](CallCtx& c) { glBindAttribLocation(c.arg(0), c.arg(1), m.cstr(c.arg(2)).c_str()); });
    h.Register("glBindBuffer", [](CallCtx& c) {
        if (c.arg(0) == GL_ARRAY_BUFFER) g_array_buffer = c.arg(1);
        else if (c.arg(0) == GL_ELEMENT_ARRAY_BUFFER) g_element_buffer = c.arg(1);
        glBindBuffer(c.arg(0), c.arg(1));
    });
    h.Register("glBindFramebuffer", [](CallCtx& c) { glBindFramebuffer(c.arg(0), c.arg(1)); });
    h.Register("glBindRenderbuffer", [](CallCtx& c) { glBindRenderbuffer(c.arg(0), c.arg(1)); });
    h.Register("glBindTexture", [](CallCtx& c) { glBindTexture(c.arg(0), c.arg(1)); });
    h.Register("glBlendEquation", [](CallCtx& c) { glBlendEquation(c.arg(0)); });
    h.Register("glBlendFunc", [](CallCtx& c) { glBlendFunc(c.arg(0), c.arg(1)); });
    h.Register("glBlendFuncSeparate", [](CallCtx& c) { glBlendFuncSeparate(c.arg(0), c.arg(1), c.arg(2), c.arg(3)); });
    h.Register("glBufferData", [&m](CallCtx& c) {  // (target, size, data*, usage)
        glBufferData(c.arg(0), GLsizeiptr(int32_t(c.arg(1))), m.hostp(c.arg(2), c.arg(1)), c.arg(3));
    });
    h.Register("glCheckFramebufferStatus", [](CallCtx& c) { c.ret(glCheckFramebufferStatus(c.arg(0))); });
    h.Register("glClear", [](CallCtx& c) { glClear(c.arg(0)); });
    h.Register("glClearColor", [](CallCtx& c) { glClearColor(c.argf(0), c.argf(1), c.argf(2), c.argf(3)); });
    h.Register("glClearDepthf", [](CallCtx& c) { glClearDepthf(c.argf(0)); });
    h.Register("glClearStencil", [](CallCtx& c) { glClearStencil(int32_t(c.arg(0))); });
    h.Register("glCompileShader", [](CallCtx& c) { glCompileShader(c.arg(0)); });
    h.Register("glCreateProgram", [](CallCtx& c) { c.ret(glCreateProgram()); });
    h.Register("glCreateShader", [](CallCtx& c) { c.ret(glCreateShader(c.arg(0))); });
    h.Register("glDeleteBuffers", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(1), 4u * c.arg(0))) glDeleteBuffers(int32_t(c.arg(0)), reinterpret_cast<const GLuint*>(p)); });
    h.Register("glDeleteFramebuffers", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(1), 4u * c.arg(0))) glDeleteFramebuffers(int32_t(c.arg(0)), reinterpret_cast<const GLuint*>(p)); });
    h.Register("glDeleteTextures", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(1), 4u * c.arg(0))) glDeleteTextures(int32_t(c.arg(0)), reinterpret_cast<const GLuint*>(p)); });
    h.Register("glDeleteProgram", [](CallCtx& c) { glDeleteProgram(c.arg(0)); });
    h.Register("glDeleteShader", [](CallCtx& c) { glDeleteShader(c.arg(0)); });
    h.Register("glDepthFunc", [](CallCtx& c) { glDepthFunc(c.arg(0)); });
    h.Register("glDepthMask", [](CallCtx& c) { glDepthMask(GLboolean(c.arg(0) & 0xFF)); });
    h.Register("glDisable", [](CallCtx& c) { glDisable(c.arg(0)); });
    h.Register("glEnable", [](CallCtx& c) { glEnable(c.arg(0)); });
    h.Register("glDisableVertexAttribArray", [](CallCtx& c) { glDisableVertexAttribArray(c.arg(0)); });
    h.Register("glEnableVertexAttribArray", [](CallCtx& c) { glEnableVertexAttribArray(c.arg(0)); });
    h.Register("glDrawArrays", [](CallCtx& c) { glDrawArrays(c.arg(0), int32_t(c.arg(1)), int32_t(c.arg(2))); });
    h.Register("glDrawElements", [&m](CallCtx& c) {  // (mode, count, type, indices): buffer offset or client array
        const uint32_t type = c.arg(2), tsize = type == GL_UNSIGNED_INT ? 4u : type == GL_UNSIGNED_SHORT ? 2u : 1u;
        const void* idx;
        if (g_element_buffer) idx = reinterpret_cast<const void*>(static_cast<uintptr_t>(c.arg(3)));
        else {
            idx = m.hostp(c.arg(3), size_t(c.arg(1)) * tsize);
            if (!idx) { Logf("[gl] glDrawElements with an invalid index pointer 0x%08x", c.arg(3)); return; }
        }
        glDrawElements(c.arg(0), int32_t(c.arg(1)), type, idx);
    });
    h.Register("glFramebufferRenderbuffer", [](CallCtx& c) { glFramebufferRenderbuffer(c.arg(0), c.arg(1), c.arg(2), c.arg(3)); });
    h.Register("glFramebufferTexture2D", [](CallCtx& c) { glFramebufferTexture2D(c.arg(0), c.arg(1), c.arg(2), c.arg(3), int32_t(c.arg(4))); });
    h.Register("glFrontFace", [](CallCtx& c) { glFrontFace(c.arg(0)); });
    h.Register("glGenBuffers", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(1), 4u * c.arg(0))) glGenBuffers(int32_t(c.arg(0)), reinterpret_cast<GLuint*>(p)); });
    h.Register("glGenFramebuffers", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(1), 4u * c.arg(0))) glGenFramebuffers(int32_t(c.arg(0)), reinterpret_cast<GLuint*>(p)); });
    h.Register("glGenRenderbuffers", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(1), 4u * c.arg(0))) glGenRenderbuffers(int32_t(c.arg(0)), reinterpret_cast<GLuint*>(p)); });
    h.Register("glGenTextures", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(1), 4u * c.arg(0))) glGenTextures(int32_t(c.arg(0)), reinterpret_cast<GLuint*>(p)); });
    h.Register("glGetActiveUniform", [&m](CallCtx& c) {  // (program, index, bufsize, length*, size*, type*, name*)
        const GLsizei cap = int32_t(c.arg(2)) > 0 ? int32_t(c.arg(2)) : 1;
        std::vector<char> name(size_t(cap) + 1, 0);
        GLsizei len = 0;
        GLint size = 0;
        GLenum type = 0;
        glGetActiveUniform(c.arg(0), c.arg(1), cap, &len, &size, &type, name.data());
        if (c.arg(3)) m.write<int32_t>(c.arg(3), len);
        if (c.arg(4)) m.write<int32_t>(c.arg(4), size);
        if (c.arg(5)) m.write<uint32_t>(c.arg(5), type);
        if (c.arg(6) && int32_t(c.arg(2)) > 0) WriteGuestString(m, c.arg(6), std::string(name.data()));
    });
    h.Register("glGetProgramiv", [&m](CallCtx& c) { GLint v = 0; glGetProgramiv(c.arg(0), c.arg(1), &v); if (c.arg(2)) m.write<int32_t>(c.arg(2), v); });
    h.Register("glGetShaderiv", [&m](CallCtx& c) { GLint v = 0; glGetShaderiv(c.arg(0), c.arg(1), &v); if (c.arg(2)) m.write<int32_t>(c.arg(2), v); });
    h.Register("glGetProgramInfoLog", [&m](CallCtx& c) {  // (program, bufsize, length*, infolog*)
        const GLsizei cap = int32_t(c.arg(1)) > 0 ? int32_t(c.arg(1)) : 1;
        std::vector<char> log(size_t(cap) + 1, 0);
        GLsizei len = 0;
        glGetProgramInfoLog(c.arg(0), cap, &len, log.data());
        if (c.arg(2)) m.write<int32_t>(c.arg(2), len);
        if (c.arg(3) && int32_t(c.arg(1)) > 0) WriteGuestString(m, c.arg(3), std::string(log.data()));
    });
    h.Register("glGetShaderInfoLog", [&m](CallCtx& c) {
        const GLsizei cap = int32_t(c.arg(1)) > 0 ? int32_t(c.arg(1)) : 1;
        std::vector<char> log(size_t(cap) + 1, 0);
        GLsizei len = 0;
        glGetShaderInfoLog(c.arg(0), cap, &len, log.data());
        if (c.arg(2)) m.write<int32_t>(c.arg(2), len);
        if (c.arg(3) && int32_t(c.arg(1)) > 0) WriteGuestString(m, c.arg(3), std::string(log.data()));
    });
    h.Register("glGetString", [&h](CallCtx& c) {
        static std::mutex mu;
        static std::unordered_map<uint32_t, uint32_t> cache;
        std::lock_guard<std::mutex> lk(mu);
        auto it = cache.find(c.arg(0));
        if (it == cache.end()) {
            const GLubyte* s = glGetString(c.arg(0));
            it = cache.emplace(c.arg(0), s ? PutGuestString(h, reinterpret_cast<const char*>(s)) : 0u).first;
        }
        c.ret(it->second);
    });
    h.Register("glGetUniformLocation", [&m](CallCtx& c) { c.ret(uint32_t(glGetUniformLocation(c.arg(0), m.cstr(c.arg(1)).c_str()))); });
    h.Register("glLinkProgram", [](CallCtx& c) { glLinkProgram(c.arg(0)); });
    h.Register("glPixelStorei", [](CallCtx& c) { glPixelStorei(c.arg(0), int32_t(c.arg(1))); });
    h.Register("glReadPixels", [&m](CallCtx& c) {  // (x, y, w, h, format, type, pixels*)
        const size_t bytes = size_t(c.arg(2)) * c.arg(3) * 4;
        if (void* p = m.hostp(c.arg(6), bytes)) glReadPixels(int32_t(c.arg(0)), int32_t(c.arg(1)), int32_t(c.arg(2)), int32_t(c.arg(3)), c.arg(4), c.arg(5), p);
    });
    h.Register("glRenderbufferStorage", [](CallCtx& c) { glRenderbufferStorage(c.arg(0), c.arg(1), int32_t(c.arg(2)), int32_t(c.arg(3))); });
    h.Register("glScissor", [](CallCtx& c) { glScissor(int32_t(c.arg(0)), int32_t(c.arg(1)), int32_t(c.arg(2)), int32_t(c.arg(3))); });
    h.Register("glShaderSource", [&m](CallCtx& c) {  // (shader, count, const char** string, const GLint* length)
        const uint32_t count = c.arg(1);
        std::vector<std::string> src(count);
        std::vector<const char*> ptrs(count);
        std::vector<GLint> lens(count);
        for (uint32_t i = 0; i < count; ++i) {
            const uint32_t sp = m.read<uint32_t>(c.arg(2) + 4 * i);
            const int32_t len = c.arg(3) ? m.read<int32_t>(c.arg(3) + 4 * i) : -1;
            if (len >= 0) {
                const uint8_t* d = m.hostp(sp, size_t(len));
                src[i] = d ? std::string(reinterpret_cast<const char*>(d), size_t(len)) : std::string();
            } else {
                src[i] = m.cstr(sp, 1u << 20);
            }
            ptrs[i] = src[i].c_str();
            lens[i] = GLint(src[i].size());
        }
        glShaderSource(c.arg(0), GLsizei(count), ptrs.data(), lens.data());
    });
    h.Register("glStencilFunc", [](CallCtx& c) { glStencilFunc(c.arg(0), int32_t(c.arg(1)), c.arg(2)); });
    h.Register("glStencilMask", [](CallCtx& c) { glStencilMask(c.arg(0)); });
    h.Register("glStencilOp", [](CallCtx& c) { glStencilOp(c.arg(0), c.arg(1), c.arg(2)); });
    h.Register("glTexImage2D", [&m](CallCtx& c) {  // (target, level, internalformat, w, h, border, format, type, pixels*)
        glTexImage2D(c.arg(0), int32_t(c.arg(1)), int32_t(c.arg(2)), int32_t(c.arg(3)), int32_t(c.arg(4)), int32_t(c.arg(5)),
                     c.arg(6), c.arg(7), m.hostp(c.arg(8)));
    });
    h.Register("glTexSubImage2D", [&m](CallCtx& c) {  // (target, level, xoff, yoff, w, h, format, type, pixels*)
        glTexSubImage2D(c.arg(0), int32_t(c.arg(1)), int32_t(c.arg(2)), int32_t(c.arg(3)), int32_t(c.arg(4)), int32_t(c.arg(5)),
                        c.arg(6), c.arg(7), m.hostp(c.arg(8)));
    });
    h.Register("glTexParameteri", [](CallCtx& c) { glTexParameteri(c.arg(0), c.arg(1), int32_t(c.arg(2))); });
    h.Register("glUniform1i", [](CallCtx& c) { glUniform1i(int32_t(c.arg(0)), int32_t(c.arg(1))); });
    h.Register("glUniform1fv", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(2), 4u * c.arg(1))) glUniform1fv(int32_t(c.arg(0)), int32_t(c.arg(1)), reinterpret_cast<const GLfloat*>(p)); });
    h.Register("glUniform2fv", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(2), 8u * c.arg(1))) glUniform2fv(int32_t(c.arg(0)), int32_t(c.arg(1)), reinterpret_cast<const GLfloat*>(p)); });
    h.Register("glUniform3fv", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(2), 12u * c.arg(1))) glUniform3fv(int32_t(c.arg(0)), int32_t(c.arg(1)), reinterpret_cast<const GLfloat*>(p)); });
    h.Register("glUniform4fv", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(2), 16u * c.arg(1))) glUniform4fv(int32_t(c.arg(0)), int32_t(c.arg(1)), reinterpret_cast<const GLfloat*>(p)); });
    h.Register("glUniformMatrix2fv", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(3), 16u * c.arg(1))) glUniformMatrix2fv(int32_t(c.arg(0)), int32_t(c.arg(1)), GLboolean(c.arg(2) & 0xFF), reinterpret_cast<const GLfloat*>(p)); });
    h.Register("glUniformMatrix3fv", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(3), 36u * c.arg(1))) glUniformMatrix3fv(int32_t(c.arg(0)), int32_t(c.arg(1)), GLboolean(c.arg(2) & 0xFF), reinterpret_cast<const GLfloat*>(p)); });
    h.Register("glUniformMatrix4fv", [&m](CallCtx& c) { if (auto* p = m.hostp(c.arg(3), 64u * c.arg(1))) glUniformMatrix4fv(int32_t(c.arg(0)), int32_t(c.arg(1)), GLboolean(c.arg(2) & 0xFF), reinterpret_cast<const GLfloat*>(p)); });
    h.Register("glUseProgram", [](CallCtx& c) { glUseProgram(c.arg(0)); });
    h.Register("glValidateProgram", [](CallCtx& c) { glValidateProgram(c.arg(0)); });
    h.Register("glVertexAttribPointer", [&m](CallCtx& c) {  // (index, size, type, normalized, stride, pointer)
        const void* ptr = g_array_buffer ? reinterpret_cast<const void*>(static_cast<uintptr_t>(c.arg(5))) : m.hostp(c.arg(5));
        glVertexAttribPointer(c.arg(0), int32_t(c.arg(1)), c.arg(2), GLboolean(c.arg(3) & 0xFF), int32_t(c.arg(4)), ptr);
    });
    h.Register("glViewport", [](CallCtx& c) { glViewport(int32_t(c.arg(0)), int32_t(c.arg(1)), int32_t(c.arg(2)), int32_t(c.arg(3))); });
}

}  // namespace t64
