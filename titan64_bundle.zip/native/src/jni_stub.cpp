// A fake JavaVM / JNIEnv living in guest memory. The game's native code may call into "Java" through these tables;
// every slot logs its first call and returns a harmless value, a few common ones return something sensible.
#include <cstring>
#include <mutex>
#include <set>

#include "android_hle.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {

void RegisterJni(Hle& h, uint32_t* vm_out, uint32_t* env_out) {
    GuestMemory& m = h.mem;
    constexpr int kEnvSlots = 240;
    const uint32_t env_tab = h.Alloc(4 * kEnvSlots), vm_tab = h.Alloc(4 * 8);
    const uint32_t env = h.Alloc(16), vm = h.Alloc(16);
    const uint32_t empty_str = PutGuestString(h, "");
    m.write<uint32_t>(env, env_tab);
    m.write<uint32_t>(vm, vm_tab);
    constexpr uint32_t kClass = 0x7A000010u, kMethod = 0x7A100010u, kString = 0x7A200010u;

    auto slot = [&](int i, HleFn fn) {
        const std::string name = "JNIEnv#" + std::to_string(i);
        h.Register(name, std::move(fn));
        m.write<uint32_t>(env_tab + 4u * uint32_t(i), h.Function(name));
    };
    for (int i = 0; i < kEnvSlots; ++i)
        slot(i, [i](CallCtx& c) {
            static std::mutex mu;
            static std::set<int> seen;
            bool first;
            { std::lock_guard<std::mutex> lk(mu); first = seen.insert(i).second; }
            if (first) Logf("[jni] JNIEnv slot %d called (stubbed, returns 0)", i);
            c.ret(0);
        });
    slot(4, [](CallCtx& c) { c.ret(0x00010006u); });                              // GetVersion
    slot(6, [](CallCtx& c) { c.ret(kClass); });                                   // FindClass
    slot(17, [](CallCtx& c) { c.ret(0); });                                       // ExceptionClear
    slot(21, [](CallCtx& c) { c.ret(c.arg(1)); });                                // NewGlobalRef
    slot(22, [](CallCtx& c) { c.ret(0); });                                       // DeleteGlobalRef
    slot(23, [](CallCtx& c) { c.ret(0); });                                       // DeleteLocalRef
    slot(24, [](CallCtx& c) { c.ret(c.arg(1) == c.arg(2)); });                    // IsSameObject
    slot(25, [](CallCtx& c) { c.ret(c.arg(1)); });                                // NewLocalRef
    slot(31, [](CallCtx& c) { c.ret(kClass); });                                  // GetObjectClass
    for (int i : {33, 94, 113, 144}) slot(i, [](CallCtx& c) { c.ret(kMethod); });  // Get(Static)MethodID / Get(Static)FieldID
    slot(167, [](CallCtx& c) { c.ret(kString); });                                // NewStringUTF
    slot(169, [empty_str, &m](CallCtx& c) { if (c.arg(2)) m.write<uint8_t>(c.arg(2), 0); c.ret(empty_str); });  // GetStringUTFChars
    slot(170, [](CallCtx& c) { c.ret(0); });                                      // ReleaseStringUTFChars
    slot(228, [](CallCtx& c) { c.ret(0); });                                      // ExceptionCheck

    // JNIInvokeInterface: 3 DestroyJavaVM, 4 AttachCurrentThread, 5 DetachCurrentThread, 6 GetEnv, 7 AttachCurrentThreadAsDaemon
    auto vslot = [&](int i, HleFn fn) {
        const std::string name = "JavaVM#" + std::to_string(i);
        h.Register(name, std::move(fn));
        m.write<uint32_t>(vm_tab + 4u * uint32_t(i), h.Function(name));
    };
    for (int i = 0; i < 3; ++i) vslot(i, [](CallCtx& c) { c.ret(0); });
    vslot(3, [](CallCtx& c) { c.ret(0); });
    auto get_env = [&m, env](CallCtx& c) { if (c.arg(1)) m.write<uint32_t>(c.arg(1), env); c.ret(0); };
    vslot(4, get_env);
    vslot(5, [](CallCtx& c) { c.ret(0); });
    vslot(6, get_env);
    vslot(7, get_env);
    *vm_out = vm;
    *env_out = env;
}

}  // namespace t64
