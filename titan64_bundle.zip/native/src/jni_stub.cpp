// A fake JavaVM / JNIEnv living in guest memory. The game's native code (and the Google Play Games C++ SDK linked into
// it) call into "Java" through these tables. There is no Java here, so every call logs what was asked (class, method name
// and signature, strings) and returns a harmless value; the log tells us which Java behaviour has to be emulated for real.
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_map>

#include "android_hle.h"
#include "libc_util.h"
#include "log.h"

namespace t64 {
namespace {

const char* kTypes[10] = {"Object", "Boolean", "Byte", "Char", "Short", "Int", "Long", "Float", "Double", "Void"};
const char* kArrTypes[8] = {"Boolean", "Byte", "Char", "Short", "Int", "Long", "Float", "Double"};

std::string SlotName(int i) {
    static const char* fixed[] = {"reserved0", "reserved1", "reserved2", "reserved3", "GetVersion", "DefineClass", "FindClass", "FromReflectedMethod",
        "FromReflectedField", "ToReflectedMethod", "GetSuperclass", "IsAssignableFrom", "ToReflectedField", "Throw", "ThrowNew", "ExceptionOccurred",
        "ExceptionDescribe", "ExceptionClear", "FatalError", "PushLocalFrame", "PopLocalFrame", "NewGlobalRef", "DeleteGlobalRef", "DeleteLocalRef",
        "IsSameObject", "NewLocalRef", "EnsureLocalCapacity", "AllocObject", "NewObject", "NewObjectV", "NewObjectA", "GetObjectClass", "IsInstanceOf",
        "GetMethodID"};
    if (i < 34) return fixed[i];
    auto call = [&](int base, const char* prefix) -> std::string {
        const int k = i - base;
        static const char* suffix[3] = {"", "V", "A"};
        return std::string(prefix) + kTypes[k / 3] + "Method" + suffix[k % 3];
    };
    if (i < 64) return call(34, "Call");
    if (i < 94) return call(64, "CallNonvirtual");
    if (i == 94) return "GetFieldID";
    if (i < 104) return std::string("Get") + kTypes[i - 95] + "Field";
    if (i < 113) return std::string("Set") + kTypes[i - 104] + "Field";
    if (i == 113) return "GetStaticMethodID";
    if (i < 144) return call(114, "CallStatic");
    if (i == 144) return "GetStaticFieldID";
    if (i < 154) return std::string("GetStatic") + kTypes[i - 145] + "Field";
    if (i < 163) return std::string("SetStatic") + kTypes[i - 154] + "Field";
    static const char* mid[] = {"NewString", "GetStringLength", "GetStringChars", "ReleaseStringChars", "NewStringUTF", "GetStringUTFLength",
        "GetStringUTFChars", "ReleaseStringUTFChars", "GetArrayLength", "NewObjectArray", "GetObjectArrayElement", "SetObjectArrayElement"};
    if (i < 175) return mid[i - 163];
    if (i < 183) return std::string("New") + kArrTypes[i - 175] + "Array";
    if (i < 191) return std::string("Get") + kArrTypes[i - 183] + "ArrayElements";
    if (i < 199) return std::string("Release") + kArrTypes[i - 191] + "ArrayElements";
    if (i < 207) return std::string("Get") + kArrTypes[i - 199] + "ArrayRegion";
    if (i < 215) return std::string("Set") + kArrTypes[i - 207] + "ArrayRegion";
    static const char* tail[] = {"RegisterNatives", "UnregisterNatives", "MonitorEnter", "MonitorExit", "GetJavaVM", "GetStringRegion",
        "GetStringUTFRegion", "GetPrimitiveArrayCritical", "ReleasePrimitiveArrayCritical", "GetStringCritical", "ReleaseStringCritical",
        "NewWeakGlobalRef", "DeleteWeakGlobalRef", "ExceptionCheck", "NewDirectByteBuffer", "GetDirectBufferAddress", "GetDirectBufferCapacity",
        "GetObjectRefType"};
    if (i < 233) return tail[i - 215];
    return "slot" + std::to_string(i);
}

struct JniState {
    std::mutex mu;
    std::unordered_map<uint32_t, std::string> classes, members, strings;  // handle -> description / contents
    std::unordered_map<uint32_t, uint32_t> string_ptrs;                   // string handle -> guest copy (for GetStringUTFChars)
    uint32_t next_class = 0x7A000100u, next_member = 0x7A100100u, next_string = 0x7A200100u, next_object = 0x7A300100u;
    int logged = 0;
};
JniState& J() { static JniState* s = new JniState; return *s; }

void JLog(const char* fmt, const std::string& a, const std::string& b = "", const std::string& c = "") {
    JniState& s = J();
    std::lock_guard<std::mutex> lk(s.mu);
    if (s.logged++ < 400) Logf(fmt, a.c_str(), b.c_str(), c.c_str());
}

}  // namespace

void RegisterJni(Hle& h, uint32_t* vm_out, uint32_t* env_out) {
    GuestMemory& m = h.mem;
    constexpr int kEnvSlots = 240;
    const uint32_t env_tab = h.Alloc(4 * kEnvSlots), vm_tab = h.Alloc(4 * 8);
    const uint32_t env = h.Alloc(16), vm = h.Alloc(16);
    const uint32_t empty_str = PutGuestString(h, "");
    m.write<uint32_t>(env, env_tab);
    m.write<uint32_t>(vm, vm_tab);

    auto member_desc = [](uint32_t id) {
        JniState& s = J();
        std::lock_guard<std::mutex> lk(s.mu);
        auto it = s.members.find(id);
        return it == s.members.end() ? std::string("?") : it->second;
    };
    auto fresh_object = []() {
        JniState& s = J();
        std::lock_guard<std::mutex> lk(s.mu);
        const uint32_t o = s.next_object;
        s.next_object += 16;
        return o;
    };

    // Generic handler for every slot: log the call, return 0 / a fresh object / false depending on the declared return type.
    for (int i = 0; i < kEnvSlots; ++i) {
        const std::string name = "JNIEnv#" + std::to_string(i);
        const std::string sn = SlotName(i);
        const bool is_call = (i >= 34 && i < 94) || (i >= 114 && i < 144);
        const bool is_object_call = is_call && (((i >= 34 && i < 64) ? (i - 34) : (i >= 64 && i < 94) ? (i - 64) : (i - 114)) / 3 == 0);
        h.Register(name, [&h, &m, i, sn, is_call, is_object_call, member_desc, fresh_object](CallCtx& c) {
            if (is_call) {
                // (env, obj/class, methodID, ...) ; nonvirtual calls carry an extra class argument
                const uint32_t mid = (i >= 64 && i < 94) ? c.arg(3) : c.arg(2);
                JLog("[jni] %s -> %s", sn, member_desc(mid));
                c.ret(is_object_call ? fresh_object() : 0u);
                return;
            }
            JLog("[jni] %s (not emulated, returns 0)", sn);
            c.ret(0);
            (void)h; (void)m;
        });
        m.write<uint32_t>(env_tab + 4u * uint32_t(i), h.Function(name));
    }
    auto slot = [&](int i, HleFn fn) { h.Register("JNIEnv#" + std::to_string(i), std::move(fn)); };

    slot(4, [](CallCtx& c) { c.ret(0x00010006u); });  // GetVersion = JNI_VERSION_1_6
    slot(6, [&m](CallCtx& c) {                         // FindClass(name)
        const std::string name = m.cstr(c.arg(1));
        JniState& s = J();
        uint32_t id;
        {
            std::lock_guard<std::mutex> lk(s.mu);
            id = s.next_class;
            s.next_class += 16;
            s.classes[id] = name;
        }
        JLog("[jni] FindClass(%s)", name);
        c.ret(id);
    });
    for (int i : {17, 22, 23, 26, 170, 217, 218}) slot(i, [](CallCtx& c) { c.ret(0); });  // ExceptionClear, DeleteRef, EnsureCapacity, Release*, Monitor*
    slot(21, [](CallCtx& c) { c.ret(c.arg(1)); });                // NewGlobalRef
    slot(25, [](CallCtx& c) { c.ret(c.arg(1)); });                // NewLocalRef
    slot(226, [](CallCtx& c) { c.ret(c.arg(1)); });               // NewWeakGlobalRef
    slot(24, [](CallCtx& c) { c.ret(c.arg(1) == c.arg(2)); });    // IsSameObject
    slot(31, [fresh_object](CallCtx& c) { (void)c; JLog("[jni] GetObjectClass", ""); c.ret(0x7A000010u); });
    slot(32, [](CallCtx& c) { c.ret(1); });                       // IsInstanceOf -> true
    slot(228, [](CallCtx& c) { c.ret(0); });                      // ExceptionCheck -> no exception
    slot(15, [](CallCtx& c) { c.ret(0); });                       // ExceptionOccurred
    auto get_id = [&m](bool is_static, bool is_field) {
        return [&m, is_static, is_field](CallCtx& c) {  // (env, class, name, sig)
            const std::string cls = [&] { JniState& s = J(); std::lock_guard<std::mutex> lk(s.mu); auto it = s.classes.find(c.arg(1)); return it == s.classes.end() ? std::string("?") : it->second; }();
            const std::string desc = cls + "." + m.cstr(c.arg(2)) + m.cstr(c.arg(3)) + (is_static ? " [static]" : "") + (is_field ? " [field]" : "");
            JniState& s = J();
            uint32_t id;
            {
                std::lock_guard<std::mutex> lk(s.mu);
                id = s.next_member;
                s.next_member += 16;
                s.members[id] = desc;
            }
            JLog("[jni] Get%sID -> %s", is_field ? "Field" : (is_static ? "StaticMethod" : "Method"), desc);
            c.ret(id);
        };
    };
    slot(33, get_id(false, false));
    slot(94, get_id(false, true));
    slot(113, get_id(true, false));
    slot(144, get_id(true, true));
    slot(167, [&m](CallCtx& c) {  // NewStringUTF
        const std::string text = m.cstr(c.arg(1));
        JniState& s = J();
        uint32_t id;
        {
            std::lock_guard<std::mutex> lk(s.mu);
            id = s.next_string;
            s.next_string += 16;
            s.strings[id] = text;
        }
        JLog("[jni] NewStringUTF(\"%s\")", text);
        c.ret(id);
    });
    slot(168, [](CallCtx& c) {  // GetStringUTFLength
        JniState& s = J();
        std::lock_guard<std::mutex> lk(s.mu);
        auto it = s.strings.find(c.arg(1));
        c.ret(it == s.strings.end() ? 0u : uint32_t(it->second.size()));
    });
    slot(169, [&h, &m, empty_str](CallCtx& c) {  // GetStringUTFChars
        if (c.arg(2)) m.write<uint8_t>(c.arg(2), 0);
        std::string text;
        bool known = false;
        {
            JniState& s = J();
            std::lock_guard<std::mutex> lk(s.mu);
            auto it = s.strings.find(c.arg(1));
            if (it != s.strings.end()) { text = it->second; known = true; }
        }
        c.ret(known ? PutGuestString(h, text) : empty_str);
    });
    slot(171, [](CallCtx& c) { c.ret(0); });  // GetArrayLength
    slot(219, [&m, vm](CallCtx& c) { if (c.arg(1)) m.write<uint32_t>(c.arg(1), vm); c.ret(0); });  // GetJavaVM

    // JNIInvokeInterface: 3 DestroyJavaVM, 4 AttachCurrentThread, 5 DetachCurrentThread, 6 GetEnv, 7 AttachCurrentThreadAsDaemon
    auto vslot = [&](int i, HleFn fn) {
        const std::string name = "JavaVM#" + std::to_string(i);
        h.Register(name, std::move(fn));
        m.write<uint32_t>(vm_tab + 4u * uint32_t(i), h.Function(name));
    };
    for (int i = 0; i < 4; ++i) vslot(i, [](CallCtx& c) { c.ret(0); });
    auto get_env = [&m, env](CallCtx& c) { if (c.arg(1)) m.write<uint32_t>(c.arg(1), env); c.ret(0); };
    vslot(4, get_env);
    vslot(5, [](CallCtx& c) { c.ret(0); });
    vslot(6, get_env);
    vslot(7, get_env);
    *vm_out = vm;
    *env_out = env;
}

}  // namespace t64
