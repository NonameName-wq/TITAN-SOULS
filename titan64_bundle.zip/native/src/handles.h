// 32-bit guest handles for host objects (FILE*, AAsset*, EGLContext, ...). Guest code only ever treats them as opaque.
#pragma once
#include <cstdint>
#include <mutex>
#include <unordered_map>

namespace t64 {

template <class T>
class HandleMap {
public:
    explicit HandleMap(uint32_t base) : next_(base) {}
    uint32_t Put(T v) {
        std::lock_guard<std::mutex> lk(mu_);
        const uint32_t h = next_;
        next_ += 16;
        m_[h] = v;
        return h;
    }
    bool Get(uint32_t h, T* out) const {
        std::lock_guard<std::mutex> lk(mu_);
        auto it = m_.find(h);
        if (it == m_.end()) return false;
        *out = it->second;
        return true;
    }
    T GetOr(uint32_t h, T dflt) const {
        T v;
        return Get(h, &v) ? v : dflt;
    }
    void Erase(uint32_t h) {
        std::lock_guard<std::mutex> lk(mu_);
        m_.erase(h);
    }

private:
    mutable std::mutex mu_;
    uint32_t next_;
    std::unordered_map<uint32_t, T> m_;
};

}  // namespace t64
