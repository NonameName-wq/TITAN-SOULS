// High-level emulation of the system functions that libTestSuite.so imports.
// Each imported function gets a tiny ARM stub in guest memory: "svc #index; bx lr".
// Cpu::CallSVC forwards the index to Hle::Dispatch, which runs the host-side handler.
#pragma once
#include <array>
#include <cstdint>
#include <cstring>
#include <functional>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>
#include "elf32.h"
#include "guest_memory.h"

namespace t64 {

// Arguments follow the 32-bit ARM soft-float ABI (what armeabi-v7a Android uses):
// r0-r3 then stack; floats travel in core registers; 64-bit values use even register pairs.
struct CallCtx {
    GuestMemory& mem;
    std::array<uint32_t, 16>& r;
    uint32_t arg(int i) const { return i < 4 ? r[i] : mem.read<uint32_t>(r[13] + 4u * (i - 4)); }
    uint64_t arg64(int i) const { return uint64_t(arg(i)) | (uint64_t(arg(i + 1)) << 32); }
    float argf(int i) const { uint32_t v = arg(i); float f; std::memcpy(&f, &v, 4); return f; }
    double argd(int i) const { uint64_t v = arg64(i); double d; std::memcpy(&d, &v, 8); return d; }
    void ret(uint32_t v) { r[0] = v; }
    void ret64(uint64_t v) { r[0] = uint32_t(v); r[1] = uint32_t(v >> 32); }
    void retf(float f) { std::memcpy(&r[0], &f, 4); }
    void retd(double d) { uint64_t v; std::memcpy(&v, &d, 8); ret64(v); }
};

using HleFn = std::function<void(CallCtx&)>;

class Hle : public ImportResolver {
public:
    explicit Hle(GuestMemory& m);

    void InstallKuserHelpers();
    uint32_t Function(const std::string& name) override;
    uint32_t Data(const std::string& name, uint32_t size) override;
    void Dispatch(uint32_t index, std::array<uint32_t, 16>& regs);

    void Register(const std::string& name, HleFn fn) { fns_[name] = std::move(fn); }
    // Import implemented directly as guest ARM code (needed when the import must call back into guest code).
    void RegisterGuest(const std::string& name, std::vector<uint32_t> words) { guest_impl_[name] = std::move(words); }
    bool Implemented(const std::string& name) const { return fns_.count(name) != 0; }
    uint32_t Alloc(uint32_t size, uint32_t align = 16);
    uint32_t AllocSize(uint32_t ptr) const { return ptr ? mem.read<uint32_t>(ptr - 8) : 0; }

    GuestMemory& mem;
    bool halt_requested = false;
    std::string halt_reason;
    std::set<std::string> missing_called;  // imports that were called but have no handler

private:
    struct Entry { std::string name; };
    std::vector<Entry> entries_;
    std::unordered_map<std::string, uint32_t> func_addr_, data_addr_;
    std::unordered_map<std::string, HleFn> fns_;
    std::unordered_map<std::string, std::vector<uint32_t>> guest_impl_;
    uint32_t guest_code_ptr_ = kStubBase + 0x80000;
    uint32_t data_ptr_ = kDataBase;
    uint32_t heap_ptr_ = kHeapBase;
};

void RegisterBuiltins(Hle& h);

}  // namespace t64
