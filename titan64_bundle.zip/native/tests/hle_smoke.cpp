// Calls every portable HLE handler once with zero arguments (blocking / terminating ones excluded). Run with
// ASAN_OPTIONS=detect_stack_use_after_return=1 to catch handlers that captured dead stack variables.
#include <fstream>
#include <regex>
#include <set>
#include <sstream>
#include "hle.h"
using namespace t64;
int main(int argc, char** argv) {
    GuestMemory mem; Hle hle(mem);
    std::set<std::string> skip = {"exit", "abort", "raise", "__stack_chk_fail", "pthread_cond_wait", "pthread_cond_timedwait", "sem_wait",
                                  "sem_timedwait", "read", "readv", "poll", "system", "pthread_create", "_Unwind_RaiseException", "_Unwind_Resume",
                                  "_Unwind_Resume_or_Rethrow", "pthread_join", "getc", "fgetc"};
    std::set<std::string> names;
    std::regex re("\"([A-Za-z_][A-Za-z0-9_]*)\"");
    for (int i = 1; i < argc; ++i) {
        std::ifstream f(argv[i]); std::stringstream ss; ss << f.rdbuf(); std::string s = ss.str();
        for (std::sregex_iterator it(s.begin(), s.end(), re), end; it != end; ++it) if (hle.Implemented((*it)[1])) names.insert((*it)[1]);
    }
    int n = 0;
    for (const auto& name : names) {
        if (skip.count(name)) continue;
        uint32_t stub = hle.Function(name);
        uint32_t idx = mem.read<uint32_t>(stub) & 0xFFFFFF;
        std::array<uint32_t, 16> regs{};
        regs[13] = hle.Alloc(4096) + 2048;
        hle.Dispatch(idx, regs);
        ++n;
    }
    std::printf("smoke: called %d handlers without a crash\n", n);
    return 0;
}
