#include <cassert>
#include <cstdio>
#include <random>
#include <thread>
#include <vector>
#include "hle.h"
#include "libc_util.h"
using namespace t64;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)

GuestMemory* M; Hle* H;
thread_local std::array<uint32_t,16> R;
uint32_t call(const char* name, std::vector<uint32_t> a = {}, uint32_t* r1 = nullptr) {
    uint32_t stub = H->Function(name);
    uint32_t w = M->read<uint32_t>(stub);
    uint32_t idx = w & 0xFFFFFF;
    thread_local uint32_t stack_page = 0;
    if (!stack_page) stack_page = H->Alloc(4096);
    R.fill(0);
    R[13] = stack_page + 2048;
    for (size_t i = 0; i < a.size(); ++i) { if (i < 4) R[i] = a[i]; else M->write<uint32_t>(R[13] + 4 * (i - 4), a[i]); }
    H->Dispatch(idx, R);
    if (r1) *r1 = R[1];
    return R[0];
}
uint32_t str(const std::string& s) { return PutGuestString(*H, s); }

int main() {
    GuestMemory mem; Hle hle(mem); M = &mem; H = &hle;
    // ---- allocator ----
    {
        std::mt19937 rng(1);
        std::vector<std::pair<uint32_t,uint32_t>> live;
        for (int i = 0; i < 20000; ++i) {
            if (live.empty() || rng() % 3) {
                uint32_t sz = 1 + rng() % 5000; uint32_t p = hle.Alloc(sz);
                CHECK(p && p % 16 == 0);
                std::memset(mem.host(p), int(i & 0xFF), sz);
                live.push_back({p, sz});
            } else {
                size_t k = rng() % live.size(); auto [p, sz] = live[k];
                CHECK(mem.host(p)[0] == mem.host(p)[sz - 1]);   // not corrupted by neighbours
                hle.Free(p); live.erase(live.begin() + long(k));
            }
        }
        // overlap check
        std::sort(live.begin(), live.end());
        for (size_t i = 1; i < live.size(); ++i) CHECK(live[i-1].first + live[i-1].second <= live[i].first);
        for (auto& l : live) hle.Free(l.first);
        uint32_t big = hle.Alloc(300u << 20); CHECK(big != 0);   // coalesced back to a big region
        uint32_t p = hle.Realloc(0, 10); std::memcpy(mem.host(p), "hello", 6); p = hle.Realloc(p, 5000); CHECK(!std::strcmp((char*)mem.host(p), "hello"));
        hle.Free(big);
    }
    // ---- printf / sscanf ----
    {
        uint32_t buf = hle.Alloc(256);
        call("sprintf", {buf, str("%d|%5.2f|%s|%lld|%c|%x"), uint32_t(-5), 0, 0, 0});  // %5.2f needs a double: regs r2..: build properly below
        double d = 3.14159; uint64_t db; std::memcpy(&db, &d, 8);
        // sprintf(buf, "%d %5.2f %s %lld %c %#x", -5, 3.14159, "str", 1234567890123LL, 'z', 255)
        // args: r2=-5 ; double at (r3,[sp]) is 8-aligned -> r3 unused? AAPCS varargs: r3 skipped, double at sp+0
        R.fill(0);
        uint32_t stub = hle.Function("sprintf"); uint32_t idx = mem.read<uint32_t>(stub) & 0xFFFFFF;
        uint32_t sp = hle.Alloc(256) + 128; R[13] = sp; R[0] = buf; R[1] = str("%d %5.2f %s %lld %c %#x"); R[2] = uint32_t(-5);
        // r3 padding, then stack: double(8) , str ptr(4), pad(4)->8 align for long long, ll(8), 'z', 255
        mem.write<uint64_t>(sp + 0, db); mem.write<uint32_t>(sp + 8, str("str")); mem.write<uint64_t>(sp + 16, 1234567890123ull);
        mem.write<uint32_t>(sp + 24, 'z'); mem.write<uint32_t>(sp + 28, 255);
        hle.Dispatch(idx, R);
        std::printf("sprintf -> '%s'\n", (char*)mem.host(buf));
        CHECK(std::string((char*)mem.host(buf)) == "-5  3.14 str 1234567890123 z 0xff");
        // sscanf
        uint32_t a = hle.Alloc(16), b = hle.Alloc(16), s = hle.Alloc(64), f = hle.Alloc(16);
        uint32_t n = call("sscanf", {str("  42 0x1F hello 2.5 tail"), str("%d %i %s %f"), a, b, s, f});
        CHECK(n == 4); CHECK(mem.read<int32_t>(a) == 42); CHECK(mem.read<int32_t>(b) == 31); CHECK(mem.cstr(s) == "hello"); CHECK(mem.read<float>(f) == 2.5f);
        n = call("sscanf", {str("v=7;name=bob"), str("v=%d;name=%[a-z]"), a, s});
        CHECK(n == 2 && mem.read<int32_t>(a) == 7 && mem.cstr(s) == "bob");
        n = call("sscanf", {str(""), str("%d"), a}); CHECK(n == 0xFFFFFFFFu);
    }
    // ---- strings / misc ----
    {
        uint32_t t = call("strtod", {str("12.5xyz"), 0}); (void)t;
        uint32_t out; uint32_t lo = call("strtod", {str("12.5xyz"), 0}, &out); uint64_t bits = uint64_t(lo) | (uint64_t(out) << 32); double d; std::memcpy(&d, &bits, 8); CHECK(d == 12.5);
        uint32_t s = str("a,b;;c"); uint32_t t1 = call("strtok", {s, str(",;")}); CHECK(mem.cstr(t1) == "a");
        uint32_t t2 = call("strtok", {0, str(",;")}); CHECK(mem.cstr(t2) == "b"); uint32_t t3 = call("strtok", {0, str(",;")}); CHECK(mem.cstr(t3) == "c");
        CHECK(call("strtok", {0, str(",;")}) == 0);
    }
    // ---- regex ----
    {
        uint32_t re = hle.Alloc(16), pm = hle.Alloc(64);
        CHECK(call("regcomp", {re, str("^([a-z]+)_([0-9]+)$"), 1}) == 0);
        CHECK(call("regexec", {re, str("abc_123"), 3, pm, 0}) == 0);
        CHECK(mem.read<int32_t>(pm + 8) == 0 && mem.read<int32_t>(pm + 12) == 3 && mem.read<int32_t>(pm + 16) == 4 && mem.read<int32_t>(pm + 20) == 7);
        CHECK(call("regexec", {re, str("ABC"), 3, pm, 0}) != 0);
        call("regfree", {re});
    }
    // ---- qsort with a "guest" comparator ----
    {
        hle.call_guest = [&](uint32_t addr, const std::vector<uint32_t>& args, uint32_t* r0, std::string*) {
            int32_t x = mem.read<int32_t>(args[0]), y = mem.read<int32_t>(args[1]); *r0 = uint32_t(x < y ? -1 : x > y ? 1 : 0); return addr == 0x1234; };
        uint32_t arr = hle.Alloc(64); int32_t v[] = {5, -3, 9, 0, 7, 7, -8, 2};
        for (int i = 0; i < 8; ++i) mem.write<int32_t>(arr + 4 * i, v[i]);
        call("qsort", {arr, 8, 4, 0x1234});
        std::sort(v, v + 8); for (int i = 0; i < 8; ++i) CHECK(mem.read<int32_t>(arr + 4 * i) == v[i]);
    }
    // ---- files ----
    {
        std::string path = "/tmp/t64_test.bin";
        uint32_t f = call("fopen", {str(path), str("wb")}); CHECK(f != 0);
        uint32_t data = str("0123456789"); CHECK(call("fwrite", {data, 1, 10, f}) == 10); call("fclose", {f});
        f = call("fopen", {str(path), str("rb")}); call("fseek", {f, 0, 2}); CHECK(call("ftell", {f}) == 10);
        call("fseek", {f, 3, 0}); uint32_t buf = hle.Alloc(16); CHECK(call("fread", {buf, 1, 4, f}) == 4); CHECK(std::string((char*)mem.host(buf), 4) == "3456"); call("fclose", {f});
        uint32_t st = hle.Alloc(128); CHECK(call("stat", {str(path), st}) == 0); CHECK(mem.read<uint64_t>(st + 48) == 10);
        CHECK(call("fopen", {str("/nonexistent/x"), str("r")}) == 0); CHECK(mem.read<int32_t>(hle.ErrnoAddr()) == 2);
        uint32_t fds = hle.Alloc(8); CHECK(call("pipe", {fds}) == 0);
        int wfd = mem.read<int32_t>(fds + 4), rfd = mem.read<int32_t>(fds);
        CHECK(call("write", {uint32_t(wfd), data, 3}) == 3); CHECK(call("read", {uint32_t(rfd), buf, 8}) == 3);
        uint32_t dir = call("opendir", {str("/tmp")}); CHECK(dir != 0); int cnt = 0; while (call("readdir", {dir})) ++cnt; CHECK(cnt > 2); call("closedir", {dir});
        std::remove(path.c_str());
    }
    // ---- setjmp / longjmp ----
    {
        uint32_t stub = hle.Function("setjmp"), stub2 = hle.Function("longjmp");
        uint32_t i1 = mem.read<uint32_t>(stub) & 0xFFFFFF, i2 = mem.read<uint32_t>(stub2) & 0xFFFFFF;
        uint32_t jb = hle.Alloc(64); std::array<uint32_t,16> r{}; for (int i = 4; i < 12; ++i) r[i] = 100 + i; r[13] = 0x5000; r[14] = 0x4001; r[0] = jb;
        hle.Dispatch(i1, r); CHECK(r[0] == 0);
        std::array<uint32_t,16> q{}; q[0] = jb; q[1] = 0; hle.Dispatch(i2, q);
        CHECK(q[0] == 1 && q[13] == 0x5000 && q[14] == 0x4001 && q[4] == 104 && q[11] == 111);
    }
    // ---- threads: mutex / cond / join / semaphores with a fake guest runner ----
    {
        uint32_t counter = hle.Alloc(16), mtx = hle.Alloc(16), cv = hle.Alloc(16), flag = hle.Alloc(16), sem = hle.Alloc(16);
        call("pthread_mutex_init", {mtx, 0}); call("pthread_cond_init", {cv, 0}); call("sem_init", {sem, 0, 0});
        hle.run_thread = [&](uint32_t addr, uint32_t arg, uint32_t, uint32_t* r0, std::string*) {
            if (addr == 1) {            // worker: increments counter 20000 times under the mutex
                for (int i = 0; i < 20000; ++i) { call("pthread_mutex_lock", {mtx}); mem.write<int32_t>(counter, mem.read<int32_t>(counter) + 1); call("pthread_mutex_unlock", {mtx}); }
                *r0 = arg * 2;
            } else if (addr == 2) {     // waiter: waits on the condition until flag set, then posts the semaphore
                call("pthread_mutex_lock", {mtx});
                while (!mem.read<int32_t>(flag)) call("pthread_cond_wait", {cv, mtx});
                call("pthread_mutex_unlock", {mtx}); call("sem_post", {sem}); *r0 = 99;
            }
            return true; };
        uint32_t tids = hle.Alloc(64);
        for (int i = 0; i < 4; ++i) CHECK(call("pthread_create", {tids + 4u * i, 0, 1, uint32_t(10 + i)}) == 0);
        CHECK(call("pthread_create", {tids + 16, 0, 2, 0}) == 0);
        for (int i = 0; i < 4; ++i) { uint32_t rv = hle.Alloc(8); CHECK(call("pthread_join", {mem.read<uint32_t>(tids + 4u * i), rv}) == 0); CHECK(mem.read<uint32_t>(rv) == uint32_t((10 + i) * 2)); }
        CHECK(mem.read<int32_t>(counter) == 80000);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        call("pthread_mutex_lock", {mtx}); mem.write<int32_t>(flag, 1); call("pthread_cond_broadcast", {cv}); call("pthread_mutex_unlock", {mtx});
        uint32_t ts = hle.Alloc(8); mem.write<int32_t>(ts, int32_t(time(nullptr)) + 5); mem.write<int32_t>(ts + 4, 0);
        CHECK(call("sem_timedwait", {sem, ts}) == 0);
        uint32_t rv = hle.Alloc(8); CHECK(call("pthread_join", {mem.read<uint32_t>(tids + 16), rv}) == 0); CHECK(mem.read<uint32_t>(rv) == 99);
        // timed wait with no signal times out
        mem.write<int32_t>(ts, int32_t(time(nullptr))); mem.write<int32_t>(ts + 4, 50 * 1000 * 1000);
        call("pthread_mutex_lock", {mtx}); CHECK(call("pthread_cond_timedwait", {cv, mtx, ts}) == 110); call("pthread_mutex_unlock", {mtx});
    }
    std::printf(fails ? "\n%d FAILURES\n" : "\nALL TESTS PASSED\n", fails);
    return fails != 0;
}
