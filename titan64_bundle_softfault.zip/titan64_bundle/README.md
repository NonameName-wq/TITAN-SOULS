titan64 – soft-fault build (milestone 4 + FT crash workaround)
